# Public dataset provenance

- Dataset: **Superconductivty Data** (the official UCI title retains this spelling).
- Creator: Kam Hamidieh, 2018.
- Repository: UCI Machine Learning Repository, dataset 464.
- DOI: https://doi.org/10.24432/C53P47
- Dataset page: https://archive.ics.uci.edu/dataset/464/superconductivty+data
- Download source: https://archive.ics.uci.edu/static/public/464/superconductivty+data.zip
- License: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/
- Retrieved: 2026-10-08. The downloaded archive is unchanged; its SHA-256 is recorded in the real-data result metadata and package manifest.

The analysis reads `train.csv`, containing 21,263 rows, 81 predictors and the critical-temperature response. The new grouped evaluation uses `unique_m.csv` to keep identical normalized element compositions in one partition. Earlier random row splits do not isolate compositions. The supplied code introduces artificial independent missingness after training-only standardization; complete validation and test features are retained.

Changes made for analysis: random splitting, training-only centering/scaling, artificial masks, node partitioning, and response standardization. Original archive contents are not modified. Redistribution is under the dataset's stated CC BY 4.0 license with attribution above.

## Abalone

- Creators: Warwick Nash, Tracy Sellers, Simon Talbot, Andrew Cawthorn, Wes Ford (1994).
- UCI dataset page: https://archive.ics.uci.edu/dataset/1/abalone
- DOI: https://doi.org/10.24432/C55C7W
- Original archive: https://archive.ics.uci.edu/static/public/1/abalone.zip
- Retrieved: 2026-10-09; SHA-256 is recorded in the package manifest.
- License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/

The unchanged archive contains 4,177 records. The evaluation omits categorical sex, uses seven continuous measurements, and predicts ring count. Changes for analysis are training-only scaling, random splits, artificial MCAR masks, node partitioning, and response scaling. The original archive remains unchanged and is redistributed with the attribution above.
