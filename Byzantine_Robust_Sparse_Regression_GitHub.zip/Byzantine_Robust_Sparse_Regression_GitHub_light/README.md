# Byzantine-Robust Sparse Regression with Missing Covariates

Lightweight experimental reproducibility package by **Xiaofei Wu, Rongmei Liang, and Jian Qing Shi**, based on revision 40. It includes the experimental code, both public datasets for offline use, frozen plans, retained summaries, and supporting CSV tables.

**Seven large result files are omitted to keep the ZIP below 25 MB.** Their original sizes and SHA-256 hashes are recorded in [provenance/omitted_results.json](provenance/omitted_results.json). Complete raw-record audits require generating those records through new experiment runs. Packaging this archive did not rerun model fitting.

## Start here

Run from the repository root:

```text
python code/verify_repository.py
python -m pip install -r requirements-reproduce.txt
```

The verifier uses only the Python standard library and checks the files actually included. Keep `.gitattributes` to preserve the byte-level identities of frozen scripts and plans. No LaTeX installation is needed.

## Reproduce the main studies

Create a new workspace, then run the studies in order:

```text
python code/create_run_workspace.py all --destination runs/replication
cd runs/replication
python code/competitive_benchmark.py --mode full --repeats 30
python code/competitive_sample_size.py
python code/bind_replication_plan.py
python code/competitive_multimetric.py
python code/competitive_process_cost.py --pilot
python code/competitive_process_cost.py --run
python code/summarize_process_cost.py
```

The workspace keeps the original plans under `reference/` and writes new results separately. After the primary and sample-size runs, the binding step checks code, design, and record completeness and creates an evaluation plan tied to the new raw-file hashes. It preserves the seeds, design, tuning rules, and evaluation thresholds. Timing and file hashes may differ from the historical run.

These commands fit models and can take substantial time. `--resume` continues an interrupted run; it does not repeat a completed experiment. See the [reproducibility guide](docs/REPRODUCIBILITY.md) for independent audits and platform notes.

## Plot the retained summaries

The lightweight package already contains the summaries required by this command. Run it from the original package root:

```text
python code/revision38_figures.py
```

It generates experimental plots in `figures/` without fitting models or requiring the omitted raw records.

## Contents and attribution

| Location | Contents |
| --- | --- |
| `code/` | Solvers, runners, audits, plotting code, and repository helpers |
| `data/` | Two public dataset archives and attribution |
| `results/` | Plans, retained numerical results, summaries, logs, and environment records |
| `ancillary_tables/` | Supporting CSV tables and notes |
| `provenance/` | Baseline attribution, omitted-file hashes, and packaging information |
| `figures/` | Initially empty plot destination |

Data attribution is in [data/PROVENANCE.md](data/PROVENANCE.md); comparator details are in [SLARD baseline provenance](provenance/SLARD_BASELINE_PROVENANCE.txt). Author metadata and license status are in [CITATION.cff](CITATION.cff) and [LICENSE_NOTICE.md](LICENSE_NOTICE.md). The measured communication-cost study uses multiple processes on one host.

中文说明：这是小于 25 MB 的轻量复现包，保留代码、两套公开数据和实验汇总，未收入七个大型结果文件。完整原始记录审计需先重跑相应实验。上传方法见 [GitHub 上传说明](UPLOAD_GITHUB_中文.md)。
