# GitHub 轻量包上传说明

`Byzantine_Robust_Sparse_Regression_GitHub_light.zip` 是小于 25 MB 的实验复现包，包含代码、两套公开数据、实验计划、保留的数值结果与汇总、CSV 表和运行说明。

为缩减体积，本包未收入七个大型结果文件，也未收入其压缩副本。原始文件的大小与 SHA-256 见 `provenance/omitted_results.json`。因此，完整原始记录审计需要先重新运行相应实验；本次打包没有重新拟合模型。

## 上传

1. 解压 `Byzantine_Robust_Sparse_Regression_GitHub_light.zip`。
2. 建立自己的 GitHub 仓库。
3. 上传解压后目录**内部的文件和子目录**，使 `README.md` 位于仓库根目录；保留 `.gitignore` 和 `.gitattributes`。

上传原始轻量包的内容即可。重新运行实验产生的大文件留在本地运行目录，不需随本包上传。

## 使用

在包的根目录先运行：

```text
python code/verify_repository.py
python -m pip install -r requirements-reproduce.txt
```

第一条命令只校验包内现有文件，不恢复遗漏记录、不拟合模型。无需运行解压还原脚本，也无需安装 LaTeX。

[复现说明](docs/REPRODUCIBILITY.md) 给出了独立运行目录中的主实验、样本量后续实验、评价计划绑定、原始记录审计和同机多进程成本实验的顺序。新评价计划与新生成记录的哈希绑定，保留原种子、设计、调参及评价阈值；原发布目录保持不变。已包含的汇总可直接用于重新绘图。

作者代码尚未指定通用复用许可证；数据的原有授权与归属保留，详见 [LICENSE_NOTICE.md](LICENSE_NOTICE.md) 和 [数据说明](data/PROVENANCE.md)。
