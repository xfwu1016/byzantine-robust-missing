# License and attribution notice

The authors have not designated a general reuse license for their code or generated experimental results in this package. This notice does not grant an MIT, BSD, Creative Commons, or other license for those materials. Contact Jian Qing Shi (<jianqingshi@bnbu.edu.cn>) regarding permissions.

The two public dataset archives have their own terms. The UCI Superconductivty Data and Abalone datasets are attributed in [data/PROVENANCE.md](data/PROVENANCE.md) and distributed under the stated [Creative Commons Attribution 4.0 International license](https://creativecommons.org/licenses/by/4.0/). Preserve their attribution and identify analytical transformations when reusing them.

Python dependencies retain their respective licenses. Listing a dependency does not relicense it. The [SLARD baseline provenance](provenance/SLARD_BASELINE_PROVENANCE.txt) describes the relationship of the implemented comparators to the cited method.
