"""Plot the complete sample-size follow-up and fixed-threshold sensitivity.

Reads the frozen-data audit only; no simulation, fitting, or threshold selection.
All six methods are the same prespecified subset used by competitive_accuracy.
The source audit retains every one of the nine methods and all configurations.
"""
from pathlib import Path
import hashlib
import json
import platform

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "results/revision38_multimetric_summary.json"
PLAN = ROOT / "results/revision38_evaluation_plan.json"
FIGURES = ROOT / "figures"
METHODS = ["Trim-SCAD", "Trim-MCP", "Trim-Lasso", "VRMOM-SCAD",
           "NoCorrection-SCAD", "T-SLARD-ZF"]
DISPLAY = {"NoCorrection-SCAD": "Uncorrected SCAD"}
# Color, marker, and line style are redundant encodings for print accessibility.
STYLES = {
    "Trim-SCAD": ("#0072B2", "o", "-"),
    "Trim-MCP": ("#D55E00", "s", "--"),
    "Trim-Lasso": ("#333333", "^", ":"),
    "VRMOM-SCAD": ("#009E73", "D", "-."),
    "NoCorrection-SCAD": ("#CC79A7", "v", "--"),
    "T-SLARD-ZF": ("#E69F00", "X", ":"),
}
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.5,
    "axes.labelsize": 9.5, "axes.titlesize": 9.5,
    "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
    "legend.fontsize": 9.5, "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.7, "lines.linewidth": 1.4,
    "savefig.facecolor": "white", "figure.facecolor": "white",
})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def axes_style(ax):
    ax.grid(axis="y", color="#D9D9D9", lw=0.6, alpha=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, width=0.6)


def legend(fig, y):
    handles = [Line2D([], [], color=STYLES[m][0], marker=STYLES[m][1],
                      ls=STYLES[m][2], markerfacecolor="white", markersize=4.5,
                      label=DISPLAY.get(m, m)) for m in METHODS]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, y), columnspacing=1.1,
               handlelength=2.3, handletextpad=0.5)


def save(fig, stem, payload):
    fig.savefig(FIGURES / f"{stem}.pdf")
    fig.savefig(FIGURES / f"{stem}.png", dpi=240)
    plt.close(fig)
    payload.update({
        "source": SOURCE.relative_to(ROOT).as_posix(),
        "source_sha256": digest(SOURCE),
        "evaluation_plan": PLAN.relative_to(ROOT).as_posix(),
        "evaluation_plan_sha256": digest(PLAN),
        "script_sha256": digest(Path(__file__)),
        "python": platform.python_version(), "numpy": np.__version__,
        "matplotlib": matplotlib.__version__, "methods": METHODS,
        "outputs": {ext: digest(FIGURES / f"{stem}.{ext}")
                    for ext in ("pdf", "png")},
    })
    (FIGURES / f"{stem}_provenance.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(stem, "saved", flush=True)


def sample_size(data):
    index = {(r["study"], r["configuration"], r["method"]): r
             for r in data["metric_summary"]}
    fig, axes = plt.subplots(2, 2, figsize=(5.55, 4.9), sharex=True,
                             sharey="row")
    fig.subplots_adjust(left=0.135, right=0.985, bottom=0.235, top=0.92,
                        hspace=0.24, wspace=0.18)
    selected = []
    metrics = ["l2", "population_prediction_excess"]
    x = np.array([30, 50, 70])
    for col, (attack, title) in enumerate([
            ("gaussian", "Gaussian attack"), ("stealth", "In-range attack")]):
        axes[0, col].set_title(title)
        for row, metric in enumerate(metrics):
            ax = axes[row, col]
            for order, method in enumerate(METHODS):
                records = [index[("sample_size", f"ss_q{q:.1f}_{attack}", method)]
                           for q in [0.7, 0.5, 0.3]]
                assert all(r["planned"] == r["success"] == 30 for r in records)
                y = np.array([r[metric]["mean"] for r in records])
                se = np.array([r[metric]["mcse"] for r in records])
                assert np.all(y - se > 0)
                color, marker, line = STYLES[method]
                ax.errorbar(x, y, yerr=se, color=color, marker=marker,
                            linestyle=line, markersize=4.5, markerfacecolor="white",
                            markeredgewidth=1.0, capsize=2.1, elinewidth=0.8,
                            zorder=10-order)
                selected.extend({"configuration": r["configuration"],
                                 "method": method, "metric": metric,
                                 "planned": r["planned"], "success": r["success"],
                                 **r[metric]} for r in records)
            ax.set_yscale("log")
            # Leave room for the four-digit sample-size labels at both ends.
            ax.set_xlim(20, 80)
            ax.set_xticks(x, ["30%\n$n_j=512$", "50%\n$n_j=1004$",
                               "70%\n$n_j=2788$"])
            axes_style(ax)
            ax.yaxis.set_minor_locator(NullLocator())
            if row == 0:
                ax.set_ylim(0.11, 1.95)
                ax.yaxis.set_major_locator(FixedLocator([0.1, 0.2, 0.5, 1.0]))
            else:
                ax.set_ylim(0.008, 3.7)
                ax.yaxis.set_major_locator(FixedLocator([0.01, 0.05, 0.2, 1.0, 3.0]))
            ax.yaxis.set_major_formatter(FuncFormatter(lambda v, pos: f"{v:g}"))
            ax.text(0.03, 0.96, f"({chr(97+row*2+col)})", transform=ax.transAxes,
                    va="top", ha="left", fontsize=9.5)
    axes[0, 0].set_ylabel("Coefficient error (log scale)")
    axes[1, 0].set_ylabel("Prediction excess (log scale)")
    fig.text(0.555, 0.123, "Missing covariates and local sample size", ha="center")
    legend(fig, 0.005)
    save(fig, "revision38_sample_size", {
        "description": "Complete six-cell existing sample-size follow-up, new seeds per design.",
        "dimensions_inches": [5.55, 4.9], "minimum_font_points": 9.5,
        "sample_rule": "n_j=ceil(512*(0.7/q)^2), q in {0.7,0.5,0.3}",
        "points": "Means over all 30 successful selected fits in each displayed cell",
        "bars": "One Monte Carlo SE across independent repetitions, not paired difference intervals",
        "prediction_excess": "(theta_hat-theta_true)^T Sigma (theta_hat-theta_true)",
        "axis_policy": "Logarithmic shared y scale within metric, labeled; no x jitter",
        "plotted_cells": selected,
    })


def thresholds(data):
    index = {(r["study"], r["configuration"], r["method"], r["threshold"]): r
             for r in data["threshold_summary"]}
    thresholds = data["thresholds"]
    assert thresholds == [1e-6, 1e-4, 1e-3, 1e-2, .025, .05, .1, .2, .4, .6]
    fig, axes = plt.subplots(2, 2, figsize=(5.55, 4.95), sharex=True, sharey=True)
    fig.subplots_adjust(left=0.12, right=0.985, bottom=0.22, top=0.925,
                        hspace=0.24, wspace=0.17)
    selected = []
    for row, q in enumerate([0.7, 0.5]):
        for col, (attack, title) in enumerate([
                ("gaussian", "Gaussian attack"), ("stealth", "In-range attack")]):
            ax = axes[row, col]
            if row == 0:
                ax.set_title(title)
            config = f"q{q:.1f}_f2_{attack}"
            for order, method in enumerate(METHODS):
                records = [index[("primary", config, method, t)] for t in thresholds]
                assert all(r["planned"] == r["exact_all_n"] == 30 for r in records)
                means = [r["exact_all_mean"] for r in records]
                color, marker, line = STYLES[method]
                ax.plot(thresholds, means, color=color, marker=marker,
                        linestyle=line, markersize=4.1, markerfacecolor="white",
                        markeredgewidth=0.9, zorder=10-order)
                selected.extend({"configuration": config, "method": method,
                                 "threshold": r["threshold"], "exact_count": r["exact_count"],
                                 "planned": r["planned"], "success": r["success"],
                                 "mean": r["exact_all_mean"], "mcse": r["exact_all_mcse"]}
                                for r in records)
            ax.set_xscale("log")
            ax.set_xlim(6e-7, 1.0)
            ax.set_xticks([1e-6, 1e-4, 1e-2, 1e-1, .6],
                          [r"$10^{-6}$", r"$10^{-4}$", r"$10^{-2}$", "0.1", "0.6"])
            ax.xaxis.set_minor_locator(NullLocator())
            ax.set_ylim(-.045, 1.075)
            ax.set_yticks([0, .25, .5, .75, 1.0], ["0", ".25", ".50", ".75", "1"])
            axes_style(ax)
            ax.text(.03, .06, f"({chr(97+row*2+col)}) {100*(1-q):.0f}% missing",
                    transform=ax.transAxes, va="bottom", fontsize=9.5,
                    bbox=dict(facecolor="white", edgecolor="none", alpha=.85, pad=1.5))
    axes[0, 0].set_ylabel("Exact-support proportion")
    axes[1, 0].set_ylabel("Exact-support proportion")
    fig.text(.55, .118, "Support threshold (log scale)", ha="center")
    legend(fig, .005)
    save(fig, "revision38_support_thresholds", {
        "description": "Common support-threshold sensitivity in four primary joint-contamination cells.",
        "dimensions_inches": [5.55, 4.95], "minimum_font_points": 9.5,
        "n_j": 512, "m": 12, "p": 256, "byzantine_nodes": 2,
        "thresholds": thresholds,
        "evaluation_only": "Thresholds assess saved coefficients; no refitting, no selected best threshold, no changed predictions.",
        "denominator": "All 30 planned repetitions; failed fits scored as unsuccessful exact support recovery",
        "uncertainty": "Point curves only; all cell MCSEs retained in provenance and source CSV",
        "axis_policy": "Logarithmic threshold axis, all ten values plotted; common probability y scale; no jitter",
        "plotted_cells": selected,
    })


if __name__ == "__main__":
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    assert data["checks"]["inputs_unchanged"]
    assert data["checks"]["original_metric_recomputations_pass"]
    sample_size(data)
    thresholds(data)
