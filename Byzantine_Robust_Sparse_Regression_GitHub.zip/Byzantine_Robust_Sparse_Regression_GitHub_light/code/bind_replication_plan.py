"""Bind the unchanged evaluation design to complete results of a fresh run."""
import copy
import json
from datetime import datetime, timezone
from repository_io import ROOT, digest

VOLATILE = {'created_utc', 'numpy', 'python', 'platform', 'primary_plan_sha256'}

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def validate_records(stem):
    current = read_json(ROOT / 'results' / (stem + '_plan.json'))
    reference = read_json(ROOT / 'reference' / (stem + '_plan.json'))
    fixed = lambda plan: {key: value for key, value in plan.items() if key not in VOLATILE}
    if fixed(current) != fixed(reference):
        raise ValueError('Experimental protocol differs from the archived design: ' + stem)
    configs = {entry['label']: entry for entry in current['configurations']}
    expected = {(label, seed, method['name']) for label in configs
                for seed in current['seeds'] for method in current['methods']}
    seen = set()
    raw = ROOT / 'results' / (stem + '.jsonl')
    with raw.open(encoding='utf-8') as stream:
        for line in stream:
            row = json.loads(line)
            key = (row['configuration']['label'], row['seed'], row['method'])
            if key not in expected or key in seen or row['configuration'] != configs[key[0]]:
                raise ValueError('Unexpected/duplicate record or configuration: ' + str(key))
            seen.add(key)
    if seen != expected:
        raise ValueError(f'Incomplete {stem}: {len(seen)} of {len(expected)} records')
    return len(seen)

def main():
    marker = ROOT / 'RUN_WORKSPACE.json'
    if not marker.is_file() or read_json(marker).get('study') != 'all':
        raise SystemExit('Run this only in a fresh workspace created with study all.')
    template_path = ROOT / 'reference/revision38_evaluation_plan.json'
    template = read_json(template_path)
    for name, expected in template['immutable_sources'].items():
        if name.startswith('code/') and digest(ROOT / name) != expected:
            raise ValueError('Frozen scientific code changed: ' + name)
    sample_plan = read_json(ROOT / 'results/competitive_sample_size_plan.json')
    if sample_plan['primary_plan_sha256'] != digest(ROOT / 'results/competitive_full_plan.json'):
        raise ValueError('The follow-up does not reference this primary run plan.')
    sample_script = ROOT / 'code/competitive_sample_size.py'
    if digest(sample_script) != sample_plan['script_sha256']:
        raise ValueError('The follow-up runner differs from its recorded source.')
    counts = {stem: validate_records(stem) for stem in ('competitive_full', 'competitive_sample_size')}
    current_hashes = {name: digest(ROOT / name) for name in template['immutable_sources']}
    target = ROOT / 'results/revision38_evaluation_plan.json'
    if target.exists():
        existing = read_json(target)
        provenance = existing.get('replication_provenance', {})
        if (existing.get('immutable_sources') == current_hashes
                and provenance.get('template_sha256') == digest(template_path)):
            print('Existing replication plan verified; nothing changed.')
            return
        raise FileExistsError('An evaluation plan already exists with different provenance; it was not overwritten.')
    for path in (ROOT / 'results').glob('competitive_process_cost*'):
        raise FileExistsError('Bind the plan before starting any cost-study execution: ' + str(path))
    bound = copy.deepcopy(template)
    bound['immutable_sources'] = current_hashes
    bound['replication_provenance'] = {
        'bound_utc': datetime.now(timezone.utc).isoformat(),
        'template_sha256': digest(template_path), 'complete_record_counts': counts,
        'scope': 'Fresh execution results. Original design, seeds, grids and thresholds unchanged.',
        'archived_source_hashes': template['immutable_sources'],
    }
    with target.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(bound, indent=2) + '\n')
    print(json.dumps({'replication_plan': str(target), 'complete_record_counts': counts}, indent=2))

if __name__ == '__main__':
    main()
