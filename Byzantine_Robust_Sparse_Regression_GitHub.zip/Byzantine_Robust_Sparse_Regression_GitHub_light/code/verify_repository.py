"""Verify the included files; large generated raw records are not included."""
import json
from repository_io import ROOT, safe_path, digest

def main():
    manifest = json.loads((ROOT / 'REPOSITORY_MANIFEST.json').read_text(encoding='utf-8'))
    for name, item in manifest['files'].items():
        path = safe_path(name)
        if not path.is_file() or path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
            raise SystemExit('Distribution file mismatch: ' + name)
    omitted = json.loads((ROOT / 'provenance/omitted_results.json').read_text(encoding='utf-8'))
    print(json.dumps({'included_files_verified': len(manifest['files']),
                      'generated_raw_files_not_included': len(omitted['files']),
                      'scope': 'File integrity only; no model fitting or theorem verification.'}, indent=2))

if __name__ == '__main__':
    main()
