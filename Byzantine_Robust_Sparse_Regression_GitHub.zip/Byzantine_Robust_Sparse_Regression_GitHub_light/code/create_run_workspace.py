"""Create an empty experimental workspace, leaving archived results untouched."""
import argparse
import json
import shutil
from pathlib import Path
from repository_io import ROOT

PLANS = ('competitive_full_plan.json', 'competitive_sample_size_plan.json',
         'revision38_evaluation_plan.json')
AUDIT_INPUTS = ('competitive_pilot_plan.json', 'competitive_core_equivalence_fullgrid.json')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('study', choices=['all', 'primary', 'sample_size'])
    parser.add_argument('--destination', type=Path)
    args = parser.parse_args()
    dest = (args.destination or ROOT / 'runs' / args.study).resolve()
    if dest.exists():
        raise SystemExit('Destination already exists; nothing changed: ' + str(dest))
    if any(dest.is_relative_to((ROOT / name).resolve()) for name in ('code', 'data')):
        raise SystemExit('Choose a destination outside code and data source directories.')
    for name in PLANS + AUDIT_INPUTS:
        if not (ROOT / 'results' / name).is_file():
            raise SystemExit('Create workspaces from the original lightweight repository root.')
    dest.mkdir(parents=True)
    shutil.copytree(ROOT / 'code', dest / 'code', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copytree(ROOT / 'data', dest / 'data')
    for folder in ('results', 'figures', 'reference'):
        (dest / folder).mkdir()
    for name in PLANS:
        shutil.copy2(ROOT / 'results' / name, dest / 'reference' / name)
    for name in AUDIT_INPUTS:
        shutil.copy2(ROOT / 'results' / name, dest / 'results' / name)
    if args.study == 'sample_size':
        shutil.copy2(ROOT / 'results' / PLANS[0], dest / 'results' / PLANS[0])
    for path in ROOT.glob('requirements*.txt'):
        shutil.copy2(path, dest / path.name)
    commands = {
        'primary': ['python code/competitive_benchmark.py --mode full --repeats 30'],
        'sample_size': ['python code/competitive_sample_size.py'],
        'all': ['python code/competitive_benchmark.py --mode full --repeats 30',
                'python code/competitive_sample_size.py',
                'python code/bind_replication_plan.py',
                'python code/competitive_process_cost.py --pilot',
                'python code/competitive_process_cost.py --run'],
    }[args.study]
    (dest / 'RUN_WORKSPACE.json').write_text(json.dumps({
        'study': args.study, 'commands': commands,
        'archived_audit_inputs': list(AUDIT_INPUTS),
        'note': 'Fresh execution directory. Reference plans are archived designs, not new outcomes.'
    }, indent=2) + '\n', encoding='utf-8')
    print('Created ' + str(dest) + '\nRun in that directory:\n' + '\n'.join(commands))

if __name__ == '__main__':
    main()
