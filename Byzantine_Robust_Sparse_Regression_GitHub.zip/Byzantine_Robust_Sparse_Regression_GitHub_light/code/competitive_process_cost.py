"""Frozen-plan, paired single-host process cost for complete validation tuning.

Only --pilot runs the independent correctness/feasibility seed. --run runs the
prespecified main seeds; neither mode overwrites prior output. Use --resume for
an interrupted run with exactly matching plan, sources and numerical versions.
Core fitting, penalty grid and attack rules are imported without modification.
"""
from __future__ import annotations

import os
for _name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_name] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import platform
import struct
import time
import traceback

import numpy as np
import scipy
import competitive_benchmark as benchmark
import robust_sparse as core


ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / "results/revision38_evaluation_plan.json"
ORDER_SALT = 381026
EQUIVALENCE_TOLERANCE = 1e-10


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def worker(connection, z, y, q):
    """Hold raw observations; rebuild moments separately for every method."""
    try:
        with benchmark.threadpool_limits(limits=1):
            node = None
            connection.send_bytes(b"R")
            while True:
                message = connection.recv_bytes()
                command = message[:1]
                if command in (b"C", b"Z"):
                    started = time.perf_counter()
                    node = core.Node(z, y, q if command == b"C" else 1., dense=True)
                    connection.send_bytes(b"B" + struct.pack("!d", time.perf_counter() - started))
                elif command == b"G":
                    if node is None:
                        raise RuntimeError("Gradient requested before moment construction")
                    x = np.frombuffer(message, dtype=np.float64, offset=1)
                    connection.send_bytes(b"G" + node.grad(x).tobytes())
                elif command == b"S":
                    connection.send_bytes(b"S")
                    break
                else:
                    raise ValueError("Unknown worker command")
    except BaseException:
        try:
            connection.send_bytes(b"E" + traceback.format_exc().encode("utf-8"))
        except (BrokenPipeError, EOFError, OSError):
            pass
        raise
    finally:
        connection.close()


class WorkerPool:
    def __init__(self, raw_nodes, q):
        self.connections, self.processes = [], []
        self.p = raw_nodes[0].p
        started = time.perf_counter()
        context = mp.get_context("spawn")
        try:
            for node in raw_nodes[1:]:
                parent, child = context.Pipe(duplex=True)
                process = context.Process(target=worker, args=(child, node.z, node.y, q))
                process.start()
                child.close()
                self.connections.append(parent)
                self.processes.append(process)
            for connection in self.connections:
                if self.receive(connection) != b"R":
                    raise RuntimeError("Worker did not report ready")
        except BaseException:
            self.close(force=True)
            raise
        self.startup_seconds = time.perf_counter() - started
        self.raw_worker_array_bytes = sum(node.z.nbytes + node.y.nbytes for node in raw_nodes[1:])

    @staticmethod
    def receive(connection):
        if not connection.poll(120):
            raise TimeoutError("Worker response timed out after 120 seconds")
        message = connection.recv_bytes()
        if message[:1] == b"E":
            raise RuntimeError(message[1:].decode("utf-8", errors="replace"))
        return message

    def rebuild(self, correction):
        command = b"C" if correction else b"Z"
        for connection in self.connections:
            connection.send_bytes(command)

    def finish_rebuild(self):
        durations = []
        for connection in self.connections:
            response = self.receive(connection)
            if response[:1] != b"B" or len(response) != 9:
                raise RuntimeError("Invalid moment-construction response")
            durations.append(struct.unpack("!d", response[1:])[0])
        return durations

    def gradients(self, master, x):
        # Send all requests before any receive; real float64 coefficient and
        # gradient buffers traverse every worker pipe, including corrupt nodes.
        coefficients = np.asarray(x, dtype=np.float64).tobytes()
        request = b"G" + coefficients
        for connection in self.connections:
            connection.send_bytes(request)
        local = master.grad(x)
        received = []
        vector_bytes = len(coefficients) * len(self.connections)
        control_bytes = len(self.connections)
        for connection in self.connections:
            response = self.receive(connection)
            if response[:1] != b"G" or len(response) != 1 + 8 * self.p:
                raise RuntimeError("Invalid gradient response")
            vector_bytes += len(response) - 1
            control_bytes += 1
            received.append(np.frombuffer(response, dtype=np.float64, offset=1))
        return np.array([local, *received]), vector_bytes, control_bytes

    def close(self, force=False):
        if not force:
            try:
                for connection in self.connections:
                    connection.send_bytes(b"S")
                for connection in self.connections:
                    if self.receive(connection) != b"S":
                        raise RuntimeError("Invalid shutdown response")
            except (BrokenPipeError, EOFError, OSError, RuntimeError, TimeoutError):
                force = True
        for connection in self.connections:
            connection.close()
        for process in self.processes:
            if force and process.is_alive():
                process.terminate()
            process.join(timeout=30)
            if process.is_alive():
                process.terminate()
                process.join(timeout=10)
            if not force and process.exitcode != 0:
                raise RuntimeError(f"Worker exited with code {process.exitcode}")


def candidate_fit(pool, master, scale, factor, method, cf, seed, direction, rounds):
    """The exact traced_fit updates, with pipe gradients and no truth scoring."""
    _, aggregation, penalty, _ = method
    started = time.perf_counter()
    x, local, initial = core.initial(master, scale, factor)
    initialization_seconds = time.perf_counter() - started
    x = x.copy()
    coefficients = [x.copy()]
    trace, round_costs = [], []
    vector_bytes = control_bytes = 0
    if initial["status"] != "ok":
        return x, dict(status="initial_failed", initial=initial, trace=trace,
                       initialization_seconds=initialization_seconds,
                       round_costs=round_costs, vector_payload_bytes=0,
                       control_payload_bytes=0), coefficients
    m, p = cf["m"], master.p
    floor = factor * scale * (np.sqrt(np.log(p) / (m * master.n))
                             + (cf["b"] / m) * np.sqrt(np.log(p) / master.n))
    for t in range(rounds):
        tick = time.perf_counter()
        raw, payload, controls = pool.gradients(master, x)
        communication_gradient_seconds = time.perf_counter() - tick
        vector_bytes += payload
        control_bytes += controls
        tick = time.perf_counter()
        sent = core.attack(raw, cf["f"], cf["attack"], t, seed, direction)
        sd = master.score_sd(x) if aggregation == "vrmom" else None
        aggregate = core.aggregate(sent, aggregation, cf["b"], sd, master.n)
        c = master.mv(x) - aggregate
        aggregation_seconds = time.perf_counter() - tick
        target = max(floor, local * .65 ** (t + 1))
        base = max(target, local * .65 ** t)
        tick = time.perf_counter()
        x, info = core.homotopy(master, c, x, core.penalty_weights(x, base, penalty), base, target)
        inner_seconds = time.perf_counter() - tick
        trace.append(dict(info, lambda_value=float(target)))
        coefficients.append(x.copy())
        round_costs.append(dict(round=t + 1, vector_payload_bytes=payload,
                                control_payload_bytes=controls,
                                communication_gradient_seconds=communication_gradient_seconds,
                                aggregation_seconds=aggregation_seconds, inner_seconds=inner_seconds))
        if info["status"] != "ok":
            break
    return x, dict(status=trace[-1]["status"], initial=initial, trace=trace,
                   initialization_seconds=initialization_seconds, round_costs=round_costs,
                   vector_payload_bytes=vector_bytes, control_payload_bytes=control_bytes), coefficients


def process_fit(pool, cf, seed, method, dataset, design):
    corrected, _, xv, yv, xt, yt, theta, direction, covariance, _ = dataset
    name, _, _, correction = method
    # The full-tuning clock starts before any method-specific moments exist.
    started = time.perf_counter()
    pool.rebuild(correction)
    master_start = time.perf_counter()
    master = core.Node(corrected[0].z, corrected[0].y, cf["q"] if correction else 1., dense=True)
    master_moment_seconds = time.perf_counter() - master_start
    worker_moment_seconds = pool.finish_rebuild()
    moment_seconds = time.perf_counter() - started
    scale = float(np.std(master.y, ddof=1) / (cf["q"] if correction else 1.))
    candidates, stored = [], []
    for factor in design["grid"]:
        candidate_start = time.perf_counter()
        x, info, coefficients = candidate_fit(pool, master, scale, factor, method, cf, seed,
                                               direction, design["rounds"])
        fitting_seconds = time.perf_counter() - candidate_start
        validation = float(np.mean((yv - xv @ x) ** 2)) if info["status"] == "ok" else None
        seconds = time.perf_counter() - candidate_start
        candidates.append(dict(factor=factor, validation_mse=validation, seconds=seconds,
                               fitting_seconds=fitting_seconds, communication_rounds=len(info["trace"]),
                               total_updates=info["initial"].get("iterations", 0) + sum(z["iterations"] for z in info["trace"]),
                               total_stages=info["initial"].get("stages", 0) + sum(z.get("stages", 0) for z in info["trace"]), **info))
        stored.append((x, coefficients))
    selection_start = time.perf_counter()
    eligible = [i for i, candidate in enumerate(candidates) if candidate["status"] == "ok"]
    selected = min(eligible, key=lambda i: candidates[i]["validation_mse"]) if eligible else None
    selection_seconds = time.perf_counter() - selection_start
    full_seconds = time.perf_counter() - started
    # Everything depending on truth, all test evaluation and JSON preparation
    # happen after this clock stops. Truth never changes any fitting decision.
    evaluation_start = time.perf_counter()
    for candidate, (x, coefficients) in zip(candidates, stored):
        candidate["coefficient"] = x.tolist()
        candidate["outer_coefficients"] = [value.tolist() for value in coefficients]
        candidate["path"] = [dict(round=t, **benchmark.metric(value, theta)) for t, value in enumerate(coefficients)]
        candidate["final_diagnostic"] = benchmark.metric(x, theta)
        expected = 16 * (cf["m"] - 1) * cf["p"] * candidate["communication_rounds"]
        if candidate["vector_payload_bytes"] != expected:
            raise AssertionError("Actual vector payload disagrees with completed round count")
    result = dict(method=name, scale=scale, candidates=candidates, selected_index=selected,
                  candidate_successes=len(eligible), status="ok" if eligible else "all_candidates_failed",
                  full_tuning_seconds=full_seconds, moment_construction_seconds=moment_seconds,
                  master_moment_seconds=master_moment_seconds, worker_moment_seconds=worker_moment_seconds,
                  selection_seconds=selection_seconds,
                  total_search_seconds=sum(z["seconds"] for z in candidates),
                  total_search_updates=sum(z["total_updates"] for z in candidates),
                  total_search_stages=sum(z["total_stages"] for z in candidates),
                  total_search_rounds=sum(z["communication_rounds"] for z in candidates),
                  total_vector_payload_bytes=sum(z["vector_payload_bytes"] for z in candidates),
                  total_control_payload_bytes=10 * (cf["m"] - 1) + sum(z["control_payload_bytes"] for z in candidates),
                  final_target_attainment={str(target): False for target in (.1, .2, .5)})
    if selected is not None:
        x, coefficients = stored[selected]
        delta = x - theta
        metrics = benchmark.metric(x, theta)
        result.update(metrics, factor=candidates[selected]["factor"],
                      coefficient=x.tolist(), outer_coefficients=[value.tolist() for value in coefficients],
                      path=candidates[selected]["path"], validation_mse=candidates[selected]["validation_mse"],
                      test_mse=float(np.mean((yt - xt @ x) ** 2)),
                      population_prediction_excess=float(delta @ covariance @ delta),
                      final_lambda=candidates[selected]["trace"][-1]["lambda_value"],
                      grid_edge=selected in (0, len(design["grid"]) - 1),
                      final_target_attainment={str(target): metrics["l2"] <= target for target in (.1, .2, .5)})
    result["post_tuning_evaluation_seconds"] = time.perf_counter() - evaluation_start
    return result


def equivalent(process, serial):
    statuses = [c["status"] for c in process["candidates"]] == [c["status"] for c in serial["candidates"]]
    validation_errors = [abs(a["validation_mse"] - b["validation_mse"])
                         for a, b in zip(process["candidates"], serial["candidates"])
                         if a["validation_mse"] is not None and b["validation_mse"] is not None]
    coefficient_error = 0.
    if process["status"] == serial["status"] == "ok":
        coefficient_error = float(np.max(np.abs(np.asarray(process["coefficient"]) - serial["coefficient"])))
    selection = process["status"] == serial["status"] and process["selected_index"] == serial["selected_index"]
    paths = all(a["trace"] == b["trace"] and a["initial"] == b["initial"]
                for a, b in zip(process["candidates"], serial["candidates"]))
    return dict(passed=statuses and selection and coefficient_error <= EQUIVALENCE_TOLERANCE
                and max(validation_errors, default=0.) <= EQUIVALENCE_TOLERANCE and paths,
                candidate_statuses_equal=statuses, selected_status_and_index_equal=selection,
                all_initial_and_stage_records_exactly_equal=paths,
                selected_max_abs_coefficient_difference=coefficient_error,
                max_abs_validation_mse_difference=max(validation_errors, default=0.),
                tolerance=EQUIVALENCE_TOLERANCE)


def protocol(mode):
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    design = plan["cost_design"]
    for name, expected in plan["immutable_sources"].items():
        if digest(ROOT / name) != expected:
            raise RuntimeError("Frozen source changed: " + name)
    assert design["grid"] == benchmark.GRID and design["rounds"] == 8 and design["thread_limit"] == 1
    assert design["validation_n"] == 400 and design["test_n"] == 2000
    methods = [next(method for method in benchmark.METHODS if method[0] == name) for name in design["methods"]]
    configurations = []
    for q in design["q"]:
        for attack in design["attacks"]:
            matches = [cf for cf in benchmark.configurations() if cf["q"] == q and cf["attack"] == attack
                       and cf["f"] == design["f"] and cf["b"] == design["b"]
                       and cf["m"] == design["m"] and cf["n"] == design["n"] and cf["p"] == design["p"]
                       and cf["rho"] == design["correlation"] and cf["layout"] == design["signal_layout"]]
            assert len(matches) == 1
            configurations.append(matches[0])
    seeds = design["pilot_seeds"] if mode == "pilot" else design["seeds"]
    assert not set(design["pilot_seeds"]).intersection(design["seeds"])
    metadata = dict(mode=mode, plan_path=PLAN.relative_to(ROOT).as_posix(), plan_sha256=digest(PLAN),
                    script_sha256=digest(__file__), core_sha256=digest(ROOT / "code/robust_sparse.py"),
                    benchmark_sha256=digest(ROOT / "code/competitive_benchmark.py"),
                    python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                    platform=platform.platform(), logical_cpus=os.cpu_count(), thread_limit=1,
                    design=design, configurations=configurations, seeds=seeds, methods=[list(x) for x in methods],
                    order_salt=ORDER_SALT, expected_records=len(configurations) * len(seeds) * len(methods),
                    expected_candidates=len(configurations) * len(seeds) * len(methods) * len(design["grid"]),
                    timing_scope="Per-method parallel moment rebuilding, every candidate initialization/solve/gradient exchange, validation and selection. Excludes shared dataset preparation, process startup, post-tuning truth/test evaluation and serialization.",
                    preparation_scope="benchmark.make_data includes raw generation, reference corrected/zero-filled moments and spectrum metadata. It is reported separately; every timed method rebuilds its own moments.",
                    communication_scope="Actual float64 coefficient/gradient buffer bytes, for all completed rounds of all candidates including failures. Control-command/status/timer payloads counted separately. OS pipe framing/pickle startup overhead is not measured or included.",
                    setup_scope="Shared process startup/raw-array transfer and ready handshake. Raw array bytes are size accounting, not a measurement of pickle/framing overhead.",
                    target_scope="Final selected coefficient only, evaluated after complete validation tuning; no truth-based stopping or candidate selection.")
    return design, configurations, seeds, methods, metadata


def run(mode, resume):
    design, configurations, seeds, methods, metadata = protocol(mode)
    if mode == "run":
        pilot_execution = ROOT / "results/competitive_process_cost_pilot_execution.json"
        if not pilot_execution.is_file():
            raise RuntimeError("Run the independent pilot successfully before the main study")
        pilot = json.loads(pilot_execution.read_text(encoding="utf-8"))
        if not pilot.get("complete") or pilot.get("script_sha256") != metadata["script_sha256"] or pilot.get("plan_sha256") != metadata["plan_sha256"]:
            raise RuntimeError("Main study requires a complete pilot with identical plan and script")
    stem = "competitive_process_cost_pilot" if mode == "pilot" else "competitive_process_cost"
    output = ROOT / "results" / (stem + ".jsonl")
    manifest = ROOT / "results" / (stem + "_metadata.json")
    execution = ROOT / "results" / (stem + "_execution.json")
    if manifest.exists():
        if not resume:
            raise FileExistsError(f"{manifest}: use --resume with the same frozen protocol")
        if json.loads(manifest.read_text(encoding="utf-8")) != metadata:
            raise RuntimeError("Resume protocol/source/environment mismatch")
    else:
        if output.exists() or execution.exists():
            raise FileExistsError("Results exist without their frozen metadata")
        manifest.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    expected = {(cf["label"], seed, method[0]) for cf in configurations for seed in seeds for method in methods}
    done = set()
    if output.exists():
        with output.open(encoding="utf-8") as stream:
            for line in stream:
                row = json.loads(line)
                key = (row["configuration"]["label"], row["seed"], row["method"])
                if key not in expected or key in done or row["plan_sha256"] != metadata["plan_sha256"] or row["script_sha256"] != metadata["script_sha256"]:
                    raise RuntimeError("Invalid, duplicate or mismatched prior record")
                if mode == "pilot" and not row["serial_equivalence"]["passed"]:
                    raise RuntimeError("A failed pilot cannot be silently resumed")
                done.add(key)
    started = time.perf_counter()
    invocation_records = 0
    with output.open("a", encoding="utf-8") as stream:
        for ci, cf in enumerate(configurations):
            for rep, seed in enumerate(seeds):
                if all((cf["label"], seed, method[0]) in done for method in methods):
                    continue
                preparation_start = time.perf_counter()
                dataset = benchmark.make_data(cf, seed)
                preparation_seconds = time.perf_counter() - preparation_start
                pool = WorkerPool(dataset[0], cf["q"])
                order = np.random.default_rng(np.random.SeedSequence([seed, ci, ORDER_SALT])).permutation(len(methods))
                try:
                    for execution_order, mi in enumerate(order):
                        method = methods[mi]
                        key = (cf["label"], seed, method[0])
                        if key in done:
                            continue
                        record = process_fit(pool, cf, seed, method, dataset, design)
                        if mode == "pilot":
                            equivalence_start = time.perf_counter()
                            serial = benchmark.fit_method(cf, seed, method, dataset)
                            record["serial_equivalence"] = equivalent(record, serial)
                            record["pilot_serial_reference_and_equivalence_seconds"] = time.perf_counter() - equivalence_start
                        row = dict(mode=mode, configuration=cf, seed=seed, rep=rep,
                                   execution_order=int(execution_order), dataset=dataset[-1],
                                   dataset_preparation_seconds=preparation_seconds,
                                   shared_pool_startup_seconds=pool.startup_seconds,
                                   shared_worker_raw_array_bytes=pool.raw_worker_array_bytes,
                                   shared_startup_shutdown_control_bytes=3 * (cf["m"] - 1),
                                   plan_sha256=metadata["plan_sha256"], script_sha256=metadata["script_sha256"], **record)
                        stream.write(json.dumps(benchmark.clean(row), separators=(",", ":")) + "\n")
                        stream.flush()
                        done.add(key)
                        invocation_records += 1
                        if mode == "pilot" and not record["serial_equivalence"]["passed"]:
                            raise AssertionError(json.dumps(record["serial_equivalence"]))
                        print(json.dumps(dict(mode=mode, configuration=cf["label"], seed=seed,
                                              method=method[0], full_tuning_seconds=record["full_tuning_seconds"],
                                              status=record["status"], completed_records=len(done))), flush=True)
                finally:
                    pool.close()
    report = dict(completed_utc=datetime.now(timezone.utc).isoformat(), mode=mode,
                  expected_records=len(expected), records=len(done), complete=done == expected,
                  invocation_records=invocation_records, invocation_elapsed_seconds=time.perf_counter() - started,
                  output_sha256=digest(output), plan_sha256=metadata["plan_sha256"],
                  script_sha256=metadata["script_sha256"], output_bytes=output.stat().st_size)
    execution.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--pilot", action="store_true", help="Only the independent correctness/feasibility seed")
    mode.add_argument("--run", action="store_true", help="All prespecified main seeds")
    parser.add_argument("--resume", action="store_true", help="Continue identical, incomplete output without overwriting")
    args = parser.parse_args()
    with benchmark.threadpool_limits(limits=1):
        run("pilot" if args.pilot else "run", args.resume)
