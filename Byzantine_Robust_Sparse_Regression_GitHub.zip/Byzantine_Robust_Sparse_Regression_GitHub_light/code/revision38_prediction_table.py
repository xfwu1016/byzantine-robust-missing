"""Summarize paired test errors from frozen reanalysis; no fitting."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'results/revision38_multimetric_summary.json').read_text())
lines=[r'\begin{table}[H]',r'\caption{Paired test-MSE differences, Trim-SCAD minus each comparator. Entries are means with one Monte Carlo standard error in parentheses; each uses 30 jointly successful repetitions. Negative differences favor Trim-SCAD. The follow-up uses new seeds.}\label{tab:prediction38}',r'\centering\compacttable\setlength{\tabcolsep}{3pt}',r'\begin{tabular}{rllrrr}\toprule',r'$q$ & $n_j$ & Attack & Trim-Lasso & VRMOM-SCAD & T-SLARD-ZF\\\midrule']
for study,title,qs in [('primary','Fixed local sample size',[.7,.5]),('sample_size','Sample-size follow-up',[.7,.5,.3])]:
    lines.append(r'\multicolumn{6}{l}{\textit{'+title+r'}}\\')
    for q in qs:
        for attack,label in [('gaussian','Gaussian'),('stealth','In-range')]:
            config=(f'q{q}_f2_' if study=='primary' else f'ss_q{q}_')+attack
            n=next(x['n'] for x in d['configuration_order'] if x['study']==study and x['label']==config)
            vals=[]
            for comparator in ['Trim-Lasso','VRMOM-SCAD','T-SLARD-ZF']:
                r=next(x for x in d['paired'] if x['study']==study and x['configuration']==config and x['proposed']=='Trim-SCAD' and x['comparator']==comparator and x['metric']=='test_mse')
                assert r['n']==30
                vals.append(f"${r['mean']:.4f}$ ({r['mcse']:.4f})")
            lines.append(f'{q:.1f} & {n} & '+label+' & '+' & '.join(vals)+r'\\')
lines += [r'\bottomrule\end{tabular}',r'\end{table}']
(root/'results/revision38_prediction_table.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
