"""Frozen-data multimetric audit; no fitting, retuning, or threshold selection.

Uses only saved validation-selected coefficients and outcomes. The ten common
support thresholds are read from revision38_evaluation_plan.json. Population
prediction excess is independently recomputed for the stated AR(1) covariance.
Test MSE is copied from the saved evaluation (test observations are not regenerated).
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def stats(values):
    values = list(values)
    n = len(values)
    return dict(n=n, mean=statistics.fmean(values) if n else None,
                mcse=statistics.stdev(values) / math.sqrt(n) if n > 1 else None)


def support_metrics(coef, truth, threshold):
    active = [abs(x) > threshold for x in coef]
    nonzero = [x != 0 for x in truth]
    tp = sum(a and b for a, b in zip(active, nonzero))
    fp = sum(a and not b for a, b in zip(active, nonzero))
    fn = sum(not a and b for a, b in zip(active, nonzero))
    return dict(exact=int(fp == 0 and fn == 0), tp=tp, fp=fp, fn=fn,
                selected=tp + fp, f1=2 * tp / (2 * tp + fp + fn),
                precision=tp / (tp + fp) if tp + fp else 0.,
                recall=tp / (tp + fn))


def population_excess(delta, rho):
    # sum_j d_j^2 + 2 sum_{j>k} d_j d_k rho^(j-k), in O(p).
    cross = 0.
    terms = []
    for x in delta:
        terms.append(x*x + 2*x*cross)
        cross = rho * (cross + x)
    return math.fsum(terms)


def write_csv(path, rows):
    assert rows, path
    with path.open('w', encoding='utf-8', newline='') as stream:
        out = csv.DictWriter(stream, fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def paired_stats(left, right, metric):
    values = [a[metric] - b[metric] for a, b in zip(left, right)]
    lower = metric in ('l2', 'test_mse', 'population_prediction_excess')
    favorable = [d < 0 if lower else d > 0 for d in values]
    unfavorable = [d > 0 if lower else d < 0 for d in values]
    return dict(**stats(values), wins=sum(favorable), losses=sum(unfavorable),
                ties=sum(d == 0 for d in values),
                favorable_direction='negative' if lower else 'positive')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.package.resolve()
    result = root / 'results'
    plan_path = result / 'revision38_evaluation_plan.json'
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    thresholds = plan['thresholds']
    assert thresholds[0] == 1e-6 and len(thresholds) == 10
    hashes = {name: digest(root / name) for name in plan['immutable_sources']}
    assert hashes == plan['immutable_sources'], 'A frozen source has changed'
    selected_rows, threshold_rows = [], []
    grouped, configs, sources = {}, [], {}
    max_diff = dict(l2=0., f1=0., population_prediction_excess=0.)
    sources_spec = [('primary', 'competitive_full', 23),
                    ('sample_size', 'competitive_sample_size', 6)]
    for study, stem, expected_config_count in sources_spec:
        raw_path, raw_plan_path = result / (stem + '.jsonl'), result / (stem + '_plan.json')
        source_plan = json.loads(raw_plan_path.read_text(encoding='utf-8'))
        cf_list, seeds = source_plan['configurations'], source_plan['seeds']
        methods = [m['name'] for m in source_plan['methods']]
        assert len(cf_list) == expected_config_count and len(seeds) == 30 and len(methods) == 9
        expected = {(c['label'], seed, method) for c in cf_list for seed in seeds for method in methods}
        seen, data_hashes = set(), {}
        config_by_label = {c['label']: c for c in cf_list}
        successes = 0
        for line in raw_path.open(encoding='utf-8'):
            row = json.loads(line)
            cf, seed, method = row['configuration'], row['seed'], row['method']
            key = (cf['label'], seed, method)
            assert key in expected and key not in seen, key
            seen.add(key)
            assert cf == config_by_label[cf['label']], key
            data_key = (cf['label'], seed)
            data_hash = row['dataset']['data_sha256']
            assert data_hashes.setdefault(data_key, data_hash) == data_hash, data_key
            ok = row['status'] == 'ok'
            assert ok == (row['selected_index'] is not None), key
            basic = dict(study=study, configuration=cf['label'], seed=seed,
                         method=method, q=cf['q'], n=cf['n'], p=cf['p'], m=cf['m'],
                         rho=cf['rho'], layout=cf['layout'], attack=cf['attack'],
                         f=cf['f'], b=cf['b'], status=row['status'], success=int(ok))
            measures = dict(l2=None, test_mse=None, population_prediction_excess=None,
                            exact=None, f1=None, precision=None, recall=None,
                            selected=None, tp=None, fp=None, fn=None)
            per_threshold = []
            if ok:
                successes += 1
                coef, truth = row['coefficient'], row['dataset']['truth']
                assert len(coef) == len(truth) == cf['p']
                assert all(math.isfinite(x) for x in coef)
                delta = [x-y for x, y in zip(coef, truth)]
                l2 = math.sqrt(math.fsum(x*x for x in delta))
                excess = population_excess(delta, cf['rho'])
                orig = support_metrics(coef, truth, thresholds[0])
                for name, value in [('l2', l2), ('f1', orig['f1']),
                                    ('population_prediction_excess', excess)]:
                    difference = abs(value - row[name])
                    max_diff[name] = max(max_diff[name], difference)
                    assert difference <= 1e-10 * max(1., abs(row[name])), (key, name, difference)
                for name in ('exact', 'fp', 'fn', 'selected'):
                    assert orig[name] == row[name], (key, name)
                measures.update(l2=l2, test_mse=row['test_mse'],
                                population_prediction_excess=excess, **orig)
                for threshold in thresholds:
                    per_threshold.append(support_metrics(coef, truth, threshold))
            else:
                per_threshold = [None] * len(thresholds)
            selected_rows.append(dict(**basic, **measures,
                                      exact_all=int(measures['exact'] or 0),
                                      f1_all=measures['f1'] if ok else 0.))
            grouped[(study, cf['label'], method, seed)] = (selected_rows[-1], per_threshold)
            for threshold, metrics in zip(thresholds, per_threshold):
                fields = metrics or dict(exact=None, tp=None, fp=None, fn=None,
                                         selected=None, f1=None, precision=None, recall=None)
                threshold_rows.append(dict(**basic, threshold=threshold, **fields,
                                           exact_all=int(fields['exact'] or 0),
                                           f1_all=fields['f1'] if ok else 0.,
                                           precision_all=fields['precision'] if ok else 0.,
                                           recall_all=fields['recall'] if ok else 0.))
        assert seen == expected, (study, len(seen), len(expected))
        configs.extend(dict(study=study, configuration=cf, methods=methods, seeds=seeds) for cf in cf_list)
        sources[study] = dict(data=str(raw_path.relative_to(root)), sha256=digest(raw_path),
                              plan=str(raw_plan_path.relative_to(root)), plan_sha256=digest(raw_plan_path),
                              configurations=len(cf_list), methods=len(methods), repetitions=len(seeds),
                              expected=len(expected), observed=len(seen), success=successes,
                              failure=len(seen)-successes, complete=True,
                              within_configuration_paired_hashes_verified=True)
    threshold_groups = defaultdict(list)
    for row in threshold_rows:
        threshold_groups[(row['study'], row['configuration'], row['method'], row['threshold'])].append(row)
    threshold_summary = []
    for (study, label, method, threshold), rows in threshold_groups.items():
        successful = [r for r in rows if r['success']]
        item = dict(study=study, configuration=label, method=method, threshold=threshold,
                    planned=len(rows), success=len(successful), failures=len(rows)-len(successful),
                    exact_count=sum(r['exact_all'] for r in rows))
        for metric in ('exact', 'f1', 'precision', 'recall'):
            for convention, values in [('conditional', [r[metric] for r in successful]),
                                       ('all', [r[metric + '_all'] for r in rows])]:
                ss = stats(values)
                item.update({metric+'_'+convention+'_'+k: v for k, v in ss.items()})
        for metric in ('selected', 'tp', 'fp', 'fn'):
            ss = stats(r[metric] for r in successful)
            item.update({metric+'_conditional_'+k: v for k, v in ss.items()})
        threshold_summary.append(item)
    metric_summary, pairs, threshold_pairs = [], [], []
    for conf in configs:
        study, cf, methods, seeds = conf['study'], conf['configuration'], conf['methods'], conf['seeds']
        label = cf['label']
        for method in methods:
            rows = [grouped[(study, label, method, seed)][0] for seed in seeds]
            good = [r for r in rows if r['success']]
            item = dict(study=study, configuration=label, method=method, planned=len(rows),
                        success=len(good), failure=len(rows)-len(good))
            for metric in ('l2', 'test_mse', 'population_prediction_excess', 'exact', 'f1'):
                item[metric] = stats(r[metric] for r in good)
            item['exact_all'] = stats(r['exact_all'] for r in rows)
            item['f1_all'] = stats(r['f1_all'] for r in rows)
            metric_summary.append(item)
        for proposed in ('Trim-SCAD', 'Trim-MCP'):
            for comparator in methods:
                if proposed == comparator:
                    continue
                joint = [(grouped[(study, label, proposed, seed)], grouped[(study, label, comparator, seed)])
                         for seed in seeds]
                joint = [(a,b) for a,b in joint if a[0]['success'] and b[0]['success']]
                meta = dict(study=study, configuration=label, proposed=proposed,
                            comparator=comparator, planned_pairs=len(seeds))
                for metric in ('l2', 'test_mse', 'population_prediction_excess', 'exact', 'f1'):
                    pairs.append(dict(**meta, metric=metric,
                                      **paired_stats([a[0] for a,b in joint], [b[0] for a,b in joint], metric)))
                for j, threshold in enumerate(thresholds):
                    for metric in ('exact', 'f1'):
                        threshold_pairs.append(dict(**meta, threshold=threshold, metric=metric,
                                                    **paired_stats([a[1][j] for a,b in joint],
                                                                   [b[1][j] for a,b in joint], metric)))
    paths = {}
    for suffix, rows in [('selected.csv', selected_rows), ('threshold_records.csv', threshold_rows),
                         ('threshold_summary.csv', threshold_summary), ('paired.csv', pairs),
                         ('threshold_paired.csv', threshold_pairs)]:
        path = result / ('revision38_multimetric_' + suffix)
        write_csv(path, rows)
        paths[str(path.relative_to(root))] = dict(rows=len(rows), sha256=digest(path))
    # Verify every input remains identical after the complete read-only computation.
    assert {name: digest(root/name) for name in hashes} == hashes
    report = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                  script_sha256=digest(Path(__file__)), plan_sha256=digest(plan_path),
                  frozen_sources=hashes, source_checks=sources, thresholds=thresholds,
                  rules=dict(selection='Saved validation-selected estimator only; no new fit or retuning.',
                             thresholds=plan['threshold_use'],
                             support='abs(coefficient) > threshold; true support is truth != 0.',
                             precision='Zero when no variable is selected; true support is nonempty in every setting.',
                             conditional='Means and sample-based MC SE use successful fits only.',
                             all='All 30 repetitions; failed fits receive zero exact/F1/precision/recall scores, an explicit failure-scoring convention, not estimated coefficients.',
                             paired='Proposed minus comparator on jointly successful seeds; lower favors errors and higher favors support metrics. No pooling across configurations.',
                             uncertainty='MC SE = sample SD / sqrt(n); neither a confidence interval nor a multiple-comparison-adjusted test.',
                             population_excess='Independently recomputed delta^T Sigma delta for Sigma[j,k]=rho^abs(j-k).',
                             test_mse='Retained from the frozen saved test evaluation; test observations were not regenerated.'),
                  checks=dict(all_records_retained=len(selected_rows), threshold_records=len(threshold_rows),
                              original_metric_recomputations_pass=True, max_absolute_differences=max_diff,
                              inputs_unchanged=True),
                  configuration_order=[dict(study=x['study'], **x['configuration']) for x in configs],
                  metric_summary=metric_summary, threshold_summary=threshold_summary,
                  paired=pairs, threshold_paired=threshold_pairs, outputs=paths)
    (result/'revision38_multimetric_summary.json').write_text(json.dumps(report, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps(dict(checks=report['checks'], sources=sources, outputs=paths), indent=2))


if __name__ == '__main__':
    main()
