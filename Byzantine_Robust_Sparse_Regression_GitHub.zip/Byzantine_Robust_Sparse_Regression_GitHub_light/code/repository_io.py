"""Standard-library paths and checksums for the reproduction package."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def safe_path(relative):
    path = ROOT / relative
    if Path(relative).is_absolute() or not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('Path escapes the repository: ' + str(relative))
    return path

def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()
