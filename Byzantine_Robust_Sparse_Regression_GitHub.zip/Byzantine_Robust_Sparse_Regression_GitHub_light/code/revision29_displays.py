"""Vector-only figure and table revisions from immutable experiment records.

Uses ReportLab for final-size artwork; no experimental result is changed.
"""
from pathlib import Path
import json, math, statistics, hashlib
from collections import defaultdict
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors

ROOT=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(TTFont('FigureSans','C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('FigureBold','C:/Windows/Fonts/arialbd.ttf'))
INK=colors.HexColor('#16394B');BLUE=colors.HexColor('#0072B2');ORANGE=colors.HexColor('#D55E00')
def text(c,x,y,s,size=9,align='center',bold=False):
    c.setFillColor(INK);c.setFont('FigureBold' if bold else 'FigureSans',size)
    {'center':c.drawCentredString,'left':c.drawString,'right':c.drawRightString}[align](x,y,s)
def box(c,x,y,w,h,lines,fill):
    c.setStrokeColor(INK);c.setFillColor(colors.HexColor(fill));c.setLineWidth(.7);c.roundRect(x,y,w,h,4,fill=1)
    for i,s in enumerate(lines):text(c,x+w/2,y+h/2+(len(lines)-1)*5.5-i*11,s)
def arrow(c,x1,y1,x2,y2,dashed=False):
    c.setStrokeColor(INK);c.setFillColor(INK);c.setLineWidth(.8);c.setDash([3,2] if dashed else [])
    c.line(x1,y1,x2,y2);c.setDash([])
    a=math.atan2(y2-y1,x2-x1);d=4
    p=c.beginPath();p.moveTo(x2,y2);p.lineTo(x2-d*math.cos(a-.45),y2-d*math.sin(a-.45));p.lineTo(x2-d*math.cos(a+.45),y2-d*math.sin(a+.45));p.close();c.drawPath(p,fill=1,stroke=0)
def framework():
    c=canvas.Canvas(str(ROOT/'figures/framework.pdf'),pagesize=(383,207),initialFontName='FigureSans')
    text(c,52,190,'Local observations',10,bold=True);text(c,200,190,'Trusted master',10,bold=True);text(c,337,190,'Sparse estimate',10,bold=True)
    box(c,2,85,103,77,[], '#F1F6F8')
    text(c,53.5,148,'Honest workers',9.5,bold=True)
    for r in range(3):
        for k in range(5):
            missing=(r,k) in [(0,1),(1,3),(2,0),(2,4)]
            c.setFillColor(colors.white if missing else BLUE);c.setStrokeColor(INK);c.setLineWidth(.25)
            c.rect(31+k*9,112-r*7,8,6,fill=1,stroke=1)
    text(c,53.5,91,'Missing covariates',9)
    box(c,2,17,103,47,['Byzantine workers','Arbitrary reports'],'#F8F2EE')
    box(c,131,118,138,44,['Trim gradient reports'],'#EAF3F8')
    box(c,131,35,138,56,['Update local surrogate','Weighted soft thresholding'],'#EAF3F8')
    text(c,200,23,'Local updates',9)
    arrow(c,105,130,131,140);arrow(c,105,40,131,125,True);arrow(c,200,118,200,91)
    arrow(c,200,173,53,173);text(c,130,177,'Broadcast next estimate',9)
    arrow(c,269,63,291,63)
    c.setStrokeColor(INK);c.setLineWidth(.6);c.line(298,103,377,103)
    for x,h in [(305,0),(315,31),(326,0),(336,-18),(347,0),(359,24),(369,0)]:
        c.setStrokeColor(INK);c.line(x,103,x,103+h);c.setFillColor(INK);c.circle(x,103+h,1.5,fill=1,stroke=0)
    text(c,337,63,'Selected variables',9)
    c.save()

def paired_figure():
    rec={};source=ROOT/'results/competitive_full.jsonl'
    with source.open() as f:
        for line in f:
            r=json.loads(line)
            if r['configuration']['label'] in ['q0.7_f2_gaussian','q0.7_f2_stealth']:
                rec[r['configuration']['label'],r['method'],r['seed']]=r
    c=canvas.Canvas(str(ROOT/'figures/competitive_paired.pdf'),pagesize=(383,332),initialFontName='FigureSans')
    text(c,191.5,318,'(a) Trim-SCAD minus comparator error',10,bold=True)
    xlo,xhi=130,365;ylo,yhi=205,295
    def xx(v):return xlo+(v+.15)/.20*(xhi-xlo)
    for val in [-.15,-.10,-.05,0,.05]:
        c.setStrokeColor(colors.HexColor('#D8DFE3'));c.setLineWidth(.5);c.line(xx(val),ylo,xx(val),yhi)
        text(c,xx(val),192,f'{val:.2f}',9)
    c.setStrokeColor(INK);c.setDash([2,2]);c.line(xx(0),ylo,xx(0),yhi);c.setDash([])
    pairs=[]
    for idx,method in enumerate(['Trim-Lasso','VRMOM-SCAD','T-SLARD-ZF']):
        y=283-idx*31;text(c,118,y-3,method,9,'right')
        for atk,dy,col in [('gaussian',4,BLUE),('stealth',-4,ORANGE)]:
            cfg='q0.7_f2_'+atk
            rr=[(rec[cfg,'Trim-SCAD',s],rec[cfg,method,s]) for s in range(28021001,28021031)]
            assert all(a['status']==b['status']=='ok' for a,b in rr)
            dif=[a['l2']-b['l2'] for a,b in rr];mu=statistics.mean(dif);se=statistics.stdev(dif)/math.sqrt(30)
            pairs.append(dict(attack=atk,comparator=method,mean=mu,se=se,n=30))
            c.setStrokeColor(col);c.setFillColor(col);c.setLineWidth(1.1)
            c.line(xx(mu-2*se),y+dy,xx(mu+2*se),y+dy)
            for v in [mu-2*se,mu+2*se]:c.line(xx(v),y+dy-2.5,xx(v),y+dy+2.5)
            if atk=='gaussian':c.circle(xx(mu),y+dy,2.6,fill=1,stroke=0)
            else:c.rect(xx(mu)-2.4,y+dy-2.4,4.8,4.8,fill=0,stroke=1)
    text(c,191.5,168,'(b) Exact support recoveries out of 30',10,bold=True)
    methods=['Trim-SCAD','Trim-MCP','Trim-Lasso','VRMOM-SCAD','T-SLARD-ZF']
    for j,method in enumerate(methods):
        y=149-j*24;text(c,118,y-3,method,9,'right')
        for atk,dy,col in [('gaussian',5,BLUE),('stealth',-5,ORANGE)]:
            n=sum(rec['q0.7_f2_'+atk,method,s]['exact'] for s in range(28021001,28021031))
            x=xlo+n/30*(xhi-xlo);c.setStrokeColor(col);c.setLineWidth(1);c.line(xlo,y+dy,x,y+dy)
            c.setFillColor(col)
            if atk=='gaussian':c.circle(x,y+dy,2,fill=1,stroke=0)
            else:c.rect(x-2,y+dy-2,4,4,fill=0,stroke=1)
            text(c, min(x+7,375),y+dy-2,str(n),8,'left')
    c.setFillColor(BLUE);c.circle(80,11,2.6,fill=1,stroke=0);text(c,87,8,'Gaussian',9,'left')
    c.setStrokeColor(ORANGE);c.rect(205,8,5,5,fill=0,stroke=1);text(c,215,8,'In-range',9,'left')
    c.save()
    (ROOT/'figures/competitive_paired_provenance.json').write_text(json.dumps(dict(source=str(source.relative_to(ROOT)),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),pairs=pairs,bars='two paired Monte Carlo standard errors; no multiplicity-adjusted inference',counts='exact support among all 30 repetitions'),indent=2))

def main_table():
    rows=json.loads((ROOT/'results/competitive_summary.json').read_text())['summary']
    methods=[m[0] for m in __import__('competitive_benchmark').METHODS]
    out=[r'\begin{table}[!htb]\centering',r'\caption{Coefficient error and support recovery with 30\% missingness and two Byzantine nodes among twelve. Errors are means $\pm$ Monte Carlo SE among successful fits. OK and Exact count successful fits and exact recoveries, both out of 30.}',r'\label{tab:competitive}',r'\par\begingroup\renewcommand{\baselinestretch}{1.2}\small\selectfont',r'\setlength{\tabcolsep}{4pt}\renewcommand{\arraystretch}{1.05}',r'\begin{tabular}{llrrlrr}\toprule',r' & \multicolumn{3}{c}{Gaussian} & \multicolumn{3}{c}{In-range}\\',r'\cmidrule(lr){2-4}\cmidrule(lr){5-7}',r'Method & $\ell_2$ error & OK & Exact & $\ell_2$ error & OK & Exact\\\midrule']
    for method in methods:
        cells=[method.replace('NoCorrection-SCAD','Uncorrected SCAD')]
        for cfg in ['q0.7_f2_gaussian','q0.7_f2_stealth']:
            r=next(r for r in rows if r['configuration']==cfg and r['method']==method)
            cells+=['--' if not r['success'] else r'$%.3f\pm%.3f$'%(r['l2']['mean'],r['l2']['se']),str(r['success']),str(r['exact'])]
        out.append(' & '.join(cells)+r' \\')
    out += [r'\bottomrule\end{tabular}\endgroup\end{table}']
    (ROOT/'results/competitive_main_table.tex').write_text('\n'.join(out)+'\n')

def stress_matrix():
    rows=json.loads((ROOT/'results/revision_summary.json').read_text())['revision_synthetic.json']
    configs=list(dict.fromkeys(r['config'] for r in rows));methods=list(dict.fromkeys(r['method'] for r in rows))
    assert len(configs)==6 and len(methods)==7
    labels=['Reference','Missing','Corr.','In-range','Undertrim','Clean']
    c=canvas.Canvas(str(ROOT/'figures/validation_benchmark.pdf'),pagesize=(383,410),initialFontName='FigureSans')
    for panel,title in enumerate(['(a) Mean coefficient error','(b) Successful fits out of 30','(c) Exact support recoveries out of 30']):
        top=392-panel*124;text(c,191.5,top,title,10,bold=True)
        for j,label in enumerate(labels):text(c,110+j*46,top-18,label,8.5)
        for i,method in enumerate(methods):
            y=top-32-i*11.5;text(c,82,y-3,method,9,'right')
            for j,cfg in enumerate(configs):
                row=next(r for r in rows if r['config']==cfg and r['method']==method)
                value=row['mean'] if panel==0 else row['success'] if panel==1 else round(30*row['exact'])
                if value is None:fill=colors.HexColor('#E8E8E8');label='--'
                else:
                    frac=min(value/(2.4 if panel==0 else 30),1);fill=colors.Color(1-.14*frac,1-.22*frac,1-.28*frac)
                    label=f'{value:.3f}' if panel==0 else str(value)
                c.setFillColor(fill);c.setStrokeColor(colors.white);c.setLineWidth(.6);c.rect(87+j*46,y-5,46,11.5,fill=1,stroke=1)
                text(c,110+j*46,y-3,label,9)
    text(c,4,25,'Error: lower is better. Counts: higher is better. -- : no successful fit.',8.5,'left')
    text(c,4,11,'Missing: high missingness. Corr.: high correlation. See the design table.',8.5,'left')
    c.save()

if __name__=='__main__':framework();paired_figure();main_table();stress_matrix()
