"""Read-only validation of the complete frozen process study, then summaries.

Requires all 600 method records / 4200 candidates. Never runs fitting and never
produces a partial-result table. Costs include failed candidates and method runs;
accuracy is conditional on a successful selected fit. Targets use final estimates.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
TARGETS = (.1, .2, .5)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def stats(values):
    values = list(values)
    assert all(math.isfinite(x) for x in values)
    return dict(n=len(values), mean=statistics.mean(values) if values else None,
                se=statistics.stdev(values) / math.sqrt(len(values)) if len(values) > 1 else None,
                median=statistics.median(values) if values else None,
                minimum=min(values) if values else None, maximum=max(values) if values else None)


def close(a, b, tolerance=1e-10):
    return abs(a - b) <= tolerance * (1 + abs(b))


def read_complete():
    plan_path = RESULTS / "revision38_evaluation_plan.json"
    meta_path = RESULTS / "competitive_process_cost_metadata.json"
    execution_path = RESULTS / "competitive_process_cost_execution.json"
    input_path = RESULTS / "competitive_process_cost.jsonl"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    execution = json.loads(execution_path.read_text(encoding="utf-8"))
    design = plan["cost_design"]
    assert execution["complete"] and execution["records"] == meta["expected_records"] == 600
    assert meta["expected_candidates"] == 4200 and meta["design"] == design and meta["mode"] == "run"
    assert meta["plan_sha256"] == execution["plan_sha256"] == digest(plan_path)
    assert meta["script_sha256"] == execution["script_sha256"] == digest(ROOT / "code/competitive_process_cost.py")
    assert meta["core_sha256"] == digest(ROOT / "code/robust_sparse.py")
    assert meta["benchmark_sha256"] == digest(ROOT / "code/competitive_benchmark.py")
    for relative_path, expected_hash in plan["immutable_sources"].items():
        assert digest(ROOT / relative_path) == expected_hash, relative_path
    assert execution["output_sha256"] == digest(input_path)
    configurations = {cf["label"]: cf for cf in meta["configurations"]}
    methods = design["methods"]
    seeds = design["seeds"]
    expected = {(cf, seed, method) for cf in configurations for seed in seeds for method in methods}
    records, data_hashes = {}, defaultdict(set)
    candidate_statuses = Counter()
    candidate_count = 0
    setup_instances = {}
    byte_total = 0
    with input_path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            row = json.loads(line)
            key = (row["configuration"]["label"], row["seed"], row["method"])
            assert key in expected and key not in records, (line_number, key)
            assert row["mode"] == "run" and row["configuration"] == configurations[key[0]]
            assert seeds[row["rep"]] == row["seed"] and 0 <= row["execution_order"] < len(methods)
            assert row["plan_sha256"] == meta["plan_sha256"] and row["script_sha256"] == meta["script_sha256"]
            cf = row["configuration"]
            data_hashes[key[:2]].add(row["dataset"]["data_sha256"])
            setup_key = (*key[:2], row["dataset_preparation_seconds"], row["shared_pool_startup_seconds"])
            setup_instances[setup_key] = dict(preparation=row["dataset_preparation_seconds"], startup=row["shared_pool_startup_seconds"],
                                             raw_array_bytes=row["shared_worker_raw_array_bytes"],
                                             control_bytes=row["shared_startup_shutdown_control_bytes"])
            assert row["shared_worker_raw_array_bytes"] == 8 * (cf["m"] - 1) * cf["n"] * (cf["p"] + 1)
            assert row["shared_startup_shutdown_control_bytes"] == 3 * (cf["m"] - 1)
            candidates = row["candidates"]
            assert [c["factor"] for c in candidates] == design["grid"]
            candidate_count += len(candidates)
            for candidate in candidates:
                status = candidate["status"]
                candidate_statuses[status] += 1
                trace = candidate["trace"]
                initial = candidate["initial"]
                assert candidate["communication_rounds"] == len(trace)
                assert len(candidate["outer_coefficients"]) == len(candidate["path"]) == len(trace) + 1
                assert candidate["coefficient"] == candidate["outer_coefficients"][-1]
                assert candidate["vector_payload_bytes"] == 16 * (cf["m"] - 1) * cf["p"] * len(trace)
                assert candidate["control_payload_bytes"] == 2 * (cf["m"] - 1) * len(trace)
                assert len(candidate["round_costs"]) == len(trace)
                assert sum(x["vector_payload_bytes"] for x in candidate["round_costs"]) == candidate["vector_payload_bytes"]
                assert candidate["total_updates"] == initial["iterations"] + sum(x["iterations"] for x in trace)
                assert candidate["total_stages"] == initial["stages"] + sum(x["stages"] for x in trace)
                assert candidate["seconds"] >= candidate["fitting_seconds"] >= candidate["initialization_seconds"] >= 0
                if status == "initial_failed":
                    assert initial["status"] != "ok" and not trace and candidate["validation_mse"] is None
                else:
                    assert initial["status"] == "ok" and trace and status == trace[-1]["status"]
                if status == "ok":
                    assert len(trace) == design["rounds"] and all(x["status"] == "ok" for x in trace)
                    assert math.isfinite(candidate["validation_mse"])
                    for stage in trace:
                        assert stage["kkt"] <= min(1e-5, stage["lambda_value"] / 1000) + 1e-12
                else:
                    assert candidate["validation_mse"] is None
            eligible = [i for i, c in enumerate(candidates) if c["status"] == "ok"]
            selected = min(eligible, key=lambda i: candidates[i]["validation_mse"]) if eligible else None
            assert row["selected_index"] == selected and row["candidate_successes"] == len(eligible)
            assert row["status"] == ("ok" if eligible else "all_candidates_failed")
            assert close(row["total_search_seconds"], sum(c["seconds"] for c in candidates))
            for name, item in [("updates", "total_updates"), ("stages", "total_stages"), ("rounds", "communication_rounds")]:
                assert row["total_search_" + name] == sum(c[item] for c in candidates)
            assert row["total_vector_payload_bytes"] == sum(c["vector_payload_bytes"] for c in candidates)
            assert row["total_control_payload_bytes"] == 10 * (cf["m"] - 1) + sum(c["control_payload_bytes"] for c in candidates)
            assert row["full_tuning_seconds"] + 1e-8 >= row["moment_construction_seconds"] + row["total_search_seconds"] + row["selection_seconds"]
            assert row["full_tuning_seconds"] > 0 and row["moment_construction_seconds"] > 0
            if selected is not None:
                assert row["coefficient"] == candidates[selected]["coefficient"]
                assert row["validation_mse"] == candidates[selected]["validation_mse"]
                assert row["factor"] == candidates[selected]["factor"]
                coefficient, truth = row["coefficient"], row["dataset"]["truth"]
                delta = [a - b for a, b in zip(coefficient, truth)]
                assert len(delta) == cf["p"] and close(row["l2"], math.sqrt(sum(x * x for x in delta)))
                chosen = {i for i, x in enumerate(coefficient) if abs(x) > 1e-6}
                active = {i for i, x in enumerate(truth) if x != 0}
                fp, fn, tp = len(chosen - active), len(active - chosen), len(chosen & active)
                assert row["fp"] == fp and row["fn"] == fn and row["exact"] == (chosen == active)
                assert close(row["f1"], 2 * tp / (2 * tp + fp + fn))
                assert all(math.isfinite(row[name]) for name in ["l2", "test_mse", "population_prediction_excess", "f1"])
                # Independent O(p) evaluation of the Toeplitz quadratic form.
                cross, left = 0., 0.
                for value in delta:
                    cross += value * left
                    left = cf["rho"] * (left + value)
                assert close(row["population_prediction_excess"], sum(x * x for x in delta) + 2 * cross)
            assert row["final_target_attainment"] == {str(t): selected is not None and row["l2"] <= t for t in TARGETS}
            fields = ["method", "seed", "status", "l2", "test_mse", "population_prediction_excess", "f1", "fp", "fn", "exact", "factor", "selected_index", "candidate_successes", "full_tuning_seconds", "moment_construction_seconds", "total_search_seconds", "total_search_updates", "total_search_stages", "total_search_rounds", "total_vector_payload_bytes", "total_control_payload_bytes", "final_target_attainment", "execution_order"]
            records[key] = {field: row.get(field) for field in fields}
            records[key]["candidate_statuses"] = [c["status"] for c in candidates]
            byte_total += row["total_vector_payload_bytes"]
    assert records.keys() == expected and len(records) == 600 and candidate_count == 4200
    assert all(len(values) == 1 for values in data_hashes.values())
    for cf in configurations:
        for seed in seeds:
            assert {records[(cf, seed, method)]["execution_order"] for method in methods} == set(range(len(methods)))
    # Attacks at a given q use exactly the same observations and masks.
    for q in design["q"]:
        labels = [name for name, cf in configurations.items() if cf["q"] == q]
        for seed in seeds:
            assert len(set.union(*(data_hashes[(name, seed)] for name in labels))) == 1
    details = dict(records=len(records), candidates=candidate_count, candidate_statuses=dict(candidate_statuses),
                   failed_candidates=sum(n for status, n in candidate_statuses.items() if status != "ok"),
                   all_candidates_vector_payload_bytes=byte_total, dataset_units=len(data_hashes),
                   distinct_data_hashes=len(set.union(*data_hashes.values())),
                   shared_pool_instances=len(setup_instances),
                   preparation_seconds_sum=sum(x["preparation"] for x in setup_instances.values()),
                   shared_pool_startup_seconds_sum=sum(x["startup"] for x in setup_instances.values()),
                   shared_raw_array_size_bytes_sum=sum(x["raw_array_bytes"] for x in setup_instances.values()),
                   shared_startup_shutdown_control_bytes_sum=sum(x["control_bytes"] for x in setup_instances.values()),
                   preparation_seconds_per_pool=stats(x["preparation"] for x in setup_instances.values()),
                   startup_seconds_per_pool=stats(x["startup"] for x in setup_instances.values()),
                   selected_statuses=dict(Counter(row["status"] for row in records.values())),
                   full_tuning_seconds_sum=sum(row["full_tuning_seconds"] for row in records.values()),
                   all_candidates_control_payload_bytes=sum(row["total_control_payload_bytes"] for row in records.values()),
                   execution_invocation_records=execution["invocation_records"],
                   execution_invocation_elapsed_seconds=execution["invocation_elapsed_seconds"],
                   execution_completed_utc=execution["completed_utc"],
                   input_sha256=execution["output_sha256"], plan_sha256=meta["plan_sha256"],
                   cost_script_sha256=meta["script_sha256"])
    return design, configurations, records, details


def summarize(design, configurations, records):
    rows, paired = [], []
    methods, seeds = design["methods"], design["seeds"]
    for label, cf in configurations.items():
        for method in methods:
            all_runs = [records[(label, seed, method)] for seed in seeds]
            good = [row for row in all_runs if row["status"] == "ok"]
            statuses = Counter(status for row in all_runs for status in row["candidate_statuses"])
            row = dict(configuration=label, q=cf["q"], attack=cf["attack"], method=method,
                       attempted=len(all_runs), success=len(good), exact=sum(x["exact"] for x in good),
                       candidate_count=sum(statuses.values()), candidate_failures=sum(n for k, n in statuses.items() if k != "ok"),
                       candidate_statuses=dict(statuses), selected_factor_counts=dict(Counter(str(x["factor"]) for x in good)),
                       grid_low=sum(x["selected_index"] == 0 for x in good),
                       grid_high=sum(x["selected_index"] == len(design["grid"]) - 1 for x in good),
                       all_attempts_full_tuning_seconds=sum(x["full_tuning_seconds"] for x in all_runs),
                       all_attempts_vector_payload_bytes=sum(x["total_vector_payload_bytes"] for x in all_runs))
            for name in ["l2", "test_mse", "population_prediction_excess", "f1", "fp", "fn"]:
                row[name] = stats(x[name] for x in good)
            for name in ["full_tuning_seconds", "moment_construction_seconds", "total_search_seconds", "total_search_updates", "total_search_stages", "total_search_rounds", "total_vector_payload_bytes", "total_control_payload_bytes"]:
                row[name] = stats(x[name] for x in all_runs)
            row["final_targets"] = {str(t): dict(attained=sum(x["final_target_attainment"][str(t)] for x in all_runs), denominator=len(all_runs)) for t in TARGETS}
            rows.append(row)
        for method_a, method_b in itertools.combinations(methods, 2):
            pairs = [(records[(label, seed, method_a)], records[(label, seed, method_b)]) for seed in seeds]
            both = [(a, b) for a, b in pairs if a["status"] == b["status"] == "ok"]
            ratios = [a["full_tuning_seconds"] / b["full_tuning_seconds"] for a, b in pairs]
            paired.append(dict(configuration=label, q=cf["q"], attack=cf["attack"], method_a=method_a, method_b=method_b,
                               cost_pairs=len(pairs), accuracy_common_success=len(both),
                               time_a_faster=sum(a["full_tuning_seconds"] < b["full_tuning_seconds"] for a, b in pairs),
                               time_b_faster=sum(b["full_tuning_seconds"] < a["full_tuning_seconds"] for a, b in pairs),
                               time_ties=sum(b["full_tuning_seconds"] == a["full_tuning_seconds"] for a, b in pairs),
                               time_difference=stats(a["full_tuning_seconds"] - b["full_tuning_seconds"] for a, b in pairs),
                               time_ratio=stats(ratios),
                               log_time_ratio=stats(math.log(x) for x in ratios),
                               vector_payload_difference=stats(a["total_vector_payload_bytes"] - b["total_vector_payload_bytes"] for a, b in pairs),
                               l2_difference=stats(a["l2"] - b["l2"] for a, b in both),
                               test_mse_difference=stats(a["test_mse"] - b["test_mse"] for a, b in both),
                               exact_count_difference=sum(bool(a["exact"]) if a["status"] == "ok" else 0 for a, _ in pairs) - sum(bool(b["exact"]) if b["status"] == "ok" else 0 for _, b in pairs)))
    assert len(rows) == 20 and len(paired) == 40
    return rows, paired


def flatten(row):
    result = {}
    for key, value in row.items():
        if isinstance(value, dict) and {"n", "mean", "se", "median"} <= value.keys():
            result.update({key + "_" + suffix: number for suffix, number in value.items()})
        elif key == "final_targets":
            for target, counts in value.items():
                result["target_" + target + "_attained"] = counts["attained"]
                result["target_" + target + "_denominator"] = counts["denominator"]
        elif isinstance(value, dict):
            result[key] = json.dumps(value, sort_keys=True, separators=(",", ":"))
        else:
            result[key] = value
    return result


def write_csv(path, rows):
    flat = [flatten(row) for row in rows]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flat[0]))
        writer.writeheader()
        writer.writerows(flat)


def tex_estimate(value, digits=3):
    if value["mean"] is None:
        return "--"
    if value["se"] is None:
        return f"{value['mean']:.{digits}f}"
    return f"${value['mean']:.{digits}f}\\pm {value['se']:.{digits}f}$"


def compact_table(rows):
    lines = [r"\begin{table}[H]", r"\caption{Full validation-tuning cost and final estimation error in the process study. Each setting uses 30 paired repetitions. Success counts successful selected fits out of 30; L2 gives their mean $\pm$ Monte Carlo SE. Time and MB are medians over all repetitions, including every candidate failure. MB denotes $10^6$ actual coefficient/gradient bytes. Shared data preparation and process startup are separate.}",
             r"\label{tab:processfullcost}", r"\centering\small\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{llcrrr}\toprule", r"$q$/Attack & Method & Success & L2 & Time (s) & MB\\\midrule"]
    for i, row in enumerate(rows):
        if i and i % 5 == 0:
            lines.append(r"\midrule")
        case = f"{row['q']:.1f}/" + ("G" if row["attack"] == "gaussian" else "I")
        lines.append(" & ".join([case, row["method"], f"{row['success']}/{row['attempted']}", tex_estimate(row["l2"]),
                                 f"{row['full_tuning_seconds']['median']:.3f}",
                                 f"{row['total_vector_payload_bytes']['median'] / 1e6:.3f}"]) + r" \\")
    lines.extend([r"\bottomrule\end{tabular}", r"\par\smallskip\raggedright\footnotesize G: Gaussian reports; I: in-range reports. Every method searches the same seven factors, allowing up to eight rounds per candidate. Time includes method-specific moment construction, all candidate initializations, gradient transport, local solves, validation and selection; truth and test evaluation occur afterwards.", r"\end{table}"])
    return "\n".join(lines) + "\n"


def main():
    design, configurations, records, audit = read_complete()
    rows, paired = summarize(design, configurations, records)
    checks = {name: True for name in ["complete_600_records_4200_candidates", "frozen_plan_sources_and_output_hashes", "all_failed_candidates_retained_and_costed", "actual_vector_and_control_payloads_consistent", "full_cost_contains_moments_candidates_validation_selection", "same_data_across_methods_and_attack_pairs", "complete_randomized_method_orders", "validation_choice_and_success_rules_verified", "selected_coefficient_support_and_final_targets_verified", "twenty_summary_rows_and_forty_paired_comparisons"]}
    result = dict(generated_utc=datetime.now(timezone.utc).isoformat(), checks=checks, audit=audit,
                  definitions={"accuracy": "Means and Monte Carlo SE among successful selected fits; exact support and final targets use all 30 attempts.",
                               "cost": "Median, mean and Monte Carlo SE across all attempted runs, including all seven candidates and every failure; shared startup/preparation excluded and reported separately.",
                               "paired": "A minus B and A/B are formed within each seed. Time pairs include all 30 attempts. The median ratio is the median of individual paired ratios, not a ratio of marginal medians. Accuracy pairs require both fits successful.",
                               "target": "Final selected-estimate attainment only, after full tuning. No target-based early stopping.",
                               "overhead": "Setup values duplicated across methods are counted once per observed pool instance; dataset preparation includes benchmark.make_data reference moments/diagnostics.",
                               "traffic": "Actual numerical vector buffers plus separately counted protocol control payloads; OS framing and startup pickle overhead are unmeasured."},
                  summary=rows, paired=paired, summarizer_sha256=digest(Path(__file__)))
    write_csv(RESULTS / "competitive_process_cost_summary.csv", rows)
    write_csv(RESULTS / "competitive_process_cost_paired.csv", paired)
    (RESULTS / "competitive_process_cost_compact.tex").write_text(compact_table(rows), encoding="utf-8")
    (RESULTS / "competitive_process_cost_summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(checks=checks, audit=audit, summary_rows=len(rows), paired_rows=len(paired)), indent=2))


if __name__ == "__main__":
    main()
