# Reproducing the experiments

This lightweight archive supplies code, offline datasets, experimental plans, and retained numerical summaries. Seven large result files are omitted; their original sizes and hashes are listed in `provenance/omitted_results.json`. File verification and plotting the retained summaries are available immediately. Complete raw-record audits require new fitting first. No LaTeX installation is needed.

## 1. Verify and install

Run from the repository root:

```text
python code/verify_repository.py
python -m pip install -r requirements-reproduce.txt
```

Verification uses the standard library and covers included files only. Keep `.gitattributes`: line-ending conversion would change frozen source and plan hashes. Use a dedicated Python environment. The primary historical plan records Python 3.12.14 and NumPy 2.3.5 on Windows; individual plans and metadata record the other study environments. Historical requirement files are retained separately from the consolidated installation list.

## 2. Generate fresh primary and follow-up records

```text
python code/create_run_workspace.py all --destination runs/replication
cd runs/replication
python code/competitive_benchmark.py --mode full --repeats 30
python code/competitive_sample_size.py
python code/bind_replication_plan.py
python code/competitive_multimetric.py
```

The helper refuses an existing destination. It copies code and necessary inputs, keeps the three original plans in `reference/`, and leaves the new studies' outcome files absent. It also copies two small archived audit inputs into `results/`, identified in `RUN_WORKSPACE.json`. The original package remains available for comparison.

The primary study has 23 configurations and 30 seeds per configuration. The sample-size follow-up has six configurations and 30 new seeds per configuration. Its allocation was designed after inspection of the primary study; this chronology is retained in `results/competitive_sample_size_README.txt` in the original package. The new follow-up uses the primary plan generated in this run.

Once both raw-record files are complete, `bind_replication_plan.py` checks the original code hashes, design, and completeness. It writes an evaluation plan bound to the new raw-file hashes without changing seeds, design, tuning, or evaluation thresholds. This permits downstream analysis of a fresh run, whose recorded timings and file hashes need not equal those of the historical run. The binding step does not fit a model or alter the original package.

`competitive_multimetric.py` then evaluates the saved coefficients at the fixed thresholds. This is evaluation, not truth-based selection of a deployed threshold.

## 3. Generate and audit primary summaries

After Section 2, while still in `runs/replication`:

```text
python code/summarize_competitive.py --study main
python code/summarize_competitive.py --study sample_size
python code/check_competitive_results.py --study full
python code/check_competitive_results.py --study sample_size
python code/compare_competitive_summaries.py --study full
python code/compare_competitive_summaries.py --study sample_size
```

The summary generator calls the primary study `main`; the independent checker calls it `full`. The checks reconstruct selection, coefficient errors, path metrics, and accounting from the newly generated raw records and compare independently calculated summaries. These commands cannot perform the complete audit in the lightweight package before the omitted raw records have been generated. They write summaries and audit reports but do not refit models.

The checker also reads the archived `competitive_pilot_plan.json` and `competitive_core_equivalence_fullgrid.json` supplied by the workspace helper. These are historical audit inputs for the unchanged scientific code, not a new execution of the equivalence check in the current environment.

## 4. Run the single-host process-cost study

After the binding step in Section 2, in the same new workspace:

```text
python code/competitive_process_cost.py --pilot
python code/competitive_process_cost.py --run
python code/summarize_process_cost.py
```

The independent pilot checks numerical agreement with the serial implementation and must pass before the main study. The main run measures full tuning with worker processes on one host. Its summary requires all 600 method records and 4,200 tuning candidates. Elapsed times depend on the machine and software; they do not measure a physical multi-server network.

For interrupted fitting, add `--resume` to the same runner command in the same workspace. Resume verifies the recorded protocol and computes missing records. It skips completed records. Use a new workspace to repeat a complete experiment.

## 5. Plot retained results and run additional experiments

The original lightweight directory contains the summaries needed for:

```text
python code/revision38_figures.py
```

Run this command from that original directory to recreate the sample-size and support-threshold plots. It reads included summaries, writes plots and provenance to `figures/`, and requires no omitted raw records. Plotting a historical summary is distinct from fitting models again.

Additional retained runners cover real-data evaluations, sparse paths, missingness, curvature, and certificate diagnostics. Their filenames are retained for traceability. Some audit scripts need raw files omitted from this edition; consult `provenance/omitted_results.json` before using them. The workspace helper also supports `primary` and `sample_size` for isolated studies; use `all` for the complete sequence above.

`revision29_displays.py` uses ReportLab and Windows Arial fonts at `C:/Windows/Fonts/arial*.ttf`. `benchmark_matched_cost.py` is an earlier Windows-only benchmark. The optional preview modes of `summarize_competitive.py` (`--partial`) and `theory_mcar_experiment.py` (`--pilot`) retain historical output paths outside the package root; they are not used above. Some summary scripts export table text as `.tex` files without invoking TeX.

`data/PROVENANCE.md` records both public dataset sources, licenses, and preprocessing. `provenance/SLARD_BASELINE_PROVENANCE.txt` describes how the implemented comparators and their tuning relate to the cited method. Numerical audits check the recorded computations; they do not establish the mathematical proofs.
