"""Download the public UCI artifact; do not overwrite an existing file."""
from pathlib import Path
import urllib.request,hashlib
root=Path(__file__).resolve().parents[1]
for name,url in [('superconductivity.zip','https://archive.ics.uci.edu/static/public/464/superconductivty+data.zip'),('abalone.zip','https://archive.ics.uci.edu/static/public/1/abalone.zip')]:
 path=root/'data'/name
 if not path.exists():
  path.parent.mkdir(parents=True,exist_ok=True)
  urllib.request.urlretrieve(url,path)
 print(path.name,hashlib.sha256(path.read_bytes()).hexdigest())
