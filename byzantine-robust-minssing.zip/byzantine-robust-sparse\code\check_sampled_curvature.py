"""Verify the sampled high-dimensional audit and its uniform-condition exclusion.

Replays the fixed seeds, not the fitting. A null vector gives a negative
corrected quadratic form; diagonal ratios give a necessary-condition exclusion.
"""
import json
import numpy as np
from pathlib import Path
from threadpoolctl import threadpool_limits
from scipy.linalg import null_space
from path_audit import make,CONFIGS,clean
R=Path(__file__).resolve().parents[1]
rows=[]
with threadpool_limits(limits=1):
 for cf in CONFIGS:
  for rep in range(10):
   seed,truth,nodes,naive,_,_=make(cf,rep)
   g=nodes[0].gram;diag=np.diag(g);ratio=float(diag.max()/diag.min())
   Kmin=8+int(np.ceil((32/3)**2*(ratio-1)**2*4))
   assert nodes[0].p>nodes[0].n and np.all(diag>0)
   # An n x (n+1) block necessarily has a nonzero null vector.
   Z=nodes[0].z[:,:nodes[0].n+1];v=null_space(Z)[:,0]
   qform=float(v@g[:len(v),:len(v)]@v);res=float(np.linalg.norm(Z@v))
   assert qform<0 and res<1e-8
   # Check reconstruction used by the no-correction comparator independently.
   direct=nodes[0].z.T@nodes[0].z/nodes[0].n
   assert np.allclose(naive[0].gram,direct,atol=1e-12)
   rows.append(dict(config=cf['name'],rep=rep,seed=seed,n=nodes[0].n,p=nodes[0].p,diagonal_ratio=ratio,K_lower=Kmin,uniform_rank_excluded=4*Kmin>nodes[0].n,negative_quadratic=qform,null_residual=res))
  print(cf['name'],'curvature checked',flush=True)
(R/'results/sampled_curvature.json').write_text(json.dumps(clean(dict(records=rows,all_negative=True,no_correction_matrices_verified=True)),indent=2))
print('Uniform assumption excluded:',sum(x['uniform_rank_excluded'] for x in rows),'/',len(rows))
