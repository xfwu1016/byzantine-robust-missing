"""Observable local solver and bounded-MCAR statistical certificates.
All numerical inequalities are checked in float64 with a conservative buffer;
these are numerical diagnostics, not interval-arithmetic proofs.
"""
import numpy as np
from robust_sparse import soft

def local_certificate(node,c,w,x,buffer=1e-10):
 U=np.flatnonzero(x!=0);p=len(x);g=node.mv(x)-c
 if len(U)==0:
  slack=float(np.min(w-np.abs(g)))
  return dict(passed=slack>=0,support=0,radius=0.,kappa=None,L=None,contraction=0.,inactive_slack=slack)
 if node.gram is not None:GU=node.gram[:,U]
 else:
  GU=np.column_stack([node.mv(np.eye(1,p,int(j)).ravel()) for j in U])
 ev=np.linalg.eigvalsh(GU[U]);kappa=float(ev[0]);L=float(ev[-1])
 if kappa<=buffer:return dict(passed=False,support=len(U),radius=None,kappa=kappa,L=L,contraction=None,inactive_slack=None)
 residual=float(np.linalg.norm(g[U]+w[U]*np.sign(x[U])))
 radius=(residual+buffer)/kappa
 outside=np.ones(p,dtype=bool);outside[U]=False
 slack=float(np.min(w[outside]-np.abs(g[outside])-np.linalg.norm(GU[outside],axis=1)*radius)) if outside.any() else float('inf')
 return dict(passed=bool(slack>buffer),support=len(U),radius=radius,kappa=kappa,L=L,contraction=1-kappa/L,inactive_slack=slack,active_residual=residual)

def calibration_certificate(G,gamma,candidates,n,q,H,Ymax,s,delta=.05):
 """Independent MCAR holdout, known |X_l|<=H and |Y|<=Ymax.
 Candidate list must be fixed before looking at this holdout. No truth, honest
 labels, population covariance or population curvature are inputs.
 """
 p=len(gamma);J=len(candidates);dc=delta/2;dg=delta/2
 Delta=H*H/q**2*np.sqrt(2*np.log(2*p*p/dc)/n)
 off=np.abs(G).copy();np.fill_diagonal(off,0);ordered=np.sort(off,axis=1)[:,::-1];out=[]
 for x in candidates:
  k=int(np.count_nonzero(x));r=min(k+s,p)
  empirical_lower=float(np.min(np.diag(G)-ordered[:,:max(0,r-1)].sum(1)))
  lower=empirical_lower-r*Delta
  C=H*H*np.linalg.norm(x,1)/q**2+H*Ymax/q
  eps=float(C*np.sqrt(2*np.log(2*J*p/dg)/n))
  score=float(np.max(np.abs(G@x-gamma)))
  radius=float(np.sqrt(r)*(score+eps)/lower) if lower>0 else None
  out.append(dict(passed=bool(lower>0),support=k,sparse_order=r,kappa_lower=lower,entrywise_radius=float(Delta),score_bound=score+eps,score_radius=eps,radius=radius))
 return out
