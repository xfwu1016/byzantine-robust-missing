"""Regenerate revised tables, figures, and audit summaries from saved runs."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results'; F=ROOT/'figures'
def read(name): return json.loads((R/name).read_text())['records']
def tex(name,rows):
 ending='\n' if name in ['matched_cost_table.tex','memory_table.tex'] else '\n'+r'\bottomrule'+'\n'
 (R/name).write_text('\n'.join(' & '.join(map(str,row))+r'\\' for row in rows)+ending)
def mean(x): return float(np.mean(x)) if len(x) else None
def med(x): return float(np.median(x)) if len(x) else None
def fmt(x,d=3): return '--' if x is None else f'{x:.{d}f}'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
local=read('local_certificates.json'); old={x['rep']:x for x in read('revision_synthetic.json') if x['config']=='reference' and x['method']=='Trim-SCAD'}
assert all(abs(x['l2']-old[x['rep']]['l2'])<1e-10 and x['factor']==old[x['rep']]['factor'] for x in local)
local_summary=dict(final_pass=sum(x['stage_audit'][-1]['certificate']['passed'] for x in local),all_stages_pass=sum(x['all_stages_pass'] for x in local),stages_pass=sum(x['stages_pass'] for x in local),stages=sum(x['stage_count'] for x in local),prefix_support_range=[min(x['max_prefix_support'] for x in local),max(x['max_prefix_support'] for x in local)],support_recovery={t:sum(x['thresholds'][t]['exact'] for x in local) for t in local[0]['thresholds']},unchanged_reference_fits=True)
cal=read('calibration_certificates.json'); cs=[]
for q in [.5,.7,.9]:
 for n in [1000,10000,50000]:
  a=[x for x in cal if x['q']==q and x['calibration_n']==n]; selected=[x['candidates'][x['selected_index']] for x in a if x['selected_index'] is not None]
  cs.append(dict(q=q,n=n,admitted=len(selected),covered=sum(x['covered'] for x in selected),radius=mean([x['radius'] for x in selected]),l2=mean([x['l2'] for x in selected])))
assert all(c['covered'] for x in cal for c in x['candidates'] if c['passed'])
tex('calibration_table.tex',[[x['q'],x['n'],f"{x['admitted']}/10",f"{x['covered']}/{x['admitted']}" if x['admitted'] else '--',fmt(x['radius']),fmt(x['l2'],4)] for x in cs])
fig,axs=plt.subplots(1,3,figsize=(10.2,2.65),layout='constrained')
for q,color in zip([.5,.7,.9],['#b44838','#326ea6','#24816b']):
 a=[x for x in cs if x['q']==q];n=[x['n'] for x in a]
 axs[0].plot(n,[x['admitted']/10 for x in a],'-o',color=color,label=f'q = {q}')
 for ax,key in zip(axs[1:],['radius','l2']): ax.plot(n,[x[key] if x[key] is not None else np.nan for x in a],'-o',color=color)
for ax in axs:
 ax.set_xscale('log');ax.set_xticks([1000,10000,50000],['1,000','10,000','50,000']);ax.set_xlabel(r'Masked calibration size $N_{\rm cal}$');ax.grid(alpha=.2)
axs[0].set(ylabel='Admitted fraction',ylim=(-.05,1.08));axs[0].legend(fontsize=8,loc='lower right')
axs[1].set(ylabel='Mean certified radius',yscale='log');axs[2].set(ylabel='Mean coefficient error',yscale='log')
for ax,title in zip(axs,['(a) Admission','(b) Error bound','(c) Observed error']):ax.set_title(title,loc='left',fontsize=10)
fig.savefig(F/'observable_certificates.pdf');fig.savefig(F/'observable_certificates.png',dpi=180);plt.close(fig)
real=read('real_revision2.json');rs=[];pairs=[]
for task in ['abalone','superconductivity_grouped']:
 for method in ['Trim-SCAD','Trim-Lasso','VRMOM-SCAD']:
  a=[x for x in real if x['task']==task and x['method']==method];ok=[x for x in a if x['status']=='ok'];v=[x['test_rmse'] for x in ok]
  rs.append(dict(task=task,method=method,success=len(ok),rmse=mean(v),sd=float(np.std(v,ddof=1)),baseline=mean([x['constant_rmse'] for x in a])))
 for comparator in ['Trim-Lasso','VRMOM-SCAD']:
  a={x['rep']:x for x in real if x['task']==task and x['method']=='Trim-SCAD' and x['status']=='ok'};b={x['rep']:x for x in real if x['task']==task and x['method']==comparator and x['status']=='ok'}
  ids=sorted(a.keys()&b.keys());d=[a[i]['test_rmse']-b[i]['test_rmse'] for i in ids]
  pairs.append(dict(task=task,contrast='Trim-SCAD minus '+comparator,n=len(d),mean=mean(d),sd=float(np.std(d,ddof=1)),differences=d))
short={'abalone':'Abalone','superconductivity_grouped':'Grouped SC'}
tex('real_revision2_table.tex',[[short[x['task']],x['method'],f"{x['success']}/10",fmt(x['rmse']),fmt(x['sd']),fmt(x['baseline'])] for x in rs])
tex('paired_revision2.tex',[[short[x['task']],x['contrast'],x['n'],fmt(x['mean']),fmt(x['sd'])] for x in pairs])
cost=read('matched_cost_runs.json');assert len(cost)==270
methods=['trim-scad','trim-lasso','vrmom-scad'];names={'trim-scad':'Trim-SCAD','trim-lasso':'Trim-Lasso','vrmom-scad':'VRMOM-SCAD'}
summ=[];memory=[]
for q in [.5,.7,.9]:
 for p in [1000,4000,10000]:
  for method in methods:
   a=[x for x in cost if x['q']==q and x['p']==p and x['method']==method];assert len(a)==10
   assert all(x['sampled_peak_rss_bytes']>0 for x in a)
   for x in a:
    assert all(t['payload_bytes']==16*(x['m']-1)*p*t['round'] for t in x['trace'])
   memory.append(dict(q=q,p=p,method=method,success=sum(x['status']=='ok' for x in a),seconds=med([x['seconds'] for x in a]),rss_mib=med([x['sampled_peak_rss_bytes']/2**20 for x in a]),rss_max_mib=max(x['sampled_peak_rss_bytes']/2**20 for x in a),setup_seconds=med([x['setup_seconds'] for x in a])))
   for target in [.1,.2]:
    hits=[]
    for x in a:
     trace=[dict(round=0,l2=x['initial_l2'],seconds=x['initial_seconds'],payload_bytes=0,status=x['initial_status'])]+x['trace']
     hit=next((t for t in trace if t['status']=='ok' and t['l2']<=target),None)
     if hit is not None:hits.append(hit)
    summ.append(dict(q=q,p=p,method=method,target=target,attained=len(hits),censored=10-len(hits),median_seconds=med([x['seconds'] for x in hits]),median_mb=med([x['payload_bytes']/1e6 for x in hits]),median_round=med([x['round'] for x in hits])))
tex('matched_cost_table.tex',[[x['q'],x['p'],names[x['method']],x['target'],f"{x['attained']}/10",fmt(x['median_seconds']),fmt(x['median_mb']),fmt(x['median_round'],1)] for x in summ])
tex('memory_table.tex',[[x['q'],x['p'],names[x['method']],f"{x['success']}/10",fmt(x['seconds']),fmt(x['rss_mib'],1),fmt(x['rss_max_mib'],1)] for x in memory])
fig,axs=plt.subplots(3,3,figsize=(10.2,6),layout='constrained')
for col,p in enumerate([1000,4000,10000]):
 for method,color,marker in zip(methods,['#326ea6','#b44838','#24816b'],['o','s','^']):
  a=[x for x in summ if x['p']==p and x['method']==method and x['target']==.1];q=[x['q'] for x in a]
  for row,key in enumerate(['attained','median_seconds','median_mb']):
   y=[(x[key]/10 if row==0 else x[key]) if x[key] is not None else np.nan for x in a]
   axs[row,col].plot(q,y,'-'+marker,color=color,label=names[method],markersize=4)
 axs[0,col].set_title(f'p = {p:,}',fontsize=10)
 for row in range(3):axs[row,col].set_xticks([.5,.7,.9]);axs[row,col].grid(alpha=.2)
 axs[0,col].set_ylim(-.05,1.05);axs[1,col].set_ylim(bottom=0);axs[2,col].set_ylim(bottom=0);axs[2,col].set_xlabel('Observation rate q')
axs[0,0].set_ylabel('Attained fraction');axs[1,0].set_ylabel('Median seconds');axs[2,0].set_ylabel('Median payload (MB)')
axs[0,1].legend(fontsize=7,loc='lower right')
fig.savefig(F/'matched_cost.pdf');fig.savefig(F/'matched_cost.png',dpi=180);plt.close(fig)
out=dict(local=local_summary,calibration=cs,real=rs,paired=pairs,cost=summ,memory=memory,checks=dict(all_admitted_candidate_bounds_cover=True,payloads_verified=True,cost_runs=270,real_selected=60,real_candidates=sum(len(x['candidates']) for x in real)))
(R/'revision2_summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(dict(local=local_summary,paired=pairs,checks=out['checks']),indent=2))
