"""Paired no-attack comparison of trimming budgets with a fixed penalty path."""
import argparse
import json
import os
import time
from pathlib import Path

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np

from robust_sparse import Node, aggregate, fit, initial

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results' / 'no_attack_budget.json'
BUDGETS = (0, 2, 4)
GRID = (0.3, 0.6, 1.2, 2.4)


def ar(rng, n, p, rho):
    x = rng.normal(size=(n, p))
    for j in range(1, p):
        x[:, j] = rho * x[:, j - 1] + np.sqrt(1 - rho * rho) * x[:, j]
    return x


def metrics(x, truth):
    selected = np.abs(x) > 1e-6
    support = truth != 0
    return dict(l2=float(np.linalg.norm(x - truth)),
                exact=bool(np.array_equal(selected, support)),
                fp=int(np.sum(selected & ~support)),
                fn=int(np.sum(~selected & support)))


def clean(value):
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items()}
    if isinstance(value, list):
        return [clean(v) for v in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def one_rep(rep):
    m, n, p, q, rho = 20, 120, 240, 0.7, 0.3
    seed = 20268008 + 10000 * 5 + rep  # The existing clean benchmark seed.
    rng = np.random.default_rng(seed)
    truth = np.zeros(p)
    truth[[0, 60, 120, 180]] = [1.2, -1.2, 1.2, -1.2]
    nodes = []
    for _ in range(m):
        x = ar(rng, n, p, rho)
        y = x @ truth + rng.normal(size=n)
        nodes.append(Node(x * (rng.random(x.shape) < q), y, q, dense=True))
    xv = ar(rng, 400, p, rho)
    yv = xv @ truth + rng.normal(size=400)
    xt = ar(rng, 2000, p, rho)
    yt = xt @ truth + rng.normal(size=2000)
    scale = np.std(nodes[0].y, ddof=1) / q
    starts = {factor: initial(nodes[0], scale, factor) for factor in GRID}
    scores = np.array([node.grad(truth) for node in nodes])
    mean_score = scores.mean(axis=0)
    records = []
    for b in BUDGETS:
        options = []
        for factor in GRID:
            coef, info = fit(
                nodes, scale, factor, 'trim', 'scad', b, 0, 'none', seed,
                init=starts[factor], penalty_budget=0,
            )
            val_mse = float(np.mean((yv - xv @ coef) ** 2)) if info['status'] == 'ok' else float('inf')
            options.append((val_mse, coef, factor, info))
        best = min(options, key=lambda item: item[0])
        val_mse, coef, factor, info = best
        successful = np.isfinite(val_mse)
        score = aggregate(scores, 'trim', b)
        records.append(dict(
            rep=rep, seed=seed, b=b, m_byzantine=0, successful=successful,
            selected_factor=factor if successful else None,
            validation_mse=val_mse if successful else None,
            l2=metrics(coef, truth)['l2'] if successful else None,
            exact=metrics(coef, truth)['exact'] if successful else False,
            fp=metrics(coef, truth)['fp'] if successful else None,
            fn=metrics(coef, truth)['fn'] if successful else None,
            test_mse=float(np.mean((yt - xt @ coef) ** 2)) if successful else None,
            score_inf=float(np.max(np.abs(score))),
            score_shift_inf=float(np.max(np.abs(score - mean_score))),
            candidates=[dict(factor=f, validation_mse=v if np.isfinite(v) else None,
                             status=i['status'], l2=metrics(x, truth)['l2'] if np.isfinite(v) else None,
                             exact=metrics(x, truth)['exact'] if np.isfinite(v) else False,
                             test_mse=float(np.mean((yt - xt @ x) ** 2)) if np.isfinite(v) else None,
                             trace=i.get('trace', []))
                        for v, x, f, i in options],
        ))
    return records


def main(reps):
    records = []
    started = time.time()
    for rep in range(reps):
        records.extend(one_rep(rep))
        payload = dict(
            description='Paired no-attack trimming-budget experiment',
            method='Trim-SCAD', budgets=list(BUDGETS), m=20, n=120, p=240,
            q=0.7, rho=0.3, validation_n=400, test_n=2000,
            penalty_budget=0,
            note='All budgets use the same observations, initializations, validation grid, and penalty path; only the number trimmed per tail changes.',
            records=records,
        )
        tmp = OUT.with_suffix('.tmp')
        tmp.write_text(json.dumps(clean(payload), indent=2), encoding='utf-8')
        tmp.replace(OUT)
        print(f'{rep + 1}/{reps} paired seeds; elapsed {time.time() - started:.1f}s', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--repeats', type=int, default=30)
    args = parser.parse_args()
    main(args.repeats)
