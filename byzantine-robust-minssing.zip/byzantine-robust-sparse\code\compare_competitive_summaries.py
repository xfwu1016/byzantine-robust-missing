"""Cross-check independently generated competitiveness summaries."""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(study):
    directory = ROOT/'results'
    prefix = 'competitive' if study == 'full' else 'competitive_sample_size'
    official_path = directory/f'{prefix}_summary.json'
    independent_path = directory/f'{prefix}_independent_summary.json'
    official = json.loads(official_path.read_text(encoding='utf-8'))
    independent = json.loads(independent_path.read_text(encoding='utf-8'))
    assert independent['complete'] and official['status'] == 'complete'
    assert official['input_sha256'] == independent['records_sha256']
    assert official['plan_sha256'] == independent['plan_sha256']
    numeric_checks = 0
    def equal(a, b, context):
        nonlocal numeric_checks
        if a is None or b is None:
            assert a is None and b is None, (context, a, b)
        else:
            assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (context, a, b)
        numeric_checks += 1
    mine = {(r['configuration'], r['method']): r for r in independent['summary']}
    other = {(r['configuration'], r['method']): r for r in official['summary']}
    assert mine.keys() == other.keys()
    for key, a in other.items():
        b = mine[key]
        for x, y in [('attempted', 'observed'), ('planned', 'planned'), ('success', 'successes'),
                     ('exact', 'exact_count'), ('candidate_count', 'candidates'),
                     ('candidate_failures', 'failed_candidates'), ('grid_low', 'low_edge'),
                     ('grid_high', 'high_edge')]:
            equal(a[x], b[y], (*key, x))
        for metric in ('l2', 'f1', 'test_mse', 'population_prediction_excess',
                       'selected_candidate_seconds', 'total_search_seconds',
                       'total_search_updates', 'total_search_vector_payload_bytes'):
            for stat in ('n', 'mean', 'se', 'median'):
                equal(a[metric][stat], b[metric][stat], (*key, metric, stat))
        for target, count in b['target_counts'].items():
            equal(a['targets'][target]['attained'], count, (*key, 'attainment', target))
            equal(a['targets'][target]['denominator'], b['observed'], (*key, 'denominator', target))
        for factor, count in b['selected_factors'].items():
            equal(a['selected_factor_counts'].get(factor, 0), count, (*key, 'factor', factor))
    paired = {(r['configuration'], r['proposed'], r['comparator']): r for r in independent['paired']}
    for a in official['paired']:
        key = (a['configuration'], a['proposed'], a['comparator'])
        b = paired[key]
        equal(a['common_success'], b['jointly_successful'], (*key, 'jointly successful'))
        for stat in ('n', 'mean', 'se', 'median'):
            equal(a['l2_difference'][stat], b['l2_difference'][stat], (*key, stat))
        equal(a['proposed_lower_error'], b['negative_count'], (*key, 'negative differences'))

    spectra = defaultdict(dict)
    records_path = directory/f'competitive_{study}.jsonl'
    with records_path.open(encoding='utf-8') as stream:
        for line in stream:
            r = json.loads(line)
            cf, seed = r['configuration']['label'], r['seed']
            value = r['dataset']['master_min_eigenvalue']
            if seed in spectra[cf]:
                equal(value, spectra[cf][seed], (cf, seed, 'shared master eigenvalue'))
            spectra[cf][seed] = value
    for a in official['configuration_diagnostics']:
        cf = a['configuration']; values = spectra[cf]
        equal(a['distinct_seed_count'], len(values), (cf, 'unique sample count'))
        equal(a['negative_master_eigenvalue_count'], sum(v < 0 for v in values.values()), (cf, 'negative curvature count'))
        equal(a['master_min_eigenvalue_range'][0], min(values.values()), (cf, 'minimum eigenvalue'))
        equal(a['master_min_eigenvalue_range'][1], max(values.values()), (cf, 'maximum eigenvalue'))
    report = dict(created_utc=datetime.now(timezone.utc).isoformat(), study=study, passed=True,
                  summary_cells=len(other), paired_cells=len(official['paired']),
                  configuration_diagnostics=len(spectra), numeric_checks=numeric_checks,
                  official_sha256=hashlib.sha256(official_path.read_bytes()).hexdigest(),
                  independent_sha256=hashlib.sha256(independent_path.read_bytes()).hexdigest(),
                  records_sha256=independent['records_sha256'])
    (directory/f'{prefix}_summary_crosscheck.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--study', choices=('full', 'sample_size'), default='full')
    run(p.parse_args().study)
