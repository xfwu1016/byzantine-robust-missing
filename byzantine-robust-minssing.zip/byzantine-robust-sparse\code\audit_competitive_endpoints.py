"""Post-fitting diagnostics of ALL saved selected Trim-SCAD/MCP paths.

No optimization, selection, or new samples. Regenerate saved data from the frozen
generator, verify its digest, reconstruct messages and weights, and evaluate
Theorem 3. Truth and honest identities are used only by this diagnostic.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import json, math, hashlib, time
from pathlib import Path
from collections import defaultdict
import numpy as np
import competitive_benchmark as bench
import robust_sparse as core

ROOT=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def run():
    groups=defaultdict(list); source_hashes={}
    for study in ['competitive_full','competitive_sample_size']:
        path=ROOT/'results'/f'{study}.jsonl';source_hashes[path.name]=sha(path)
        with path.open() as f:
            for line in f:
                r=json.loads(line)
                if r['method'] not in ['Trim-SCAD','Trim-MCP']:continue
                selected=r['candidates'][r['selected_index']] if r['selected_index'] is not None else None
                keep={k:r.get(k) for k in ['configuration','seed','dataset','method','status','scale','factor','outer_coefficients','l2','exact']}
                keep.update(study=study,selected=selected)
                groups[r['dataset']['data_sha256']].append(keep)
    summaries=defaultdict(list);max_residual_difference=0.;checked=0;start=time.time()
    target=ROOT/'results/competitive_endpoint_audit.jsonl'
    with target.open('w') as stream:
        for gi,(digest,records) in enumerate(groups.items()):
            example=records[0]; data=bench.make_data(example['configuration'],example['seed'])
            nodes,_,_,_,_,_,truth,direction,_,meta=data
            assert meta['data_sha256']==digest
            master=nodes[0];p=master.p;s=int(np.count_nonzero(truth))
            ratio=float(master.diag.max()/master.diag.min())
            Klower=2*s+math.ceil((32/3)**2*(ratio-1)**2*s)
            impossible=(4*Klower>=p and meta['master_min_eigenvalue']<0)
            for r in records:
                cf=r['configuration'];f=cf['f'];b=cf['b'];m=cf['m']
                record=dict(study=r['study'],configuration=cf['label'],method=r['method'],seed=r['seed'],
                            data_sha256=digest,status=r['status'],uniform_condition_impossible=bool(impossible),
                            necessary_K_lower_bound=Klower,master_min_eigenvalue=meta['master_min_eigenvalue'])
                if r['status']=='ok':
                    honest=nodes[:m-f];G=np.mean([v.gram for v in honest],axis=0)
                    score=np.array([v.grad(truth) for v in honest]);gmean=score.mean(0)
                    Ds=np.array([v.gram-G for v in honest]);om=3*b/(m-2*b)
                    coefs=np.array(r['outer_coefficients']);R=float(np.linalg.norm(coefs[0]-truth));rounds=[]
                    local=r['factor']*r['scale']*np.sqrt(np.log(p)/master.n)
                    floor=r['factor']*r['scale']*(np.sqrt(np.log(p)/(m*master.n))+(b/m)*np.sqrt(np.log(p)/master.n))
                    for t in range(8):
                        prev,x=coefs[t],coefs[t+1]
                        U=np.union1d(np.flatnonzero(truth),np.flatnonzero(x));W=np.union1d(np.flatnonzero(truth),np.flatnonzero(prev));rt=len(U)
                        kap=float(np.linalg.eigvalsh(master.gram[np.ix_(U,U)])[0])
                        raw=np.array([v.grad(prev) for v in nodes]);sent=core.attack(raw,f,cf['attack'],t,r['seed'],direction)
                        g=core.aggregate(sent,'trim',b);c=master.mv(prev)-g
                        target_lam=max(floor,local*.65**(t+1));base=max(target_lam,local*.65**t)
                        weights=core.penalty_weights(prev,base,'scad' if r['method']=='Trim-SCAD' else 'mcp')*(target_lam/base)
                        eps=core.kkt(master.mv(x)-c,x,weights)
                        saved=r['selected']['trace'][t]
                        discrepancy=abs(eps-saved['kkt']);max_residual_difference=max(max_residual_difference,discrepancy)
                        assert discrepancy<2e-8,(cf,r['seed'],t,eps,saved['kkt'])
                        assert abs(target_lam-saved['lambda_value'])<1e-12
                        assert eps<=min(1e-5,target_lam/1000)+2e-8
                        dblocks=Ds[:,U][:,:,W]
                        a=float(np.max(np.abs(gmean[U])));tau=float(np.max(np.abs(score[:,U]-gmean[U])))
                        d=float(np.max(np.linalg.norm(dblocks,axis=2)));mismatch=float(np.linalg.norm(dblocks[0],ord=2))
                        err=float(np.linalg.norm(x-truth));prev_err=float(np.linalg.norm(prev-truth))
                        alpha=zeta=rhs=None
                        if kap>0:
                            alpha=(mismatch+om*np.sqrt(rt)*d)/kap
                            zeta=(np.sqrt(rt)*(a+om*tau+eps)+np.linalg.norm(weights[U]))/kap
                            rhs=alpha*prev_err+zeta
                            assert err<=rhs+1e-8
                            R=alpha*R+zeta if R is not None else None
                        else:R=None
                        rounds.append(dict(round=t+1,kappa=kap,alpha=alpha,zeta=zeta,a=a,tau=tau,d=d,
                                           curvature_mismatch=mismatch,residual=eps,support=int(np.count_nonzero(x)),
                                           union_support=rt,previous_union_support=len(W),error=err,
                                           one_step_rhs=rhs,recursive_bound=R,stored_max_inner_support=saved['max_support']))
                        checked+=1
                    record.update(rounds=rounds,all_positive_curvature=all(z['kappa']>0 for z in rounds),
                                  all_contractive=all(z['alpha'] is not None and z['alpha']<1 for z in rounds),
                                  max_inner_support=max([r['selected']['initial']['max_support']]+[z['stored_max_inner_support'] for z in rounds]),
                                  initial_error=float(np.linalg.norm(coefs[0]-truth)),final_error=r['l2'])
                stream.write(json.dumps(bench.clean(record))+'\n')
                summaries[r['study'],cf['label'],r['method']].append(record)
            if (gi+1)%30==0:print(f'data groups {gi+1}/{len(groups)}; endpoints {checked}; elapsed {time.time()-start:.1f}s',flush=True)
    rows=[]
    for (study,cf,method),recs in summaries.items():
        ok=[r for r in recs if r['status']=='ok'];rr=[z for r in ok for z in r['rounds']]
        alphas=[z['alpha'] for z in rr if z['alpha'] is not None]
        rows.append(dict(study=study,configuration=cf,method=method,repetitions=len(recs),success=len(ok),
                         uniform_impossible=sum(r['uniform_condition_impossible'] for r in recs),
                         positive_paths=sum(r.get('all_positive_curvature',False) for r in recs),
                         contractive_paths=sum(r.get('all_contractive',False) for r in recs),
                         positive_endpoints=sum(z['kappa']>0 for z in rr),endpoints=len(rr),
                         min_kappa=min((z['kappa'] for z in rr),default=None),
                         alpha_range=[min(alphas),max(alphas)] if alphas else None,
                         max_zeta=max((z['zeta'] for z in rr if z['zeta'] is not None),default=None),
                         max_residual=max((z['residual'] for z in rr),default=None),
                         max_support=max((r['max_inner_support'] for r in ok),default=None)))
    result=dict(description=__doc__,source_hashes=source_hashes,distinct_data_groups=len(groups),
                records=sum(len(r) for r in summaries.values()),endpoints_checked=checked,
                maximum_residual_reconstruction_difference=max_residual_difference,summary=rows,
                audit_code_sha256=sha(Path(__file__)),generator_sha256=sha(ROOT/'code/competitive_benchmark.py'),
                core_sha256=sha(ROOT/'code/robust_sparse.py'),numpy=np.__version__,elapsed_seconds=time.time()-start)
    (ROOT/'results/competitive_endpoint_summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='summary'},indent=2))
    for r in rows:
        if r['configuration'] in ['q0.7_f2_gaussian','q0.7_f2_stealth']:print(r)

if __name__=='__main__':run()
