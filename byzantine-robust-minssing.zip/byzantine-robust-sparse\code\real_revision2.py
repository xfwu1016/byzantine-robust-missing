"""Independent second task and composition-grouped superconductivity splits."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,zipfile,hashlib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from robust_sparse import Node
from run_revision import candidates,clean
ROOT=Path(__file__).resolve().parents[1]
METHODS=[('Trim-SCAD','trim','scad'),('Trim-Lasso','trim','lasso'),('VRMOM-SCAD','vrmom','scad')]
def load():
 with zipfile.ZipFile(ROOT/'data/abalone.zip') as z:
  a=pd.read_csv(z.open('abalone.data'),header=None)
 ab=a.iloc[:,1:].to_numpy(float)
 with zipfile.ZipFile(ROOT/'data/superconductivity.zip') as z:
  sc=pd.read_csv(z.open('train.csv')).to_numpy(float);u=pd.read_csv(z.open('unique_m.csv'))
 assert np.allclose(sc[:,-1],u['critical_temp'])
 composition=u.drop(columns=['critical_temp','material']).to_numpy(float)
 composition=np.round(composition/composition.sum(axis=1,keepdims=True),10)
 _,groups=np.unique(composition,axis=0,return_inverse=True)
 return ab,sc,groups
def run():
 ab,sc,groups=load();records=[]
 for task in ['abalone','superconductivity_grouped']:
  for rep in range(10):
   seed=20263009+rep;rng=np.random.default_rng(seed);q=.7
   if task=='abalone':
    data=ab;m=10;ids=rng.permutation(len(data));it,iv,ie=ids[:2400],ids[2400:3200],ids[3200:]
    groupinfo=None
   else:
    data=sc;m=20;g=rng.permutation(np.unique(groups));a=int(.7*len(g));b=int(.85*len(g))
    it=np.flatnonzero(np.isin(groups,g[:a]));iv=np.flatnonzero(np.isin(groups,g[a:b]));ie=np.flatnonzero(np.isin(groups,g[b:]));rng.shuffle(it)
    assert not (set(groups[it])&set(groups[iv]) or set(groups[it])&set(groups[ie]) or set(groups[iv])&set(groups[ie]))
    groupinfo=dict(total_groups=len(g),train_groups=a,val_groups=b-a,test_groups=len(g)-b)
   n=len(it)//m;it=it[:n*m];train=data[it];val=data[iv];test=data[ie]
   mu=train[:,:-1].mean(0);sd=train[:,:-1].std(0);sd[sd==0]=1
   my=train[:,-1].mean();sy=train[:,-1].std();x=(train[:,:-1]-mu)/sd;y=(train[:,-1]-my)/sy
   xv=(val[:,:-1]-mu)/sd;yv=(val[:,-1]-my)/sy;xt=(test[:,:-1]-mu)/sd;p=x.shape[1]
   nodes=[Node(x[j*n:(j+1)*n]*(rng.random((n,p))<q),y[j*n:(j+1)*n],q,True) for j in range(m)]
   for name,agg,pen in METHODS:
    coef,info=candidates(nodes,xv,yv,np.std(nodes[0].y,ddof=1)/q,agg,pen,m//10,m//10,'gaussian',seed)
    rmse=float(np.sqrt(np.mean((test[:,-1]-my-sy*(xt@coef))**2)))
    records.append(dict(task=task,rep=rep,seed=seed,method=name,p=p,m=m,n=n,val_n=len(iv),test_n=len(ie),groups=groupinfo,test_rmse=rmse,constant_rmse=float(np.sqrt(np.mean((test[:,-1]-my)**2))),**info))
   print(task,rep,flush=True)
   (ROOT/'results/real_revision2.json').write_text(json.dumps(clean(dict(records=records,grid=[.3,.6,1.2,2.4],q=q,notes='Abalone uses seven continuous measurements; target rings. Grouped superconductivity splits normalized element-composition groups. Training-only complete scaling then artificial MCAR; full validation/test covariates. Shared splits, masks and attack seeds.')),indent=2))
if __name__=='__main__':
 with threadpool_limits(limits=1):run()
