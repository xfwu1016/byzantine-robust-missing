"""Known-valid indefinite quadratic certificate; not an MCAR simulation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import certified_select
ROOT=Path(__file__).resolve().parents[1]
class Quadratic:
 def __init__(self,truth,score):
  self.p=len(truth);self.gamma=self.mv(truth)-score
 def mv(self,x):return x-1.2*np.sum(x)/self.p
 def grad(self,x):return self.mv(x)-self.gamma
def run():
 records=[]
 for rep in range(30):
  rng=np.random.default_rng(20261209+rep);p=4000;truth=np.zeros(p);amp=rng.uniform(.05,1.2);truth[:2]=[amp,-amp]
  score=rng.uniform(-.001,.001,p);nodes=[Quadratic(truth,score) for _ in range(10)]
  xv=rng.normal(size=(300,p));yv=xv@truth+.2*rng.normal(size=300)
  # All honest gradients coincide, so trimming one arbitrary message returns
  # their value exactly. A=.002, B=.005 are valid, conservative known bounds.
  x,info=certified_select(nodes,xv,yv,.002,.005,2.,.98,1.,2,inflations=(1.,2.,4.,8.,10.),rounds=8,b=1,f=1,attack_kind='gaussian',seed=rep)
  chosen=info['candidates'][info['selected_index']];radius=chosen['trace'][-1]['radius']
  assert info['rejected_inflations']==[10.]
  assert chosen['validation_mse']==min(z['validation_mse'] for z in info['candidates'])
  assert np.linalg.norm(x-truth)<=radius+1e-9
  for opt in info['candidates']:
   assert 1-1.2*min(4*opt['K'],p)/p>=.98
   assert all(z['max_support']<=opt['K'] for z in opt['trace'])
  records.append(dict(rep=rep,amplitude=amp,l2=float(np.linalg.norm(x-truth)),radius=radius,**info))
 (ROOT/'results'/'certified_selection.json').write_text(json.dumps(dict(records=records,global_min_eigen=-.2,notes='Known-valid algebraic certificate; identical honest Hessians/score. Not a statistical calibration claim.'),indent=2))
 print('30 known-valid selection checks passed')
if __name__=='__main__':
 with threadpool_limits(limits=1):run()
