"""Actual single-host process transport and complete surrogate solves.
No network latency emulation; no multi-machine speedup claim.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import time,json,platform,multiprocessing as mp
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import Node,initial,aggregate,attack,homotopy,penalty_weights
ROOT=Path(__file__).resolve().parents[1]
def make(n,p,seed):
 rng=np.random.default_rng(seed);truth=np.zeros(p);truth[:4]=[1.2,-1.2,1.2,-1.2]
 x=rng.normal(size=(n,p));y=x@truth+rng.normal(size=n);x*=rng.random(x.shape)<.7
 return Node(x,y,.7),truth
def worker(conn,n,p,seed):
 with threadpool_limits(limits=1):
  node,_=make(n,p,seed);conn.send_bytes(b'ready')
  while True:
   buf=conn.recv_bytes()
   if not buf:break
   conn.send_bytes(node.grad(np.frombuffer(buf,dtype=np.float64)).tobytes())
 conn.close()
def run(m,n,p,rep):
 ctx=mp.get_context('spawn');conns=[];procs=[];t0=time.perf_counter();seed=20261109+rep*100
 master,truth=make(n,p,seed)
 for j in range(1,m):
  a,c=ctx.Pipe();proc=ctx.Process(target=worker,args=(c,n,p,seed+j));proc.start();c.close();conns.append(a);procs.append(proc)
 for c in conns:assert c.recv_bytes()==b'ready'
 setup=time.perf_counter()-t0;records=[];b=f=max(1,m//4)
 try:
  methods=[('trim','scad'),('trim','lasso'),('vrmom','scad')]
  np.random.default_rng(seed+991).shuffle(methods)
  for agg,pen in methods:
   start=time.perf_counter();scale=np.std(master.y,ddof=1)/.7;factor=.6
   x,local,ini=initial(master,scale,factor);initsecs=time.perf_counter()-start;trace=[];totalbytes=0
   floor=factor*scale*(np.sqrt(np.log(p)/(m*n))+(b/m)*np.sqrt(np.log(p)/n))
   if ini['status']=='ok':
    for t in range(8):
     tick=time.perf_counter();buf=x.tobytes()
     for c in conns:c.send_bytes(buf)
     localg=master.grad(x);received=[c.recv_bytes() for c in conns]
     messages=np.vstack([localg]+[np.frombuffer(z,dtype=np.float64) for z in received]);commgrad=time.perf_counter()-tick
     totalbytes+=len(buf)*(m-1)+sum(map(len,received));tick=time.perf_counter()
     sent=attack(messages,f,'gaussian',t,seed)
     g=aggregate(sent,agg,b,master.score_sd(x) if agg=='vrmom' else None,n);aggsecs=time.perf_counter()-tick
     cvec=master.mv(x)-g;target=max(floor,local*.65**(t+1));base=max(target,local*.65**t);tick=time.perf_counter()
     x,info=homotopy(master,cvec,x,penalty_weights(x,base,pen),base,target)
     trace.append(dict(round=t+1,status=info['status'],l2=float(np.linalg.norm(x-truth)),seconds=time.perf_counter()-start,payload_bytes=totalbytes,communication_gradient_seconds=commgrad,aggregation_seconds=aggsecs,inner_seconds=time.perf_counter()-tick,inner_iterations=info['iterations']))
     if info['status']!='ok':break
   records.append(dict(m=m,n=n,p=p,rep=rep,seed=seed,method=agg+'-'+pen,setup_seconds=setup,initial_seconds=initsecs,initial_status=ini['status'],status=trace[-1]['status'] if trace else ini['status'],seconds=time.perf_counter()-start,l2=float(np.linalg.norm(x-truth)),payload_bytes=totalbytes,trace=trace,design_array_bytes=m*n*p*8,avoided_dense_gram_bytes=m*p*p*8))
 finally:
  for c in conns:c.send_bytes(b'');c.close()
  for proc in procs:proc.join(timeout=30);assert proc.exitcode==0
 return records
if __name__=='__main__':
 allrecords=[]
 with threadpool_limits(limits=1):
  for m,n,p in [(4,2048,1000),(8,1024,1000),(16,512,1000),(8,1024,4000),(8,1024,10000)]:
   for rep in range(3):
    allrecords+=run(m,n,p,rep)
    print('end-to-end',m,n,p,rep,flush=True)
    (ROOT/'results'/'end_to_end.json').write_text(json.dumps(dict(records=allrecords,single_host=True,platform=platform.platform(),logical_cpus=os.cpu_count(),notes='Fixed factor .6, 25% Gaussian Byzantine messages, eight rounds, randomized method order, one BLAS thread; solve timing includes initialization, transport and all inner homotopy iterations, excludes worker setup; float64 payload excludes framing.'),indent=2))
