# Byzantine-Robust Sparse Regression with Missing Covariates — reproduction code

Code and data for the manuscript **"Byzantine-Robust Sparse Regression with Missing Covariates"**
(Xiaofei Wu, Jian Qing Shi), submitted to *Statistica Sinica*.

This repository contains everything needed to reproduce the numerical results:
the corrected-moment solver, all experiment drivers, post-fit audits, table and
figure generators, and the two public datasets.

## Repository layout

```
code/            Python implementation and experiment scripts (see code/README.md)
data/            Bundled UCI datasets + provenance (CC BY 4.0)
results/         Frozen summary JSON files from the manuscript (see results/README.md)
figures/         Output directory for regenerated figures (empty by default)
```

## Requirements

- Python 3.10 or newer
- NumPy, SciPy, threadpoolctl, pandas (experiments)
- matplotlib (figures), reportlab (vector tables/figures in `revision29_displays.py`)
- About 25 MB in total, including the 8 MB of data archives; the full
  benchmark writes a raw JSONL record of roughly 180 MB

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate     macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Pinned versions match the manuscript's experiment environment
(NumPy 2.3.5, SciPy 1.18.1, matplotlib 3.11.2, threadpoolctl 3.7.0,
pandas 3.0.1, reportlab 4.4.9). Newer versions should work but have not
been certified.

## Data

`data/superconductivity.zip` and `data/abalone.zip` are the unchanged UCI
archives (CC BY 4.0). See [data/PROVENANCE.md](data/PROVENANCE.md) for the
licence, attribution, retrieval dates, SHA-256 checksums, and the processing
steps applied at analysis time. `code/download_data.py` re-downloads both
archives if needed; it is not required when the bundled files are present.

## Quick start

```bash
python code/smoke_test.py
```

The smoke test takes seconds and needs no data. It checks the matrix-free and
dense corrected moments, the mean/trim/median/VRMOM aggregation identities, and
the envelope policy on the constructed indefinite quadratic with negative global
curvature.

A pilot run of the main comparison (three configurations, two seeds each) takes
minutes:

```bash
python code/competitive_benchmark.py --mode pilot --repeats 2
python code/summarize_competitive.py --study main
```

Note: `competitive_benchmark.py` refuses to overwrite an existing plan. To rerun
from scratch, delete `results/competitive_*_plan.json` in a working copy, or
work in a separate copy of the repository.

## Reproducing the paper results

All commands are run from the repository root. Experiment drivers create
`results/` files; summary and figure scripts read them. The order matters.

### Main comparison and sample-size follow-up

| Step | Command | Main output |
|---|---|---|
| Main benchmark (full) | `python code/competitive_benchmark.py --mode full --repeats 30` | `results/competitive_full.jsonl` |
| Summaries and tables | `python code/summarize_competitive.py --study main` | `results/competitive_summary.json`, `results/competitive_tables.tex` |
| Sample-size follow-up | `python code/competitive_sample_size.py` (requires the primary plan) | `results/competitive_sample_size.jsonl` |
| Follow-up summaries | `python code/summarize_competitive.py --study sample_size` | `results/competitive_sample_size_summary.json` |
| Main-text figures | `python code/main_empirical_figures.py` (after `path_audit.py`) | `figures/*.pdf` |
| Vector tables/figures | `python code/revision29_displays.py` (needs the full JSONL) | `results/*.tex`, `figures/*.pdf` |

The full benchmark is 23 configurations x 9 methods x 30 paired repetitions and
can take hours to days on one machine. `--mode pilot --repeats 2` exercises the
same code path in minutes. The sample-size follow-up uses 6 configurations x
9 methods x 30 new seeds.

### Theory checks

| Step | Command | Main output |
|---|---|---|
| MCAR conditional-theory study | `python code/theory_mcar_experiment.py` | `results/theory_mcar.json` |
| Indefinite quadratic checks | `python code/theory_indefinite_experiment.py` | `results/theory_indefinite.json` |
| Score-variance identity | `python code/theory_variance_experiment.py` | `results/theory_variance.json` |
| Theory figure | `python code/plot_theory_validation.py` | `figures/theory_validation.pdf` |
| Variance figure | `python code/plot_score_variance.py` | `figures/score_variance_empirical.pdf` |

The MCAR study is the expensive one: it uses local sample sizes of 2e4, 8e4 and
3.2e5 with 20 prespecified samples per setting.

### Sensitivity, ablation and real data

| Step | Command | Main output |
|---|---|---|
| Unequal node sizes | `python code/reviewer_experiments.py unequal` | `results/reviewer_unequal.json` |
| Masked calibration | `python code/reviewer_experiments.py calibration` | `results/reviewer_calibration.json` |
| No-attack trimming budget | `python code/no_attack_budget.py` | `results/no_attack_budget.json` |
| Active-support bridge audit | `python code/bridge_experiment.py` | `results/bridge_audit.json` |
| Local certificates / calibration | `python code/certificate_experiments.py` | `results/local_certificates.json`, `results/calibration_certificates.json` |
| Path and component audit | `python code/path_audit.py` | `results/path_ablation.json` (about 70 MB) |
| Real data (superconductivity) | `python code/run_revision.py` | `results/revision_real.json`, `results/revision_synthetic.json` |
| Real data (abalone, grouped) | `python code/real_revision2.py` | `results/real_revision2.json` |
| Sensitivity figure | `python code/summarize_revision2.py`, `python code/make_strengthened_figures.py` | `figures/*.pdf` |

### Cost benchmarks

| Step | Command | Main output |
|---|---|---|
| End-to-end pipes benchmark | `python code/benchmark_end_to_end.py` | `results/end_to_end.json` |
| Matched-accuracy cost | `python code/benchmark_matched_cost.py` | `results/matched_cost_runs.json` |
| Scaling microbenchmark | `python code/benchmark_scaling.py` | `results/scaling.json` |

These are single-host measurements; the paper does not claim a multi-host
network benchmark.

### Verification scripts

The audit scripts re-read saved records and check the reported quantities:

- `audit_competitive_endpoints.py` verifies the endpoint recursion on selected paths.
- `audit_reference_curvature.py` rechecks the sparse-curvature condition on the reference data.
- `audit_results.py` recomputes reported summaries and compares them with the stored values.
- `check_competitive_results.py`, `check_slard_baseline.py`, `check_unequal_sizes.py`,
  `check_sampled_curvature.py`, `check_observable_certificates.py`,
  `check_certified_selection.py`, `check_review_theory.py` run targeted checks.
- `compare_competitive_summaries.py` compares the official and independent summaries.

Most of these need the corresponding raw JSONL records and are therefore run
after the experiment drivers, not from the frozen summaries alone.

### Regenerating the vector tables and figures

`main_empirical_figures.py` and `revision29_displays.py` are the two display
generators for the paper. They require the raw experiment records
(`competitive_full.jsonl`, `path_ablation.json`), so they run at the end of the
pipeline. The vector artwork uses DejaVu Sans, bundled in `code/assets/`, so it
does not depend on installed system fonts; Arial is used instead when present.

## Frozen results

`results/` contains the small summary JSON files from the manuscript as shipped
for reference (about 15 MB). They let readers inspect the final numbers and
compare with regenerated outputs without downloading the raw traces. Raw JSONL
records (`competitive_full.jsonl` about 176 MB, `competitive_sample_size.jsonl`
about 42 MB, `path_ablation.json` about 70 MB) are not distributed; regenerate
them with the drivers above. See [results/README.md](results/README.md) for the
file-to-script mapping.

## Portability and runtime notes

- The code runs on Windows, macOS and Linux. The cost benchmarks use
  `multiprocessing` pipes on a single host and therefore need the standard
  `if __name__ == "__main__"` guard used in those scripts.
- `revision29_displays.py` was originally written for Windows Arial; it now
  falls back to the bundled DejaVu fonts on other platforms.
- Thread counts are pinned to one BLAS thread by the drivers to match the
  manuscript timings.
- Timings depend on hardware; the paper reports medians on one machine and makes
  no claim about absolute throughput.

## Licence and citation

The code is released under the MIT Licence (see [LICENSE](LICENSE)). The two
datasets keep their original CC BY 4.0 licence and attribution as documented in
[data/PROVENANCE.md](data/PROVENANCE.md).

Until the paper is published, please cite the manuscript:

> Wu, Xiaofei and Shi, Jian Qing (2026). Byzantine-Robust Sparse Regression with
> Missing Covariates. Manuscript submitted to *Statistica Sinica*.

A `CITATION.cff` file is provided for GitHub's citation button.

## Contact

Xiaofei Wu, Yunnan University, xfwu1016@ynu.edu.cn
Jian Qing Shi (corresponding author), Beijing Normal-Hong Kong Baptist University,
jianqingshi@bnbu.edu.cn

## AI-assistance disclosure

OpenAI Codex assisted with the development of parts of the experiment, audit and
figure code; the authors reviewed and approved the final code and results. This
disclosure matches the manuscript and supplement.
