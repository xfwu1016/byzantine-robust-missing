from pathlib import Path
import json
import numpy as np
R=Path(__file__).resolve().parents[1]
d=json.loads((R/'results/scaling.json').read_text());rows=[]
for key in dict.fromkeys((x['axis'],x['m'],x['n'],x['p']) for x in d['records']):
 a=[x for x in d['records'] if (x['axis'],x['m'],x['n'],x['p'])==key]
 vals=[x['mean_round_seconds']*1000 for x in a]
 rows.append(dict(axis=key[0],m=key[1],n=key[2],p=key[3],ms=float(np.mean(vals)),sd=float(np.std(vals,ddof=1)),payload_mb=a[0]['payload_bytes']/20/1e6))
lines=[r'\begin{center}\small\begin{tabular}{lrrrrr}\toprule',r'Sweep & Workers & Local $n$ & $p$ & Round ms (mean $\pm$ SD) & MB/round\\\midrule']
for x in rows:
 lines.append(f"{x['axis']} & {x['m']} & {x['n']} & {x['p']} & ${x['ms']:.2f}\\pm{x['sd']:.2f}$ & {x['payload_mb']:.3f} \\\\")
lines += [r'\bottomrule\end{tabular}\end{center}', 'Platform: '+d['platform'].replace('_',r'\_')+'. Logical CPUs: '+str(d['logical_cpus'])+'. Each worker uses one BLAS thread. There are three repetitions per configuration; variability is across repetitions of the mean of 20 exchanges.']
(R/'results/scaling_report.tex').write_text('\n'.join(lines))
(R/'results/scaling_summary.json').write_text(json.dumps(rows,indent=2))
