import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import time,json
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
import robust_sparse as rs
from certificates import local_certificate,calibration_certificate
from run_revision import ar,clean
ROOT=Path(__file__).resolve().parents[1]
GRID=[.3,.6,1.2,2.4]
ORIGINAL_STAGE=rs.stage
STAGES=[]
def audited_stage(node,c,w,x,tol,step_upper=None,max_iter=1200):
 out,info=ORIGINAL_STAGE(node,c,w,x,tol,step_upper,max_iter)
 cert=local_certificate(node,c,w,out) if info['status']=='ok' else dict(passed=False)
 STAGES.append(dict(status=info['status'],max_support=info['max_support'],certificate=cert))
 return out,info
def fit_audited(nodes,scale,factor,seed):
 STAGES.clear();rs.stage=audited_stage
 try:x,info=rs.fit(nodes,scale,factor,'trim','scad',2,2,'gaussian',seed)
 finally:rs.stage=ORIGINAL_STAGE
 return x,dict(info,stage_audit=list(STAGES))
def reference():
 records=[]
 for rep in range(30):
  seed=20268008+rep;rng=np.random.default_rng(seed);p=240;n=120;m=20;q=.7
  truth=np.zeros(p);truth[[0,60,120,180]]=[1.2,-1.2,1.2,-1.2];nodes=[]
  for j in range(m):
   x=ar(rng,n,p,.3);y=x@truth+rng.normal(size=n);nodes.append(rs.Node(x*(rng.random(x.shape)<q),y,q,True))
  xv=ar(rng,400,p,.3);yv=xv@truth+rng.normal(size=400);opts=[]
  for fac in GRID:
   x,info=fit_audited(nodes,np.std(nodes[0].y,ddof=1)/q,fac,seed)
   opts.append((np.mean((yv-xv@x)**2) if info['status']=='ok' else np.inf,x,info,fac))
  val,x,info,fac=min(opts,key=lambda z:z[0]);st=info['stage_audit']
  sensitivity={str(t):dict(exact=bool(np.array_equal(np.abs(x)>t,truth!=0)),selected=int(np.sum(np.abs(x)>t))) for t in [1e-8,1e-6,1e-4,1e-3]}
  records.append(dict(rep=rep,seed=seed,factor=fac,l2=float(np.linalg.norm(x-truth)),all_stages_pass=all(z['certificate']['passed'] for z in st),stage_count=len(st),stages_pass=sum(z['certificate']['passed'] for z in st),max_prefix_support=max(z['max_support'] for z in st),thresholds=sensitivity,stage_audit=st))
  if rep%10==9:print('reference certificates',rep+1,flush=True)
 (ROOT/'results'/'local_certificates.json').write_text(json.dumps(clean(dict(records=records,notes='Same reference generator and validation grid; certificates added after unchanged stage solves. A passing stage certifies fixed-step continuation from its endpoint.')),indent=2))
def calibrated():
 records=[]
 for q in [.5,.7,.9]:
  for rep in range(10):
   seed=20262009+1000*int(q*10)+rep;rng=np.random.default_rng(seed);p=240;n=120;m=20
   truth=np.zeros(p);truth[0]=1.2;nodes=[]
   for j in range(m):
    x=rng.choice([-1.,1.],size=(n,p));y=x@truth+rng.uniform(-.2,.2,n);nodes.append(rs.Node(x*(rng.random(x.shape)<q),y,q,True))
   candidates=[];candidate_audits=[]
   for fac in GRID:
    x,info=fit_audited(nodes,np.std(nodes[0].y,ddof=1)/q,fac,seed)
    candidates.append(x);candidate_audits.append(dict(factor=fac,status=info['status'],all_stages_pass=all(z['certificate']['passed'] for z in info['stage_audit']),final_stage_pass=info['stage_audit'][-1]['certificate']['passed']))
   # Fresh masked holdout, never used by fitting, attackers, or candidate grid.
   Gsum=np.zeros((p,p));gsum=np.zeros(p);N=0
   for target in [1000,10000,50000]:
    while N<target:
     size=min(5000,target-N);xx=rng.choice([-1.,1.],size=(size,p));yy=xx@truth+rng.uniform(-.2,.2,size);zz=xx*(rng.random(xx.shape)<q)
     Gsum+=zz.T@zz;gsum+=zz.T@yy;N+=size
    A=Gsum/N;G=(A-(1-q)*np.diag(np.diag(A)))/q**2;gamma=gsum/(N*q)
    certs=calibration_certificate(G,gamma,candidates,N,q,1.,1.4,1)
    admissible=[i for i,z in enumerate(certs) if z['passed'] and candidate_audits[i]['status']=='ok' and candidate_audits[i]['final_stage_pass']]
    selected=min(admissible,key=lambda i:certs[i]['radius']) if admissible else None
    rec=dict(q=q,rep=rep,seed=seed,calibration_n=N,candidates=[dict(c,**a,l2=float(np.linalg.norm(x-truth)),covered=bool(c['radius'] is not None and np.linalg.norm(x-truth)<=c['radius'])) for c,a,x in zip(certs,candidate_audits,candidates)],selected_index=selected)
    records.append(rec)
   if rep==9:print('calibration certificates',q,flush=True)
  (ROOT/'results'/'calibration_certificates.json').write_text(json.dumps(clean(dict(records=records,p=240,local_n=120,m=20,s=1,H=1,Ymax=1.4,delta=.05,notes='Known design bounds; independent masked calibration; all acceptance and selection inputs observable. Truth used only for evaluation. Coverage guarantee is per predeclared calibration size, not optional stopping over sizes.')),indent=2))
if __name__=='__main__':
 with threadpool_limits(limits=1):reference();calibrated()
