"""Main-paper figures from saved experiments; no fitting or data generation.

The path figure shows both prespecified local-sample-size settings with every
selected repetition. The imbalance figure shows every Trim-SCAD allocation
cell. Other configurations and methods remain in the supplementary results.
"""
from pathlib import Path
import hashlib
import json
import platform

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

ROOT = Path(__file__).resolve().parents[1]
RESULTS, FIGURES = ROOT / "results", ROOT / "figures"
FIGURES.mkdir(exist_ok=True)
BLUE, ORANGE = "#0072B2", "#D55E00"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.5,
    "axes.labelsize": 9.5, "axes.titlesize": 9.5,
    "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
    "legend.fontsize": 9.5, "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.7, "lines.linewidth": 1.6,
    "savefig.facecolor": "white", "figure.facecolor": "white",
})


def load(name):
    return json.loads((RESULTS / name).read_text(encoding="utf-8"))


def save(fig, name):
    # Retain the exact physical size so publication font sizes remain known.
    fig.savefig(FIGURES / f"{name}.pdf")
    fig.savefig(FIGURES / f"{name}.png", dpi=220)
    plt.close(fig)


def mean_se(values):
    values = np.asarray(values, dtype=float)
    return float(values.mean()), float(values.std(ddof=1) / np.sqrt(len(values)))


def style(ax):
    ax.grid(axis="y", color="#D9D9D9", lw=0.6, alpha=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, width=0.6)


path = load("path_ablation.json")
summary = load("path_summary.json")
assert len(path["records"]) == 360 and path["repeats"] == 10
path_provenance = []
fig, axes = plt.subplots(1, 2, figsize=(5.3, 2.35))
fig.subplots_adjust(left=0.125, right=0.99, bottom=0.22, top=0.76, wspace=0.40)
for config, n, color, marker in [
    ("reference", 256, BLUE, "o"), ("larger_master", 512, ORANGE, "s")
]:
    records = sorted([r for r in path["records"]
                      if r["config"] == config and r["method"] == "Full"],
                     key=lambda r: r["rep"])
    assert len(records) == 10 and {r["rep"] for r in records} == set(range(10))
    errors, bounds, coefficients = [], [], []
    for record in records:
        selected = record["selected"]
        assert selected is not None and selected["status"] == "ok"
        assert len(selected["rounds"]) == 8 and len(record["candidates"]) == 4
        valid = [(i, x["val"]) for i, x in enumerate(record["candidates"])
                 if x["val"] is not None]
        assert record["selected_index"] == min(valid, key=lambda x: x[1])[0]
        ee = [selected["initial"]["l2"]]
        bb, aa = [ee[0]], []
        for stage in selected["rounds"]:
            audit = stage["audit"]
            assert audit["curvature"] > 0
            assert np.isclose(stage["l2"], audit["actual_error"])
            assert np.isclose(audit["one_step_bound"],
                              audit["eta"] * ee[-1] + audit["offset"])
            ee.append(stage["l2"])
            aa.append(audit["eta"])
            bb.append(audit["eta"] * bb[-1] + audit["offset"])
            assert ee[-1] <= audit["one_step_bound"] + 1e-8
            assert ee[-1] <= bb[-1] + 1e-8
        errors.append(ee)
        bounds.append(bb)
        coefficients.append(aa)
    errors, bounds, coefficients = map(np.asarray, (errors, bounds, coefficients))
    reference = next(a for a in summary["audits"] if a["config"] == config)
    assert np.allclose(bounds, reference["bounds"])
    assert np.allclose(coefficients, reference["etas"])
    for values, linestyle in [(errors, "-"), (bounds, "--")]:
        lo, med, hi = np.quantile(values, [0.25, 0.5, 0.75], axis=0)
        axes[0].fill_between(range(9), lo, hi, color=color, alpha=0.12, lw=0)
        axes[0].plot(range(9), med, color=color, linestyle=linestyle,
                     marker=marker, markersize=3, markevery=2)
    lo, med, hi = np.quantile(coefficients, [0.25, 0.5, 0.75], axis=0)
    axes[1].fill_between(range(1, 9), lo, hi, color=color, alpha=0.16, lw=0)
    axes[1].plot(range(1, 9), med, color=color, marker=marker,
                 markersize=3, markevery=2)
    # Dots retain every repetition, including coefficients above one.
    jitter = np.linspace(-0.10, 0.10, 10)
    for repetition in range(10):
        axes[1].scatter(np.arange(1, 9) + jitter[repetition],
                        coefficients[repetition], s=4, color=color,
                        alpha=0.28, linewidths=0, zorder=2)
    path_provenance.append({
        "config": config, "local_sample_size": n, "selected_fits": 10,
        "candidate_fits": 40,
        "failed_candidates": sum(c["status"] != "ok" for r in records
                                  for c in r["candidates"]),
        "all_rounds_contracting": int(np.sum(np.all(coefficients < 1, axis=1))),
        "all_bounds_verified": True,
        "final_error_median": float(np.median(errors[:, -1])),
        "final_bound_median": float(np.median(bounds[:, -1])),
        "maximum_coefficient": float(coefficients.max()),
        "error_quantiles": np.quantile(errors, [0.25, 0.5, 0.75], axis=0).tolist(),
        "bound_quantiles": np.quantile(bounds, [0.25, 0.5, 0.75], axis=0).tolist(),
        "coefficient_quantiles": np.quantile(coefficients, [0.25, 0.5, 0.75], axis=0).tolist(),
    })
axes[0].set_yscale("log")
axes[0].set_ylabel(r"Error / bound ($\ell_2$)", labelpad=2)
axes[0].set_title("(a) Endpoint trajectories", loc="left", pad=5)
axes[0].set_xticks([0, 2, 4, 6, 8])
axes[1].axhline(1, color="#555555", linestyle=":", lw=1.1, zorder=1)
axes[1].set_ylabel(r"Coefficient $\alpha_t$", labelpad=2)
axes[1].set_title("(b) Error propagation", loc="left", pad=5)
axes[1].set_xticks([1, 2, 4, 6, 8])
axes[1].set_yticks([0.5, 1, 1.5, 2])
axes[1].set_ylim(0.15, 2.16)
for ax in axes:
    ax.set_xlabel("Communication round", labelpad=3)
    style(ax)
fig.legend(handles=[
    Line2D([0], [0], color=BLUE, marker="o", ms=3, label=r"$n_j=256$"),
    Line2D([0], [0], color=ORANGE, marker="s", ms=3, label=r"$n_j=512$"),
    Line2D([0], [0], color="#333333", label="Error"),
    Line2D([0], [0], color="#333333", ls="--", label="Bound"),
], loc="upper center", bbox_to_anchor=(0.53, 1.0), ncol=4,
    handlelength=1.6, handletextpad=0.45, columnspacing=1.0, frameon=False)
save(fig, "main_path")

unequal = load("reviewer_unequal.json")
unequal_summary = load("reviewer_summary.json")["unequal"]
assert len(unequal["records"]) == 270
imbalance_provenance = []
fig, axes = plt.subplots(1, 2, figsize=(5.3, 2.25), sharey=True)
fig.subplots_adjust(left=0.105, right=0.99, bottom=0.22, top=0.76, wspace=0.12)
for ax, master, title in zip(axes, ["small", "large"],
                             ["(a) Smallest master sample", "(b) Largest master sample"]):
    for attacked, color, marker, linestyle in [
        ("small", BLUE, "o", "-"), ("large", ORANGE, "s", "--")
    ]:
        means, ses = [], []
        for ratio in [1, 4, 16]:
            key = (ratio, "equal", "equal", "Trim-SCAD") if ratio == 1 else (
                ratio, master, attacked, "Trim-SCAD")
            records = [r for r in unequal["records"]
                       if (r["ratio"], r["master"], r["attacked"], r["method"]) == key]
            assert len(records) == 10 and {r["rep"] for r in records} == set(range(10))
            assert all(sum(r["sizes"]) == 2400 for r in records)
            assert all(r["selected"] and r["selected"]["status"] == "ok" for r in records)
            for r in records:
                valid = [c for c in r["candidates"] if c["status"] == "ok"]
                assert r["selected"]["validation"] == min(c["validation"] for c in valid)
            values = [r["selected"]["l2"] for r in records]
            mean, se = mean_se(values)
            ref = next(x for x in unequal_summary if tuple(x["key"]) == key)
            assert np.allclose([mean, se], ref["l2"])
            means.append(mean)
            ses.append(se)
            entry = {
                "ratio": ratio, "master": key[1], "attacked": key[2],
                "selected_fits": 10, "candidate_fits": 40,
                "failed_candidates": sum(c["status"] != "ok" for r in records
                                          for c in r["candidates"]),
                "mean_l2": mean, "se_l2": se,
                "master_sample_size": records[0]["sizes"][0],
                "honest_sample_total": records[0]["honest_total"],
                "effective_sample_size": records[0]["honest_effective"],
                "size_range": [min(records[0]["sizes"]), max(records[0]["sizes"])],
            }
            if entry not in imbalance_provenance:
                imbalance_provenance.append(entry)
        ax.errorbar(range(3), means, yerr=ses, color=color, marker=marker,
                    linestyle=linestyle, markersize=4, capsize=2,
                    markerfacecolor="white", markeredgewidth=1.1,
                    elinewidth=1,
                    label=("Smallest" if attacked == "small" else "Largest")
                    + " workers attacked")
    ax.set_xticks(range(3), ["1", "4", "16"])
    ax.set_xlim(-0.12, 2.12)
    ax.set_xlabel("Allocation ratio", labelpad=3)
    ax.set_title(title, loc="left", pad=5)
    style(ax)
axes[0].set_yscale("log")
axes[0].set_ylim(0.055, 1.95)
axes[0].yaxis.set_major_locator(FixedLocator([0.1, 0.2, 0.5, 1]))
axes[0].yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}"))
axes[0].yaxis.set_minor_locator(NullLocator())
axes[0].set_ylabel(r"Coefficient error ($\ell_2$)", labelpad=2)
fig.legend(*axes[0].get_legend_handles_labels(), loc="upper center",
           bbox_to_anchor=(0.53, 1), ncol=2, frameon=False,
           handlelength=2.0, handletextpad=0.5, columnspacing=1.5)
save(fig, "main_imbalance")

assert len(imbalance_provenance) == 9
source_names = ["path_ablation.json", "path_summary.json", "reviewer_unequal.json",
                "reviewer_summary.json"]
provenance = {
    "plotting_runtime": {"python": platform.python_version(),
                         "numpy": np.__version__,
                         "matplotlib": matplotlib.__version__,
                         "backend": matplotlib.get_backend()},
    "source_sha256": {name: hashlib.sha256((RESULTS / name).read_bytes()).hexdigest()
                      for name in source_names},
    "generation": "Saved results only; no simulation, fitting, or selection rerun.",
    "path": {
        "selection": "Both prespecified sample-size settings, all ten Full (Trim-SCAD) selected repetitions each.",
        "display": "Lines are medians; bands are the 25th--75th percentiles. Panel (b) dots show every repetition.",
        "interpretation": "Support-local endpoint quantities use truth and honest-node identities after selection; not an observable certificate.",
        "records": path_provenance,
    },
    "imbalance": {
        "selection": "Every Trim-SCAD allocation cell, all ten selected repetitions each; other methods remain in supplementary results.",
        "display": "Mean plus/minus one Monte Carlo standard error; logarithmic error axis. Ratio-one reference is reused in both panels and curves.",
        "budget": "2400 assigned observations, with honest sample total varying by attack placement.",
        "records": imbalance_provenance,
        "selected_fit_failures": 0,
        "failed_candidates": sum(x["failed_candidates"] for x in imbalance_provenance),
    },
}
(FIGURES / "main_empirical_provenance.json").write_text(
    json.dumps(provenance, indent=2), encoding="utf-8")
print(json.dumps({
    "path": [{k: v for k, v in r.items() if "quantiles" not in k} for r in path_provenance],
    "imbalance_cells": len(imbalance_provenance),
    "imbalance_selected_fits": 90,
    "imbalance_failed_candidates": provenance["imbalance"]["failed_candidates"],
}, indent=2))
