"""Figures from the complete theory-validation experiment records."""
from pathlib import Path
import argparse,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];FIG=ROOT/'figures'
def style():
 plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':9.5,'axes.labelsize':9.5,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':8,'mathtext.fontset':'dejavuserif','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
def finish(fig,name):
 fig.savefig(FIG/(name+'.pdf'));fig.savefig(FIG/(name+'.png'),dpi=220);plt.close(fig)
def variance():
 data=json.loads((ROOT/'results/theory_variance.json').read_text());q=np.linspace(.2,1,301)
 fig,axs=plt.subplots(1,2,figsize=(5.3,2.35),sharey=True)
 colors=['#2166ac','#d97706','#666666'];styles=['-','--',':'];markers=['o','s','^']
 for ax,corr,title in zip(axs,[0.,.5],['(a) Independent predictors','(b) Correlation 0.5']):
  energy=1+corr**2+corr**4;noise=1/q;missing=(1-q)*energy/q**2
  for key,curve,label,color,ls,mark in zip(['total','missing','noise'],[noise+missing,missing,noise],['Total','Missing covariates','Response noise'],colors,styles,markers):
   ax.plot(q,curve,color=color,ls=ls,lw=1.4,label=label)
   group=[r for r in data['summary'] if r['correlation']==corr]
   ax.errorbar([r['q'] for r in group],[r['statistics'][key]['mean'] for r in group],yerr=[2*r['statistics'][key]['se'] for r in group],fmt=mark,ms=3,mfc='white',mew=.8,color=color,lw=.7,capsize=1.5)
  ax.set_title(title,fontsize=9,loc='left');ax.set_xlabel('Observation probability $q$');ax.set_xlim(.18,1.02);ax.set_xticks([.2,.4,.6,.8,1.]);ax.grid(axis='y',alpha=.2);ax.set_ylim(0,33)
 axs[0].set_ylabel('Score variance');axs[0].legend(frameon=False,loc='upper right',handlelength=1.6,fontsize=7.5)
 fig.subplots_adjust(left=.105,right=.98,bottom=.23,top=.88,wspace=.15)
 finish(fig,'score_variance_empirical')
 prov={'source':'results/theory_variance.json','sha256':hashlib.sha256((ROOT/'results/theory_variance.json').read_bytes()).hexdigest(),'all_replications_used':True,'replications_per_setting':30,'observations_per_replication':50000,'lines':'exact formula','markers':'mean over 30 sample-variance estimates','bars':'2 Monte Carlo standard errors','no_fitting_or_selection':True}
 (FIG/'score_variance_empirical_provenance.json').write_text(json.dumps(prov,indent=2),encoding='utf-8')

def theory_paths():
 mcar=json.loads((ROOT/'results/theory_mcar.json').read_text())
 quad=json.loads((ROOT/'results/theory_indefinite.json').read_text())
 rr=[r for r in mcar['records'] if r['config']['name']=='reference']
 assert len(rr)==20 and all('fit' in r for r in rr)
 errors=np.array([[r['fit']['initial_error']]+[t['error'] for t in r['fit']['rounds']] for r in rr])
 radii=np.array([[r['fit']['initial_error']]+[t['radius'] for t in r['fit']['rounds']] for r in rr])
 fig,axs=plt.subplots(1,2,figsize=(5.3,2.45))
 for values,color,ls,label in [(errors,'#2166ac','-','Estimation error'),(radii,'#d97706','--',r'Bound $R_t$')]:
  axs[0].plot(range(13),np.median(values,axis=0),ls,color=color,lw=1.5,label=label)
  lo,hi=np.quantile(values,[.25,.75],axis=0);axs[0].fill_between(range(13),lo,hi,color=color,alpha=.15)
 axs[0].set_yscale('log');axs[0].set_xlabel('Communication round');axs[0].set_ylabel('Error / bound');axs[0].set_xticks([0,3,6,9,12]);axs[0].set_title('(a) MCAR error recursion',fontsize=9,loc='left');axs[0].legend(frameon=False,loc='upper right',fontsize=7.5)
 qq=[r for r in quad['records'] if r['configuration']=='adaptive_b1']
 assert len(qq)==20
 distance=np.array([r['trace'][0]['stages'][-1]['distances_to_fixed_point'] for r in qq]);assert distance.shape==(20,3)
 normalized=distance/distance[:,[0]];a0=1-qq[0]['constants']['kappa']/qq[0]['constants']['M']
 for x in normalized: axs[1].plot(range(3),x,color='#888888',alpha=.35,lw=.6)
 axs[1].plot(range(3),np.median(normalized,axis=0),'o-',color='#2166ac',ms=3,lw=1.5,label='Observed (median)')
 axs[1].plot(range(3),a0**np.arange(3),'s--',color='#d97706',ms=3,lw=1.3,label=r'$(1-\kappa/M)^k$')
 axs[1].set_yscale('log');axs[1].set_xlabel('Local update $k$');axs[1].set_ylabel('Relative fixed-point distance');axs[1].set_xticks([0,1,2]);axs[1].set_title('(b) Indefinite-loss contraction',fontsize=9,loc='left');axs[1].legend(frameon=False,fontsize=7.3,loc='upper right')
 for ax in axs:ax.grid(axis='y',alpha=.2)
 fig.subplots_adjust(left=.11,right=.985,bottom=.22,top=.88,wspace=.43)
 finish(fig,'theory_validation')
 prov={'sources':{f:hashlib.sha256((ROOT/'results'/f).read_bytes()).hexdigest() for f in ['theory_mcar.json','theory_indefinite.json']},'panel_a':{'configuration':'reference','n':320000,'p':24,'q':.7,'b':1,'all_replications':20,'curves':'medians','bands':'interquartile ranges','bounds':'sample-specific truth-assisted valid inputs'},'panel_b':{'configuration':'adaptive_b1','p':4000,'all_replications':20,'stage':'first communication round, final penalty level','observed_common_updates':[0,1,2],'grey_lines':'all replications','distance':'exact fixed point, normalized by initial distance at this level','no_padding_or_extra_updates':True},'no_empirical_data_filtered':True}
 (FIG/'theory_validation_provenance.json').write_text(json.dumps(prov,indent=2),encoding='utf-8')
if __name__=='__main__':
 style();variance();theory_paths();print('Created variance and theory-validation figures.')
