"""Independent finite-dimensional checks of the added rank and rate calculations."""
import json
from pathlib import Path
import numpy as np
from robust_sparse import Node,penalty_weights
rng=np.random.default_rng(1010);records=[]
for n in [8,12,24]:
    for q in [.4,.7,.9]:
        z=rng.normal(size=(n,n+8))*(rng.random((n,n+8))<q)
        # Positive empirical diagonals are an explicit hypothesis.
        if np.any(np.sum(z*z,axis=0)==0):continue
        node=Node(z,np.zeros(n),q,True);U=np.arange(n+1)
        v=np.linalg.svd(z[:,U],full_matrices=True)[2][-1]
        observed=float(v@node.gram[np.ix_(U,U)]@v)
        expected=float(-(1-q)/q**2*np.sum(np.mean(z[:,U]**2,axis=0)*v*v))
        assert observed<0 and np.allclose(observed,expected,rtol=1e-10,atol=1e-12)
        records.append(dict(n=n,q=q,subset=n+1,negative_form=observed,null_residual=float(np.linalg.norm(z[:,U]@v))))
assert len(records)>=6
assert not np.isclose(penalty_weights(np.array([4.]),2.,'scad')[0]/2,penalty_weights(np.array([4.]),1.,'scad')[0])
for _ in range(100):
    sizes=rng.integers(20,2000,8);h=8;neff=h*h/np.sum(1/sizes);nmin=sizes.min()
    weights=np.concatenate([np.full(int(n),1/(h*n)) for n in sizes])
    assert np.isclose(weights@weights,1/neff) and np.isclose(weights.max(),1/(h*nmin))
    nu,B,t,lH,lm,omega=rng.uniform(.1,10,6)
    bias=(t+1)*np.exp(-t)
    aH=nu*np.sqrt(lH/neff)+B*t*lH/(h*nmin)+2*B*bias
    tau=2*(nu*np.sqrt(lm/nmin)+B*t*lm/nmin+2*B*bias)
    V=nu*(np.sqrt(lH/neff)+omega*np.sqrt(lm/nmin))
    Q=B*(t*lH/(h*nmin)+omega*t*lm/nmin+(1+omega)*bias)
    assert aH+omega*tau<=4*(V+Q)+1e-12
out=dict(rank_checks=records,unequal_weight_checks=100,rate_collection_checks=100,frozen_weight_distinction=True)
(Path(__file__).resolve().parents[1]/'results/review_theory_checks.json').write_text(json.dumps(out,indent=2))
print('Rank obstruction, unequal weights, collected rate and frozen-weight checks passed.')
