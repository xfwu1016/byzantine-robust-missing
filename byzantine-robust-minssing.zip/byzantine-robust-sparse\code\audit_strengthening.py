"""Check saved selection, certificate, and measured-transport records."""
import json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def run():
 cert=json.loads((ROOT/'results/certified_selection.json').read_text())['records']
 assert len(cert)==30
 for r in cert:
  c=r['candidates'][r['selected_index']]
  assert c['validation_mse']==min(x['validation_mse'] for x in r['candidates'])
  assert r['l2']<=r['radius']+1e-9 and r['rejected_inflations']==[10.]
  for opt in r['candidates']:
   assert opt['rho']<1
   assert all(t['max_support']<=opt['K'] for t in opt['trace'])
 bridge=json.loads((ROOT/'results/bridge_audit.json').read_text())['records']
 assert len(bridge)==30
 for r in bridge:
  assert r['bounds_use_truth_and_honest_labels'] is True
  for c in r['certified_candidates']:
   assert r['rho']*c['inflation']<1
   assert c['l2']<=c['radius']+1e-9
   assert c['max_support']<=r['K']
  if r['selected']:assert r['selected']['val']==min(z['val'] for z in r['certified_candidates'])
 e2e=json.loads((ROOT/'results/end_to_end.json').read_text())['records'];assert len(e2e)==45
 for r in e2e:
  assert r['status']=='ok' and len(r['trace'])==8
  expected=16*(r['m']-1)*r['p']*8
  assert r['payload_bytes']==expected
  assert r['seconds']>=r['trace'][-1]['seconds']>=r['initial_seconds']>0
  for k,t in enumerate(r['trace']):
   assert t['payload_bytes']==16*(r['m']-1)*r['p']*(k+1)
   assert t['inner_iterations']>=0 and t['status']=='ok'
 out=dict(known_valid_instances=len(cert),known_valid_candidates=sum(len(r['candidates']) for r in cert),mcar_audit_instances=len(bridge),mcar_admitted=sum(r['selected'] is not None for r in bridge),complete_solver_runs=len(e2e),transport_payload_checks='passed',selection_checks='passed',conditional_bounds_checks='passed',limitations='Does not prove theorems, calibrate envelopes, or establish multi-machine performance.')
 (ROOT/'results/strengthening_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':run()
