"""Independent checks and summaries of the frozen competitiveness experiment.

This audit does not call the experiment runner or fit a model.  It recomputes
selection, coefficients/path metrics, penalty schedules and accounting from the
saved records.  All uncertainty below is across independent simulation seeds.
"""
import argparse
import ast
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b, label, tol=2e-9):
    assert a is not None and b is not None, (label, a, b)
    assert math.isfinite(a) and math.isfinite(b), (label, a, b)
    assert math.isclose(a, b, rel_tol=tol, abs_tol=tol), (label, a, b)


def stats(values):
    return dict(n=len(values), mean=statistics.mean(values) if values else None,
                se=statistics.stdev(values)/math.sqrt(len(values)) if len(values)>1 else None,
                median=statistics.median(values) if values else None)


def metrics(coef, truth, threshold):
    assert len(coef) == len(truth)
    assert all(math.isfinite(x) for x in coef)
    active = [abs(x)>threshold for x in coef]
    support = [x != 0 for x in truth]
    tp = sum(a and s for a, s in zip(active, support))
    fp = sum(a and not s for a, s in zip(active, support))
    fn = sum(s and not a for a, s in zip(active, support))
    return dict(l2=math.sqrt(math.fsum((x-y)**2 for x, y in zip(coef, truth))),
                exact=(fp == 0 and fn == 0), fp=fp, fn=fn, selected=sum(active),
                f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 1.)


def ar_quadratic(delta, rho):
    """Compute delta' Sigma delta in O(p), Sigma_ij = rho**abs(i-j)."""
    off = 0.
    lag = 0.
    for i, value in enumerate(delta):
        if i:
            lag = rho*(lag+delta[i-1])
        off += value*lag
    return math.fsum(x*x for x in delta)+2*off


def verify_metric(actual, expected, context):
    for key in ('exact', 'fp', 'fn', 'selected'):
        assert actual[key] == expected[key], (context, key, actual[key], expected[key])
    for key in ('l2', 'f1'):
        close(actual[key], expected[key], (context, key))


def run(allow_incomplete=False, study='full'):
    directory = ROOT/'results'
    plan_path = directory/f'competitive_{study}_plan.json'
    data_path = directory/f'competitive_{study}.jsonl'
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    source = ROOT/'code'/'competitive_benchmark.py'
    runner = source if study == 'full' else ROOT/'code'/'competitive_sample_size.py'
    assert digest(runner) == plan['script_sha256'], 'The frozen runner was changed.'
    if study == 'sample_size':
        assert digest(source) == plan['benchmark_source_sha256'], 'The imported primary runner was changed.'
        primary_path = directory/'competitive_full_plan.json'
        assert digest(primary_path) == plan['primary_plan_sha256']
        primary_plan = json.loads(primary_path.read_text(encoding='utf-8'))
        assert not set(plan['seeds']) & set(primary_plan['seeds'])
        assert all(c['n'] == math.ceil(512*(.7/c['q'])**2) for c in plan['configurations'])
        assert {(c['q'], c['attack']) for c in plan['configurations']} == {(q, attack) for q in (.7, .5, .3) for attack in ('gaussian', 'stealth')}
        assert all(c['f'] == c['b'] == 2 and c['p'] == 256 and c['m'] == 12 for c in plan['configurations'])
    assert digest(ROOT/'code'/'robust_sparse.py') == plan['core_sha256']
    preceding = ROOT.parent/'Statistica_Sinica_revision27'/'code'/'robust_sparse.py'
    core_preserved = digest(preceding) == plan['core_sha256'] if preceding.exists() else None
    if preceding.exists():
        assert core_preserved, 'The pre-existing core solver was changed.'

    syntax = ast.parse(source.read_text(encoding='utf-8'))
    literals = {node.targets[0].id: ast.literal_eval(node.value)
                for node in syntax.body if isinstance(node, ast.Assign)
                and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in ('GRID', 'METHODS')}
    assert literals['GRID'] == plan['grid']
    assert [dict(name=n, aggregation=a, penalty=p, corrected=c)
            for n, a, p, c in literals['METHODS']] == plan['methods']
    # Explicitly verify the selector expression, in addition to every outcome.
    fitting = next(n for n in syntax.body if isinstance(n, ast.FunctionDef) and n.name == 'fit_method')
    selector = next(n.value for n in fitting.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'selected' for t in n.targets))
    expected_selector = ast.parse("min(eligible, key=lambda i: candidates[i]['validation_mse']) if eligible else None", mode='eval').body
    assert ast.dump(selector, include_attributes=False) == ast.dump(expected_selector, include_attributes=False)

    methods = {m['name']: m for m in plan['methods']}
    configs = {c['label']: c for c in plan['configurations']}
    assert len(configs) == len(plan['configurations'])
    assert len(plan['seeds']) == plan['repeats'] == len(set(plan['seeds']))
    pilot_plan = json.loads((directory/'competitive_pilot_plan.json').read_text(encoding='utf-8'))
    assert not set(pilot_plan['seeds']) & set(plan['seeds'])

    expected = {(label, seed, method) for label in configs for seed in plan['seeds'] for method in methods}
    raw_records = data_path.read_bytes()
    if allow_incomplete and raw_records and not raw_records.endswith(b'\n'):
        raw_records = raw_records[:raw_records.rfind(b'\n')+1]
    records = []
    for line_number, line in enumerate(raw_records.decode('utf-8').splitlines(), 1):
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            raise AssertionError(f'Incomplete or corrupt record at line {line_number}')
    observed = set()
    data_hashes = defaultdict(set)
    shared_attack_hashes = defaultdict(set)
    latent_response_scales = defaultdict(list)
    execution_orders = defaultdict(set)
    groups = defaultdict(list)
    candidates_count = failed_candidates = failed_repetitions = paths_checked = 0
    for row in records:
        cf = row['configuration']; label = cf['label']; seed = row['seed']; method = row['method']
        key = (label, seed, method)
        assert key in expected and key not in observed, ('Unexpected or duplicate record', key)
        observed.add(key)
        assert row['mode'] == study and cf == configs[label]
        assert row['rep'] == plan['seeds'].index(seed)
        groups[label, method].append(row)
        data_hashes[label, seed].add(row['dataset']['data_sha256'])
        shared_key = (seed, cf['p'], cf['n'], cf['q'], cf['rho'], cf['layout'],
                      cf['noise_sd'], cf['coefficient_magnitude'], cf['m'])
        shared_attack_hashes[shared_key].add(row['dataset']['data_sha256'])
        latent_key = (seed, cf['p'], cf['n'], cf['rho'], cf['layout'],
                      cf['noise_sd'], cf['coefficient_magnitude'], cf['m'])
        latent_response_scales[latent_key].append(row['scale']*(cf['q'] if methods[method]['corrected'] else 1.))
        assert row['execution_order'] not in execution_orders[label, seed]
        execution_orders[label, seed].add(row['execution_order'])
        assert 0 <= row['execution_order'] < len(methods)
        truth = row['dataset']['truth']
        assert len(truth) == cf['p']
        assert [i for i, x in enumerate(truth) if x != 0] == sorted(row['dataset']['active'])
        assert len(row['candidates']) == len(plan['grid'])
        assert [c['factor'] for c in row['candidates']] == plan['grid']
        eligible = []
        for index, cand in enumerate(row['candidates']):
            context = (*key, cand['factor'])
            candidates_count += 1
            good = cand['status'] == 'ok'
            if good:
                eligible.append(index)
                assert cand['validation_mse'] is not None and math.isfinite(cand['validation_mse'])
                assert len(cand['trace']) == plan['rounds']
                assert cand['initial']['status'] == 'ok'
                assert all(a['status'] == 'ok' for a in cand['trace'])
            else:
                failed_candidates += 1
                assert cand['validation_mse'] is None
            assert 0 <= len(cand['trace']) <= plan['rounds']
            assert cand['communication_rounds'] == len(cand['trace'])
            assert cand['vector_payload_bytes'] == 16*(cf['m']-1)*cf['p']*len(cand['trace'])
            assert cand['total_updates'] == cand['initial'].get('iterations', 0)+sum(a['iterations'] for a in cand['trace'])
            assert cand['total_stages'] == cand['initial'].get('stages', 0)+sum(a.get('stages', 0) for a in cand['trace'])
            assert 0 <= cand['total_updates'] <= plan['stage_iteration_cap']*cand['total_stages']
            assert 0 <= cand['fitting_seconds'] <= cand['seconds']
            assert len(cand['path']) == len(cand['trace'])+1
            assert [a['round'] for a in cand['path']] == list(range(len(cand['path'])))
            local = cand['factor']*row['scale']*math.sqrt(math.log(cf['p'])/cf['n'])
            floor = cand['factor']*row['scale']*(math.sqrt(math.log(cf['p'])/(cf['m']*cf['n']))
                     +(cf['b']/cf['m'])*math.sqrt(math.log(cf['p'])/cf['n']))
            for t, endpoint in enumerate(cand['trace'], 1):
                close(endpoint['lambda_value'], max(floor, local*.65**t), (context, 'lambda', t))
            for name in ('l2', 'f1', 'exact', 'fp', 'fn', 'selected'):
                assert cand['final_diagnostic'][name] == cand['path'][-1][name], (context, name)
        selected = min(eligible, key=lambda i: row['candidates'][i]['validation_mse']) if eligible else None
        assert row['selected_index'] == selected
        assert row['candidate_successes'] == len(eligible)
        assert row['status'] == ('ok' if eligible else 'all_candidates_failed')
        accounting = dict(total_search_seconds='seconds', total_search_updates='total_updates',
                          total_search_stages='total_stages', total_search_rounds='communication_rounds',
                          total_search_vector_payload_bytes='vector_payload_bytes')
        for total, part in accounting.items():
            close(row[total], sum(c[part] for c in row['candidates']), (*key, total))
        if selected is None:
            failed_repetitions += 1
            assert 'coefficient' not in row and 'l2' not in row
            continue
        cand = row['candidates'][selected]
        close(row['factor'], cand['factor'], (*key, 'factor'))
        close(row['final_lambda'], cand['trace'][-1]['lambda_value'], (*key, 'final lambda'))
        close(row['validation_mse'], cand['validation_mse'], (*key, 'validation'))
        for outer, inner in [('selected_candidate_seconds', 'seconds'),
                             ('selected_candidate_updates', 'total_updates'),
                             ('selected_candidate_stages', 'total_stages'),
                             ('selected_candidate_vector_payload_bytes', 'vector_payload_bytes')]:
            close(row[outer], cand[inner], (*key, outer))
        assert row['grid_edge'] == (selected in (0, len(plan['grid'])-1))
        verify_metric(row, metrics(row['coefficient'], truth, plan['support_threshold']), key)
        assert row['path'] == cand['path']
        assert len(row['outer_coefficients']) == len(row['path'])
        for t, (coef, endpoint) in enumerate(zip(row['outer_coefficients'], row['path'])):
            verify_metric(endpoint, metrics(coef, truth, plan['support_threshold']), (*key, t))
            paths_checked += 1
        assert row['coefficient'] == row['outer_coefficients'][-1]
        delta = [x-y for x, y in zip(row['coefficient'], truth)]
        close(row['population_prediction_excess'], ar_quadratic(delta, cf['rho']), (*key, 'prediction excess'))
        for target in plan['targets']:
            first = next((a['round'] for a in row['path'] if a['l2'] <= target), None)
            assert row['first_target_round'][str(target)] == first, (*key, target)
    assert all(len(v) == 1 for v in data_hashes.values())
    assert all(len(v) == 1 for v in shared_attack_hashes.values())
    for key, values in latent_response_scales.items():
        for value in values:
            close(value, values[0], ('shared master-response scale', key))
    missing = expected-observed
    if not allow_incomplete:
        assert not missing, f'{len(missing)} planned records are missing.'
        assert all(len(v) == len(methods) for v in execution_orders.values())
        assert all(len(rows) == plan['repeats'] for rows in groups.values())

    complete_data_identity_checks = 0
    for label, cf in configs.items():
        if cf['q'] != 1.:
            continue
        for left_method, right_method in [('Trim-SCAD', 'NoCorrection-SCAD'),
                                          ('Trim-Lasso', 'T-SLARD-ZF')]:
            left = {r['seed']: r for r in groups.get((label, left_method), [])}
            right = {r['seed']: r for r in groups.get((label, right_method), [])}
            for seed in left.keys() & right.keys():
                a, b = left[seed], right[seed]
                for field in ('status', 'scale', 'selected_index', 'candidate_successes'):
                    assert a[field] == b[field], ('complete-data identity', label, seed, field)
                for ca, cb in zip(a['candidates'], b['candidates']):
                    for field in ('factor', 'status', 'validation_mse', 'initial', 'trace', 'path'):
                        assert ca[field] == cb[field], ('complete-data candidate identity', label, seed, field)
                if a['status'] == 'ok':
                    assert a['coefficient'] == b['coefficient']
                    assert a['outer_coefficients'] == b['outer_coefficients']
                complete_data_identity_checks += 1

    full_equivalence = json.loads((directory/'competitive_core_equivalence_fullgrid.json').read_text(encoding='utf-8'))['checks']
    assert len(full_equivalence) == len(methods)*len(plan['grid'])
    assert {(r['method'], r['factor']) for r in full_equivalence} == {(m, f) for m in methods for f in plan['grid']}
    assert all(r['passed'] and r['max_endpoint_difference'] <= 1e-12 for r in full_equivalence)

    summary = []
    paired = []
    for label in configs:
        for method in methods:
            rows = groups.get((label, method), [])
            successful = [r for r in rows if r['status'] == 'ok']
            summary.append(dict(configuration=label, method=method, planned=plan['repeats'], observed=len(rows),
                successes=len(successful), failed_repetitions=len(rows)-len(successful),
                candidates=sum(len(r['candidates']) for r in rows),
                failed_candidates=sum(c['status'] != 'ok' for r in rows for c in r['candidates']),
                exact_count=sum(r['exact'] for r in successful),
                exact_rate=sum(r['exact'] for r in successful)/len(rows) if rows else None,
                l2=stats([r['l2'] for r in successful]),
                f1=stats([r['f1'] for r in successful]),
                population_prediction_excess=stats([r['population_prediction_excess'] for r in successful]),
                test_mse=stats([r['test_mse'] for r in successful]),
                selected_candidate_seconds=stats([r['selected_candidate_seconds'] for r in successful]),
                total_search_seconds=stats([r['total_search_seconds'] for r in rows]),
                total_search_updates=stats([r['total_search_updates'] for r in rows]),
                total_search_vector_payload_bytes=stats([r['total_search_vector_payload_bytes'] for r in rows]),
                selected_factors={str(f): sum(r['factor'] == f for r in successful) for f in plan['grid']},
                low_edge=sum(r['selected_index'] == 0 for r in successful),
                high_edge=sum(r['selected_index'] == len(plan['grid'])-1 for r in successful),
                target_counts={str(t): sum(r['first_target_round'][str(t)] is not None for r in successful) for t in plan['targets']}))
        for proposed in ('Trim-SCAD', 'Trim-MCP'):
            left = {r['seed']: r for r in groups.get((label, proposed), [])}
            for comparator in methods:
                if comparator == proposed:
                    continue
                right = {r['seed']: r for r in groups.get((label, comparator), [])}
                common = [s for s in sorted(left.keys() & right.keys())
                          if left[s]['status'] == right[s]['status'] == 'ok']
                diffs = [left[s]['l2']-right[s]['l2'] for s in common]
                paired.append(dict(configuration=label, proposed=proposed, comparator=comparator,
                                   jointly_successful=len(common), l2_difference=stats(diffs),
                                   negative_count=sum(d < 0 for d in diffs),
                                   prediction_difference=stats([left[s]['population_prediction_excess']-right[s]['population_prediction_excess'] for s in common])))
    provenance = dict(created_utc=datetime.now(timezone.utc).isoformat(), study=study,
                      plan_sha256=digest(plan_path), records_sha256=hashlib.sha256(raw_records).hexdigest(),
                      records_snapshot_bytes=len(raw_records),
                      audit_script_sha256=digest(Path(__file__)), complete=not missing)
    result = dict(**provenance, checks_passed=True, expected_records=len(expected), observed_records=len(records),
                  missing_records=len(missing), candidates_checked=candidates_count,
                  failed_candidates=failed_candidates, failed_repetitions=failed_repetitions,
                  selected_path_states_checked=paths_checked, fullgrid_equivalence_cases=len(full_equivalence),
                  fullgrid_equivalence_failure_cases=sum(r['status'] != 'ok' for r in full_equivalence),
                  complete_data_identity_checks=complete_data_identity_checks,
                  core_preserved_from_revision27=core_preserved,
                  notes=['No model fitting was performed by this independent audit.',
                         'The runtime excludes moment construction; numerical accounting includes initialization and validation.',
                         'Selection is checked against the lowest validation error among all successful candidates.',
                         'Summary L2 means are conditional on success; exact recovery uses all observed repetitions.',
                         'Paired differences use jointly successful repetitions; negative differences favor the named proposed method.'])
    prefix = 'competitive' if study == 'full' else 'competitive_sample_size'
    (directory/f'{prefix}_independent_audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    (directory/f'{prefix}_independent_summary.json').write_text(json.dumps(dict(**provenance, summary=summary, paired=paired), indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--allow-incomplete', action='store_true', help='Audit a snapshot; mark incomplete explicitly.')
    parser.add_argument('--study', choices=('full', 'sample_size'), default='full')
    args = parser.parse_args()
    run(args.allow_incomplete, args.study)
