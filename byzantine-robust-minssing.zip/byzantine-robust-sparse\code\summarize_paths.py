"""Summaries/figures from recorded component and support-local endpoint audits."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from path_audit import CONFIGS,MODES,GRID
R=Path(__file__).resolve().parents[1];F=R/'figures';D=R/'results'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
names={'Full':'Trim-SCAD','NoCorrection':'No correction','DirectTarget':'Direct target','StageRefresh':'Stage refresh','Lasso':'Trim-Lasso','VRMOM':'VRMOM-SCAD'}
labels=['Reference','Larger n','More missing','Correlated','Sign flip','Clustered']
colors=['#23669b','#bd552c','#6a4c93','#ad7b00','#2d8063','#4c5866'];markers=['o','s','^','D','v','P']
def save(fig,name):
 fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.png'),dpi=200);plt.close(fig)
def se(a):return float(np.std(a,ddof=1)/np.sqrt(len(a))) if len(a)>1 else 0.
d=json.loads((D/'path_ablation.json').read_text());records=d['records'];assert len(records)==360
curvature=json.loads((D/'sampled_curvature.json').read_text())['records']
assert len(curvature)==60 and all(x['uniform_rank_excluded'] and x['negative_quadratic']<0 for x in curvature)
rows=[];audits=[];pairs=[]
for cf in CONFIGS:
 for method in MODES:
  rr=[r for r in records if r['config']==cf['name'] and r['method']==method];assert len(rr)==10
  for r in rr:
   assert len(r['candidates'])==4
   good=[(i,z['val']) for i,z in enumerate(r['candidates']) if z['val'] is not None]
   assert r['selected_index']==min(good,key=lambda v:v[1])[0] if good else r['selected_index'] is None
  ss=[r['selected'] for r in rr if r.get('selected')];errs=[x['l2'] for x in ss]
  work=[sum(z['initial']['iterations']+sum(t['iterations'] for t in z['rounds']) for z in r['candidates']) for r in rr]
  row=dict(config=cf['name'],method=method,success=len(ss),l2=float(np.mean(errs)),se=se(errs),exact=sum(x['exact'] for x in ss),grid_updates=float(np.mean(work)),grid_updates_se=se(work),failed_candidates=sum(z['status']!='ok' for r in rr for z in r['candidates']),lower_grid=sum(x['factor']==GRID[0] for x in ss),upper_grid=sum(x['factor']==GRID[-1] for x in ss))
  rows.append(row)
  if method=='Full':
   pathbounds=[];etas=[];offsets=[];supports=[];local=0;positive=0;contract=0;allcover=0
   for x in ss:
    aa=[z['audit'] for z in x['rounds']];assert len(aa)==8
    ispos=all(a['curvature']>0 for a in aa);positive+=ispos
    contract+=ispos and all(a['eta']<1 for a in aa);local+=all(a['local']['passed'] for a in aa)
    bound=x['initial']['l2'];bb=[bound]
    for a in aa:
     assert a['actual_error']<=a['one_step_bound']+1e-8
     bound=a['eta']*bound+a['offset'];bb.append(bound);assert a['actual_error']<=bound+1e-8
    allcover+=1;pathbounds.append(bb);etas.append([a['eta'] for a in aa]);offsets.append([a['offset'] for a in aa]);supports.append([x['initial']['max_support']]+[z['max_support'] for z in x['rounds']])
   au=dict(config=cf['name'],N=len(ss),positive_curvature=positive,all_rounds_contract=contract,all_rounds_local=local,all_bounds_hold=allcover,max_eta_min=float(np.min(np.max(etas,axis=1))),max_eta_max=float(np.max(etas)),final_bound_median=float(np.median(np.array(pathbounds)[:,-1])),max_inner_support=int(np.max(supports)),bounds=pathbounds,etas=etas,offsets=offsets,supports=supports)
   audits.append(au)
 base={r['rep']:r['selected'] for r in records if r['config']==cf['name'] and r['method']=='Full' and r.get('selected')}
 for method in ['NoCorrection','DirectTarget','StageRefresh','VRMOM']:
  comp={r['rep']:r['selected'] for r in records if r['config']==cf['name'] and r['method']==method and r.get('selected')};ids=sorted(base.keys()&comp.keys())
  dif=[base[i]['l2']-comp[i]['l2'] for i in ids]
  pairs.append(dict(config=cf['name'],comparator=method,n=len(ids),mean=float(np.mean(dif)),se=se(dif),max_abs=float(np.max(np.abs(dif)))))
(D/'path_summary.json').write_text(json.dumps(dict(rows=rows,audits=audits,paired=pairs,selected=360,candidates=1440,all_one_step_bounds_verified=True),indent=2))

fig,axs=plt.subplots(1,3,figsize=(7.15,2.65))
for config,color,marker,label in [('reference',colors[0],'o','n = 256'),('larger_master',colors[4],'s','n = 512')]:
 au=next(a for a in audits if a['config']==config);ss=[r['selected'] for r in records if r['config']==config and r['method']=='Full']
 err=np.array([[x['initial']['l2']]+[t['l2'] for t in x['rounds']] for x in ss]);bound=np.array(au['bounds']);etas=np.array(au['etas']);sup=np.array(au['supports'])
 axs[0].plot(range(9),np.median(err,0),marker=marker,ms=3,color=color,label=label+' error')
 axs[0].plot(range(9),np.median(bound,0),'--',color=color,label=label+' bound')
 axs[1].plot(range(9),np.median(sup,0),marker=marker,ms=3,color=color,label=label)
 axs[1].fill_between(range(9),sup.min(0),sup.max(0),color=color,alpha=.1)
 axs[2].plot(range(1,9),np.median(etas,0),marker=marker,ms=3,color=color,label=label)
 axs[2].fill_between(range(1,9),etas.min(0),etas.max(0),color=color,alpha=.1)
axs[0].set_yscale('log');axs[0].set_ylabel('Coefficient error / bound');axs[0].legend(fontsize=6,loc='best')
axs[1].set_ylabel('Maximum inner support');axs[1].axhline(4,color='gray',ls=':',lw=.8);axs[1].legend(fontsize=7)
axs[2].set_ylabel('Endpoint coefficient');axs[2].axhline(1,color='gray',ls='--',lw=.8)
for ax,title in zip(axs,['(a) Error recursion','(b) Observed sparsity','(c) Contraction audit']):ax.set_title(title,fontsize=8,loc='left');ax.set_xlabel('Communication round');ax.grid(alpha=.2);ax.set_xticks([0,2,4,6,8] if ax!=axs[2] else [1,2,4,6,8])
fig.tight_layout();save(fig,'path_audit')

fig,axs=plt.subplots(1,2,figsize=(7.15,2.95))
for mi,(method,color,marker) in enumerate(zip(MODES,colors,markers)):
 rr=[next(z for z in rows if z['config']==c['name'] and z['method']==method) for c in CONFIGS];pos=np.arange(6)+(mi-2.5)*.11
 for ax,key,err in [(axs[0],'l2','se'),(axs[1],'grid_updates','grid_updates_se')]:
  ax.errorbar(pos,[z[key] for z in rr],yerr=[z[err] for z in rr],fmt=marker,ms=3,capsize=1,color=color,label=names[method])
axs[0].set_ylabel('Coefficient error');axs[1].set_ylabel('Proximal updates per grid');axs[1].set_yscale('log')
for ax in axs:ax.set_xticks(range(6),labels,rotation=25,ha='right');ax.grid(axis='y',alpha=.2)
fig.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=3,fontsize=7,frameon=False);fig.tight_layout(rect=[0,0,1,.85]);save(fig,'path_ablation')

# Benchmark figure uses annotated matrices for all methods.
from plot_validation import draw
draw()

prev=json.loads((D/'revision2_summary.json').read_text())
fig,axs=plt.subplots(1,2,figsize=(6.8,2.65))
for q,color,marker in zip([.5,.7,.9],colors[:3],markers[:3]):
 rr=[x for x in prev['calibration'] if x['q']==q];ns=[x['n'] for x in rr]
 axs[0].plot(ns,[x['admitted']/10 for x in rr],'-'+marker,color=color,label=f'q = {q}',ms=4)
 axs[1].plot(ns,[x['radius']/x['l2'] if x['radius'] is not None else np.nan for x in rr],'-'+marker,color=color,ms=4)
for ax in axs:ax.set_xscale('log');ax.set_xticks([1000,10000,50000],['1,000','10,000','50,000']);ax.set_xlabel(r'Masked calibration size $N_{\rm cal}$');ax.grid(alpha=.2)
axs[0].set_ylabel('Admitted fraction');axs[0].set_ylim(-.05,1.05);axs[0].legend(fontsize=7);axs[1].set_ylabel('Mean radius / mean observed error');axs[1].set_yscale('log');fig.tight_layout();save(fig,'observable_certificates')

fig,axs=plt.subplots(1,3,figsize=(7.15,2.5))
for mi,(method,color,marker) in enumerate(zip(['trim-scad','trim-lasso','vrmom-scad'],colors[:3],markers[:3])):
 rr=[x for x in prev['cost'] if x['p']==10000 and x['method']==method and x['target']==.1];qs=np.array([x['q'] for x in rr])+(mi-1)*.009
 for ax,key in zip(axs,['attained','median_seconds','median_mb']):ax.plot(qs,[((x[key]/10) if key=='attained' else x[key]) if x[key] is not None else np.nan for x in rr],'-'+marker,ms=4,color=color,label=method.replace('trim','Trim').replace('vrmom','VRMOM').replace('scad','SCAD').replace('lasso','Lasso'))
for ax,y in zip(axs,['Attained fraction','Median seconds','Median payload (MB)']):ax.set_xticks([.5,.7,.9]);ax.set_xlabel('Observation rate q');ax.set_ylabel(y);ax.grid(alpha=.2)
axs[0].set_ylim(-.05,1.05)
for ax in axs[1:]:ax.set_ylim(bottom=0)
fig.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=3,fontsize=7,frameon=False);fig.tight_layout(rect=[0,0,1,.86]);save(fig,'matched_cost')

def row(cfg,method):return next(x for x in rows if x['config']==cfg and x['method']==method)
au=next(x for x in audits if x['config']=='larger_master');cl=row('clustered_signals','Full');nc=row('clustered_signals','NoCorrection')
cp=next(x for x in pairs if x['config']=='clustered_signals' and x['comparator']=='NoCorrection')
assert max(x['max_abs'] for x in pairs if x['comparator']=='DirectTarget')<3e-5
main=r'''We use $p=768$, eight nodes, four coefficients of alternating sign and magnitude $1.2$, and Gaussian noise standard deviation $0.5$. Six settings vary local sample size, missingness, correlation, attack and the placement of active predictors. All have $p>n_j$. Six variants and a shared four-point validation grid give 360 selected fits and 1440 candidates. Truth and honest labels are used only for diagnostics after fitting and selection. The supplement specifies all variants and records failures, support recovery, work and grid-boundary selections.

Figure~\ref{fig:path} compares errors with the endpoint recursion and records the maximum support over every inner update. All 60 sampled master losses have a verified negative-curvature direction and fail a necessary condition for the uniform path theorem. At $n_j=512,q=0.7$, however, all ten selected Trim-SCAD runs have positive support-local curvature and $\alpha_t<1$ throughout eight rounds. The largest per-run coefficient ranges from %.3f to %.3f. All recursively propagated bounds cover the observed errors. The radius is conservative: its median at round eight is %.3f, versus mean coefficient error %.3f. At $n_j=256$, only %d/10 reference runs have contracting coefficients throughout; clustered active predictors give 0/10. The endpoint condition therefore applies to some sampled problems excluded by the uniform condition.

Figure~\ref{fig:ablation} shows design-dependent component effects. For clustered correlated signals, corrected Trim-SCAD has mean error %.3f versus %.3f without correction, but the paired difference is %.3f with standard error %.3f; the paired uncertainty exceeds the mean improvement. With separated signals, the uncorrected variant is more accurate in these finite samples, including the high-missingness setting. Direct target solves match continuation's selected errors to within $3\times10^{-5}$ across all 60 paired fits. Recomputing weights at every level has mixed effects. These results reveal a design-dependent bias--variance tradeoff for correction and closely matched errors for continuation and direct target solves.
'''%(au['max_eta_min'],au['max_eta_max'],au['final_bound_median'],row('larger_master','Full')['l2'],next(x for x in audits if x['config']=='reference')['all_rounds_contract'],cl['l2'],nc['l2'],cp['mean'],cp['se'])
(D/'path_main.tex').write_text(main,encoding='utf-8')
sup=r'''The six configurations use $m=8,p=768,s=4$, $b=m_{\rm B}=1$, ten independent seeds, and eight outer rounds. Reference: $n_j=256,q=0.7$, Gaussian AR(1) correlation $0.3$ and Gaussian replacement attacks. Larger local samples set every $n_j=512$. More missing sets $q=0.5$; correlated sets AR correlation $0.7$; sign flip replaces the Byzantine message by $-20$ times the honest mean gradient. These five configurations use active positions $0,192,384,576$. The clustered setting uses positions $0,1,2,3$ and correlation $0.7$, with the other reference settings. It was added after the initial component comparison to examine bias from correlation between active predictors; all initial settings and outcomes are retained. Coefficients alternate $\pm1.2$ and noise has standard deviation $0.5$.

All variants use the same observations, attack seeds and independent complete validation sample of size 400. The factors $0.3,0.6,1.2,2.4$ form the same grid. Full is the practical Trim-SCAD method. No correction fits the zero-filled observations with $q=1$ in its moments and natural tuning scale. Direct target keeps the same round base and frozen weight shape but skips intermediate levels. Stage refresh recomputes the SCAD weight shape from the current iterate at each level, keeping the same base scale and target sequence. Lasso replaces SCAD-derived weights by constant weights. VRMOM changes only the aggregator. Initial local Lasso is the same within corrected variants. The comparison uses shared validation budgets. The no-correction variant changes both the moments and their natural penalty scale.

Each stage allows at most 1200 updates and uses the original stopping tolerances. All variants receive the same number of candidates and rounds, but continuation can use more stages; the table therefore reports actual proximal updates over all four candidates, including failed ones. Ten selected fits succeed in every cell. Candidate failures, exact support counts and edge-of-grid selection counts are retained below. The traced full solver was checked against the unchanged core solver for all four pilot candidates at tolerance $10^{-10}$.

\small
\begin{longtable}{llrrrrrr}
\toprule Setting & Variant & L2 $\pm$ SE & Exact & Failed & Updates & Low & High\\\midrule\endhead
\bottomrule\endlastfoot
'''
for ci,cf in enumerate(CONFIGS):
 for method in MODES:
  x=row(cf['name'],method);sup+=f"{labels[ci]} & {names[method]} & ${x['l2']:.3f}\\pm{x['se']:.3f}$ & {x['exact']}/10 & {x['failed_candidates']}/40 & {x['grid_updates']:.0f} & {x['lower_grid']} & {x['upper_grid']} \\\\\n"
sup+=r'''\end{longtable}\normalsize
Low and High count selections at the grid endpoints. All per-candidate outcomes and per-iteration paths are retained in the accompanying records. Conditional accuracy is not summarized for failed candidates.

The endpoint audit evaluates the exact support-local coefficients using the true support and honest moments only after fitting. Each one-step inequality and its recursively propagated bound is checked numerically. The table reports positive curvature and contraction separately. The local optimization check is applied independently to the actual final weighted subproblem in every round.
\begin{center}\small\setlength{\tabcolsep}{6pt}\begin{tabular}{lrrrrr}\toprule
Setting & Positive & Contract & Local & Largest $\alpha_t$ & Final bound\\\midrule
'''
for i,a in enumerate(audits):sup+=f"{labels[i]} & {a['positive_curvature']}/10 & {a['all_rounds_contract']}/10 & {a['all_rounds_local']}/10 & {a['max_eta_max']:.2f} & {a['final_bound_median']:.2f} \\\\\n"
sup+=r'''\bottomrule\end{tabular}\end{center}
Positive, Contract and Local count runs satisfying the respective condition in every round. Largest $\alpha_t$ is the maximum over all rounds and seeds. Final bound is the median recursively propagated radius; a large value is reported even when uninformative. All 60 selected full-method runs satisfy all eight one-step and propagated inequalities. These are deterministic checks conditional on the simulated samples and true support.

For each of the 60 master samples, a null vector of an $n_1\times(n_1+1)$ observed-design block gives a negative corrected quadratic form. The residual norm is below $10^{-8}$. Positive diagonals give a lower bound on $M/\kappa$ through their maximum-to-minimum ratio. Substitution into the path support budget gives $4K_{\min}>n_1$ in every sample, excluding its uniform curvature assumption by the rank proposition. This contrasts with positive endpoint curvature in all 60 runs and contracting coefficients in all ten larger-sample runs.

The uncorrected comparison has a population explanation. For a common observation probability $q$ and zero-filled predictors $Z$, independence of masks gives
\begin{align*}
 \mathbb E[ZZ^\top]&=q^2\Sigma+q(1-q)\operatorname{diag}(\Sigma),\\
 \mathbb E[ZY]&=q\Sigma\thstar.
\end{align*}
Thus its population score at the truth is
\begin{equation*}
 -q(1-q)\{\Sigma-\operatorname{diag}(\Sigma)\}\thstar.
\end{equation*}
On the true support, this score is nearly zero for widely separated AR(1) active predictors, but not for adjacent ones. Correcting moments removes this bias while increasing variance. This identity describes the population bias underlying the design contrast. The clustered comparison remains uncertain at ten seeds, as its paired standard error exceeds the magnitude of its mean improvement.

Paired differences below are Full minus comparator on the same data and validation sample. Negative values favor Full; SE is the Monte Carlo standard error across ten independent seeds.
\begin{center}\small\begin{tabular}{llrr}\toprule
Setting & Comparator & Mean difference & SE\\\midrule
'''
for z in pairs:sup+=f"{labels[[c['name'] for c in CONFIGS].index(z['config'])]} & {names[z['comparator']]} & {z['mean']:.4f} & {z['se']:.4f} \\\\\n"
sup+=r'''\bottomrule\end{tabular}\end{center}
The Gaussian samples and masks are generated IID within and across honest nodes. Dense empirical Gram matrices speed up this statistical audit; all methods in it use the same representation. The separate matrix-free benchmark reports timing on a single host.
'''
(D/'path_supplement.tex').write_text(sup,encoding='utf-8')
print(json.dumps(dict(selected=len(records),candidates=sum(len(x['candidates']) for x in records),audits=[{k:v for k,v in a.items() if k not in ['bounds','etas','offsets','supports']} for a in audits]),indent=2))
