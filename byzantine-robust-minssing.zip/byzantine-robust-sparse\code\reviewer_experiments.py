"""Prespecified unequal-size and trusted-resource comparisons; retain all outcomes."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import argparse,json,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
import robust_sparse as rs
from certificates import local_certificate,calibration_certificate
from run_revision import ar,clean
ROOT=Path(__file__).resolve().parents[1]
GRID=[.3,.6,1.2,2.4]
ORIGINAL=rs.stage

def audited_fit(nodes,scale,factor,agg,pen,seed):
    last=[]
    def record(node,c,w,x,*args,**kwargs):
        out,info=ORIGINAL(node,c,w,x,*args,**kwargs)
        last[:]=[node,c.copy(),w.copy(),out.copy()]
        return out,info
    rs.stage=record
    try:x,info=rs.fit(nodes,scale,factor,agg,pen,2,2,'gaussian',seed)
    finally:rs.stage=ORIGINAL
    cert=local_certificate(*last) if info['status']=='ok' else dict(passed=False)
    return x,info,cert

def write(name,records,**metadata):
    (ROOT/'results'/name).write_text(json.dumps(clean(dict(records=records,**metadata)),indent=2),encoding='utf-8')

def assigned_sizes(ratio,master,attacked):
    raw=np.geomspace(1,ratio,8);sizes=np.floor(2400*raw/raw.sum()).astype(int)
    sizes[-1]+=2400-sizes.sum()
    if ratio==1:return sizes.tolist()
    pool=sizes.tolist();n1=pool.pop(0 if master=='small' else -1)
    bad=[pool.pop(0 if attacked=='small' else -1) for _ in range(2)]
    return [n1]+pool+bad

def unequal():
    configs=[(1,'equal','equal')]+[(r,a,b) for r in [4,16] for a in ['small','large'] for b in ['small','large']]
    records=[];p=240;q=.7;truth=np.zeros(p);truth[[0,60,120,180]]=[1.2,-1.2,1.2,-1.2]
    for ratio,master,attacked in configs:
        sizes=assigned_sizes(ratio,master,attacked)
        for rep in range(10):
            seed=20261010+rep;rng=np.random.default_rng(seed);nodes=[]
            for n in sizes:
                X=ar(rng,n,p,.3);y=X@truth+.5*rng.normal(size=n)
                nodes.append(rs.Node(X*(rng.random(X.shape)<q),y,q,True))
            xv=ar(rng,400,p,.3);yv=xv@truth+.5*rng.normal(size=400)
            for method,agg,pen in [('Trim-SCAD','trim','scad'),('Trim-Lasso','trim','lasso'),('Median-SCAD','median','scad')]:
                opts=[]
                for factor in GRID:
                    x,info,cert=audited_fit(nodes,np.std(nodes[0].y,ddof=1)/q,factor,agg,pen,seed)
                    val=float(np.mean((yv-xv@x)**2)) if info['status']=='ok' else np.inf
                    opts.append(dict(factor=factor,status=info['status'],validation=val,l2=float(np.linalg.norm(x-truth)),rounds=len(info['trace']),certificate=cert))
                good=[v for v in opts if v['status']=='ok'];chosen=min(good,key=lambda v:v['validation']) if good else None
                records.append(dict(ratio=ratio,master=master,attacked=attacked,rep=rep,seed=seed,sizes=sizes,honest_total=sum(sizes[:-2]),honest_effective=36/sum(1/n for n in sizes[:-2]),method=method,selected=chosen,candidates=opts))
        write('reviewer_unequal.json',records,p=p,q=q,total_assigned=2400,m=8,b=2,f=2,seeds=10,grid=GRID,notes='Total assigned sample count fixed; honest count changes with attack placement. Complete validation n=400; truth used only for evaluation. Gaussian message replacements, 8 rounds. Ratios refer to desired geometric allocation; integer rounding changes exact ratios.')
        print('unequal',ratio,master,attacked,'finished',flush=True)

class Moments:
    def __init__(self,G,gamma,n):
        self.G=G;self.gamma=gamma;self.n=n;self.p=len(gamma);self.diag=np.diag(G)
    def mv(self,x):return self.G@x
    def grad(self,x):return self.mv(x)-self.gamma

def corrected(A,b,n,q):
    A=A/n
    return (A-(1-q)*np.diag(np.diag(A)))/q**2,b/(n*q)

def bounded(rng,n,p,corr):
    return rng.choice([-1.,1.],size=(n,p)) if corr==0 else np.where(ar(rng,n,p,corr)>=0,1.,-1.)

def calibration():
    records=[];p=240;q=.7
    for s,corr in [(1,0),(4,0),(4,.3)]:
        truth=np.zeros(p);truth[:s]=1.2*np.where(np.arange(s)%2==0,1.,-1.)
        for rep in range(10):
            seed=20261110+100*s+1000*int(corr*10)+rep;rng=np.random.default_rng(seed);nodes=[]
            for j in range(20):
                X=bounded(rng,120,p,corr);y=X@truth+rng.uniform(-.2,.2,120)
                nodes.append(rs.Node(X*(rng.random(X.shape)<q),y,q,True))
            candidates=[];audits=[]
            for factor in GRID:
                x,info,cert=audited_fit(nodes,np.std(nodes[0].y,ddof=1)/q,factor,'trim','scad',seed)
                candidates.append(x);audits.append(dict(factor=factor,status=info['status'],local=bool(cert['passed']),l2=float(np.linalg.norm(x-truth))))
            # Candidate generation finishes before trusted observations are drawn.
            Asum=np.zeros((p,p));bsum=np.zeros(p);N=0;y_sum=0.;y2_sum=0.;moment_seconds=0.
            Aval=bval=None;ys_val=y2_val=0.
            for target in [10000,50000]:
                while N<target:
                    batch=min(1000 if N==0 else 5000,target-N)
                    X=bounded(rng,batch,p,corr);y=X@truth+rng.uniform(-.2,.2,batch);z=X*(rng.random(X.shape)<q)
                    start=time.perf_counter();Ab=z.T@z;bb=z.T@y
                    Asum+=Ab;bsum+=bb;y_sum+=float(y.sum());y2_sum+=float(y@y)
                    if N==0:Aval=Ab.copy();bval=bb.copy();ys_val=float(y.sum());y2_val=float(y@y)
                    N+=batch;moment_seconds+=time.perf_counter()-start
                start=time.perf_counter();G,gamma=corrected(Asum,bsum,N,q)
                certs=calibration_certificate(G,gamma,candidates,N,q,1.,1.2*s+.2,s)
                cert_seconds=time.perf_counter()-start
                admitted=[i for i,c in enumerate(certs) if c['passed'] and audits[i]['status']=='ok' and audits[i]['local']]
                selected=min(admitted,key=lambda i:certs[i]['radius']) if admitted else None
                # Same trusted N: first 1000 for masked validation, rest for fitting.
                # This baseline is evaluated, not certified with its own training data.
                start=time.perf_counter();Gt,gt=corrected(Asum-Aval,bsum-bval,N-1000,q);Gv,gv=corrected(Aval,bval,1000,q)
                nt=N-1000;sd=np.sqrt(max(0,(y2_sum-y2_val-(y_sum-ys_val)**2/nt)/(nt-1)))
                node=Moments(Gt,gt,nt);baselines=[]
                for factor in GRID:
                    x,lam,info=rs.initial(node,sd/q,factor)
                    val=float(x@Gv@x-2*gv@x) if info['status']=='ok' else np.inf
                    baselines.append(dict(factor=factor,status=info['status'],validation=val,l2=float(np.linalg.norm(x-truth))))
                good=[v for v in baselines if v['status']=='ok'];baseline=min(good,key=lambda v:v['validation']) if good else None
                scad_opts=[]
                for factor in GRID:
                    x,info=rs.fit([node],sd/q,factor,'mean','scad',0,0,'none',seed)
                    val=float(x@Gv@x-2*gv@x) if info['status']=='ok' else np.inf
                    scad_opts.append(dict(factor=factor,status=info['status'],validation=val,l2=float(np.linalg.norm(x-truth))))
                good=[v for v in scad_opts if v['status']=='ok'];baseline_scad=min(good,key=lambda v:v['validation']) if good else None
                baseline_seconds=time.perf_counter()-start
                records.append(dict(s=s,latent_ar=corr,rep=rep,seed=seed,N=N,selected_index=selected,candidates=[dict(a,calibration=c,covered=bool(c['radius'] is not None and a['l2']<=c['radius'])) for a,c in zip(audits,certs)],baseline=baseline,baseline_candidates=baselines,baseline_scad=baseline_scad,baseline_scad_candidates=scad_opts,moment_seconds=moment_seconds,certificate_seconds=cert_seconds,baseline_fit_select_seconds=baseline_seconds,dense_gram_bytes=int(G.nbytes)))
        write('reviewer_calibration.json',records,p=p,q=q,training_n=2400,grid=GRID,delta=.05,seeds=10,notes='Three bounded designs; each N prespecified, nested within seed, no adaptive stopping. Trusted-only corrected Lasso and scaled-weight SCAD each use N-1000 fit rows and 1000 masked validation rows from the same trusted sample; neither receives a coverage claim. H=1, Ymax=1.2*s+0.2. All distributed candidates fixed before calibration. Correlated features are signs of Gaussian AR(1) with latent correlation 0.3. Moment timing excludes random data generation; baseline timing includes both four-point grids and excludes shared moment construction. Dense Gram bytes exclude other arrays and process memory.')
        print('calibration',s,corr,'finished',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('suite',choices=['unequal','calibration']);args=ap.parse_args()
    with threadpool_limits(limits=1):globals()[args.suite]()
