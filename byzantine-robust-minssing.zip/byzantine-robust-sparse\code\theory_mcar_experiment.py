"""Conditional-theory MCAR experiment with prespecified seeds and full path audits.

Sample-specific valid bounds use simulation truth and honest labels explicitly.
This is a diagnostic of conditional theorems, not a deployable calibration rule.
No replicate, attack outcome, or candidate is selected by estimation accuracy.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[key]='1'
import argparse, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
from contextlib import nullcontext
from robust_sparse import aggregate, attack, envelope_fit, kkt, penalty_weights, soft
ROOT=Path(__file__).resolve().parents[1]
P=24; S=2; M_NODES=8; ROUNDS=12; NOISE_SD=.5; BATCH=10000
TRUTH=np.zeros(P); TRUTH[[0,12]]=[1.2,-1.2]
R0=float(np.linalg.norm(TRUTH)); ETA=12/13
CONFIGS=[
 dict(name='n20000',q=.7,n=20000,b=1,f=1,attack='adaptive_range'),
 dict(name='n80000',q=.7,n=80000,b=1,f=1,attack='adaptive_range'),
 dict(name='reference',q=.7,n=320000,b=1,f=1,attack='adaptive_range'),
 dict(name='q050',q=.5,n=320000,b=1,f=1,attack='adaptive_range'),
 dict(name='q090',q=.9,n=320000,b=1,f=1,attack='adaptive_range'),
 dict(name='clean',q=.7,n=320000,b=0,f=0,attack='none'),
 dict(name='two_attacks',q=.7,n=320000,b=2,f=2,attack='adaptive_range'),
 dict(name='gaussian',q=.7,n=320000,b=1,f=1,attack='gaussian')]
FINAL_SEEDS=list(range(27021001,27021021)); PILOT_SEEDS=[27020001,27020002]
PLAN=dict(version=1,p=P,s=S,m=M_NODES,rounds=ROUNDS,noise_sd=NOISE_SD,
    truth=TRUTH.tolist(),R0=R0,eta=ETA,configs=CONFIGS,final_seeds=FINAL_SEEDS,
    pilot_seeds=PILOT_SEEDS,generated_at='2026-10-21',
    design='Independent standard Gaussian covariates, independent Gaussian response noise, independent coordinate MCAR. Nested n within q=.7; shared X, noise, and uniforms across observation probabilities. All nodes generated before declaring last f nodes Byzantine.',
    bounds='Full master eigenvalues give kappa and M; K then determined by theorem. Exact row top-min(K+s,p) Euclidean norm bounds honest curvature mismatch. a_H and tau use true scores and honest identities. These sample-valid theoretical inputs are not estimated deployment quantities.',
    selection='No tuning or validation selection; fixed SCAD policy, zero initialization, all prespecified seeds retained. Samples with rho>=1 are recorded as inadmissible.',
    attack='adaptive_range: each round chooses between honest coordinate 0.3 and 0.7 quantiles, taking the candidate with largest trimmed-gradient deviation from the honest mean; changes with current honest gradients, hence current iterate. Ties use an alternating coordinate/round rule. Gaussian replacement uses N(0,20^2 I).',
    diagnostics='Every local update is logged and checked for support, sparse-ball radius, full-coordinate KKT at stopping, exceptional-set and weight bounds, surrogate-score bounds, outer recursion, beta-min threshold recovery when applicable. Numerical comparison with original envelope_fit uses Gaussian and no-attack pilots.',
    inference='This checks conditional algebra/path guarantees and their empirical informativeness. It does not verify a calibrated high-probability event with unknown constants, universal attack robustness, or p>n performance.')

class Quadratic:
    def __init__(self,G,gamma,n,q):
        self.gram=G;self.gamma=gamma;self.p=len(gamma);self.n=n;self.q=q;self.diag=np.diag(G)
    def mv(self,x):return self.gram@x
    def grad(self,x):return self.mv(x)-self.gamma

def clean(v):
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    if isinstance(v,np.ndarray):return clean(v.tolist())
    if isinstance(v,np.generic):return clean(v.item())
    if isinstance(v,float) and not np.isfinite(v):return None
    return v

def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(clean(data),indent=2),encoding='utf-8');tmp.replace(path)

def generate(seed,qs=(.5,.7,.9)):
    """Only sufficient statistics persist; raw covariates never exceed BATCH rows."""
    snapshots={}
    for j in range(M_NODES):
        rng=np.random.default_rng(np.random.SeedSequence([seed,j,972]))
        G={q:np.zeros((P,P)) for q in qs};g={q:np.zeros(P) for q in qs}
        for first in range(0,320000,BATCH):
            size=min(BATCH,320000-first);X=rng.normal(size=(size,P))
            y=X@TRUTH+rng.normal(0,NOISE_SD,size);U=rng.random((size,P))
            for q in qs:
                Z=X*(U<q);G[q]+=Z.T@Z;g[q]+=Z.T@y
            n=first+size
            if n in (20000,80000,320000):
                for q in qs:
                    if q!=.7 and n!=320000:continue
                    A=G[q]/n;Gc=(A-(1-q)*np.diag(np.diag(A)))/q**2
                    snapshots.setdefault((q,n),[]).append(Quadratic(Gc.copy(),g[q].copy()/(n*q),n,q))
    return snapshots

def constants(nodes,f,b):
    honest=nodes[:len(nodes)-f] if f else nodes
    ev=np.linalg.eigvalsh(nodes[0].gram);kap=float(ev[0]);L=float(ev[-1])
    if kap<=0:return dict(kappa=kap,M=L,status='nonpositive_master',rho=None,Rinf=None)
    K=2*S+int(np.ceil((32/3)**2*(L/kap-1)**2*S))
    GH=np.mean([z.gram for z in honest],axis=0)
    scores=np.array([z.grad(TRUTH) for z in honest]);scoreH=scores.mean(0)
    a=float(np.abs(scoreH).max());tau=float(np.abs(scores-scoreH).max());r=min(K+S,P)
    d=max(float(np.sqrt(np.sort((z.gram-GH)**2,axis=1)[:,-r:].sum(1)).max()) for z in honest)
    omega=3*b/(len(nodes)-2*b);A=max(a+omega*tau,np.finfo(float).tiny);B=(1+omega)*d
    rho=16*np.sqrt(S)*B/kap;Rinf=16*np.sqrt(S)*A/(kap*(1-rho)) if rho<1 else None
    return dict(kappa=kap,M=L,K=K,aH=a,tau=tau,d=d,omega=omega,A=A,B=B,rho=rho,Rinf=Rinf,
        status='admissible' if rho<1 else 'rho_not_below_one',master_globally_indefinite=False,
        restriction_dimension=min(4*K,P),honest_count=len(honest),n_eff=len(honest)*nodes[0].n)

def adversarial(raw,f,b,kind,t,seed,x):
    if kind!='adaptive_range':return attack(raw,f,kind,t,seed)
    good=raw[:-f];lo,hi=np.quantile(good,[.3,.7],axis=0);mean=good.mean(0)
    low=raw.copy();high=raw.copy();low[-f:]=lo;high[-f:]=hi
    e_low=aggregate(low,'trim',b)-mean;e_high=aggregate(high,'trim',b)-mean
    tie=(np.arange(raw.shape[1])+t)%2==0
    choose_high=(np.abs(e_high)>np.abs(e_low))|((np.abs(e_high)==np.abs(e_low))&tie)
    out=raw.copy();out[-f:]=np.where(choose_high,hi,lo)
    return out

def instrument(nodes,cfg,seed,const):
    kap,L,K,A,B,rho=[const[k] for k in ('kappa','M','K','A','B','rho')]
    x=np.zeros(P);R=R0;rounds=[];tolcheck=2e-10
    checks=dict(support=True,sparse_ball=True,score=True,exceptional_set=True,weights=True,local_contraction=True,
        kkt=True,outer_radius=True,geometric_identity=True,threshold_support=True,finite=True)
    for t in range(ROUNDS):
        u=x.copy();oldR=R;target=8*(A+B*R);base=max(target,R/(2.35*np.sqrt(S)),kap*R/(2*np.sqrt(S)))
        raw=np.array([z.grad(u) for z in nodes]);sent=adversarial(raw,cfg['f'],cfg['b'],cfg['attack'],t,seed,u)
        g=aggregate(sent,'trim',cfg['b']);c=nodes[0].mv(u)-g
        shape=penalty_weights(u,base,'scad')/base
        E=(TRUTH!=0)|((TRUTH==0)&(np.abs(u)>2.35*base))
        score=float(np.abs(nodes[0].mv(TRUTH)-c).max())
        checks['score'] &= score<=A+B*np.linalg.norm(u-TRUTH)+tolcheck
        checks['exceptional_set'] &= int(E.sum())<=2*S
        checks['weights'] &= bool(np.all((shape>=-tolcheck)&(shape<=1+tolcheck)) and np.all(shape[~E]>=.5-tolcheck))
        levels=[];lam=base;round_maxsupport=0
        while True:
            final=lam<=target*(1+1e-12);w=lam*shape
            tol=min(1e-5,target/1000) if final else lam/26
            tol=min(tol,lam/4*np.sqrt(S/(2*K)))
            gradient=nodes[0].mv(x)-c;path=[];rad=4*np.sqrt(S)*lam/kap;previous_step=None;ratios=[]
            checks['score'] &= score<=lam/8+tolcheck
            for k in range(100000):
                residual=kkt(gradient,x,w);error=float(np.linalg.norm(x-TRUTH));support=int(np.count_nonzero(x))
                path.append(dict(k=k,error=error,support=support,kkt=residual))
                checks['support'] &= support<=K
                checks['sparse_ball'] &= error<=rad+tolcheck
                checks['finite'] &= bool(np.isfinite(x).all())
                round_maxsupport=max(round_maxsupport,support)
                if residual<=tol:break
                trial=soft(x-gradient/L,w/L);delta=trial-x;step=float(np.linalg.norm(delta))
                path[-1]['step_norm']=step
                if previous_step is not None:
                    checks['local_contraction'] &= step<=(1-kap/L)*previous_step+tolcheck
                    if previous_step>1e-12:ratios.append(step/previous_step)
                previous_step=step
                gradient+=nodes[0].mv(delta);x=trial
            else:
                checks['finite']=False
                return dict(status='iteration_cap',checks=checks,rounds=rounds)
            checks['kkt'] &= residual<=tol+tolcheck
            levels.append(dict(lambda_value=lam,tolerance=tol,radius=rad,iterations=k,path=path,contraction_modulus=1-kap/L,max_step_ratio=max(ratios,default=None)))
            if final:break
            lam=max(target,lam*ETA)
        R=2*np.sqrt(S)*target/kap;err=float(np.linalg.norm(x-TRUTH))
        closed=rho**(t+1)*R0+const['Rinf']*(1-rho**(t+1))
        checks['outer_radius'] &= err<=R+tolcheck
        checks['geometric_identity'] &= abs(closed-R)<=tolcheck
        active=np.flatnonzero(np.abs(x)>R).tolist();guaranteed=1.2>2*R
        correct=active==np.flatnonzero(TRUTH).tolist()
        if guaranteed:checks['threshold_support'] &= correct
        rounds.append(dict(round=t+1,error=err,radius=R,transient=rho**(t+1)*R0,
            excess_radius=R-const['Rinf'],max_support=round_maxsupport,score=score,
            uniform_score_bound=A+B*float(np.linalg.norm(u-TRUTH)),old_radius=oldR,
            target=target,base=base,exceptional_size=int(E.sum()),levels=levels,
            x=x.tolist(),threshold_guarantee=guaranteed,threshold_exact=correct,
            raw_exact=bool(np.array_equal(x!=0,TRUTH!=0)),
            aggregate_bias=float(np.max(np.abs(g-raw[:M_NODES-cfg['f']].mean(0))))))
    return dict(status='ok' if all(checks.values()) else 'diagnostic_failed',checks=checks,rounds=rounds,
        initial_error=R0,final_error=err,final_radius=R,max_support=max(r['max_support'] for r in rounds),
        total_updates=sum(a['iterations'] for r in rounds for a in r['levels']),final_x=x.tolist())

def summarize(records):
    out=[]
    for cfg in CONFIGS:
        rr=[r for r in records if r['config']['name']==cfg['name']];good=[r for r in rr if r.get('fit',{}).get('status')=='ok']
        vals=[r['fit']['final_error'] for r in good];rad=[r['fit']['final_radius'] for r in good]
        out.append(dict(config=cfg,N=len(rr),admissible=sum(r['constants']['status']=='admissible' for r in rr),
            successful=len(good),rho_median=float(np.median([r['constants']['rho'] for r in rr if r['constants'].get('rho') is not None])) if rr else None,
            rho_min=min([r['constants']['rho'] for r in rr if r['constants'].get('rho') is not None],default=None),rho_max=max([r['constants']['rho'] for r in rr if r['constants'].get('rho') is not None],default=None),
            K_range=[min([r['constants'].get('K',P) for r in rr],default=0),max([r['constants'].get('K',P) for r in rr],default=0)],
            mean_error=float(np.mean(vals)) if vals else None,error_se=float(np.std(vals,ddof=1)/np.sqrt(len(vals))) if len(vals)>1 else None,
            median_radius=float(np.median(rad)) if rad else None,
            improving_radius=sum(r['constants']['Rinf']<R0 for r in good),
            threshold_guaranteed=sum(r['fit']['rounds'][-1]['threshold_guarantee'] for r in good),
            threshold_exact=sum(r['fit']['rounds'][-1]['threshold_exact'] for r in good),
            raw_exact=sum(r['fit']['rounds'][-1]['raw_exact'] for r in good),
            max_observed_support=max([r['fit']['max_support'] for r in good],default=None)))
    return out

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--pilot',action='store_true');pa.add_argument('--replay',action='store_true');args=pa.parse_args()
    start=time.time();records=[];comparisons=[]
    location=ROOT/'results' if not args.pilot else ROOT.parent.parent/'work'/'revision27'
    prefix='theory_mcar_pilot' if args.pilot else 'theory_mcar'
    plan_path=location/(prefix+'_plan.json')
    if plan_path.exists():
        assert json.loads(plan_path.read_text(encoding='utf-8'))==PLAN, 'Existing fixed plan differs; do not overwrite it.'
    else:save(plan_path,PLAN)
    seeds=PILOT_SEEDS if args.pilot else FINAL_SEEDS
    for rep,seed in enumerate(seeds):
        if args.replay:
            archive=np.load(location/f'theory_mcar_moments_{seed}.npz');data={}
            for cfg in CONFIGS:
                q,n=cfg['q'],cfg['n'];tag=f'q{round(q*100):03d}_n{n}'
                if (q,n) not in data:data[q,n]=[Quadratic(G,g,n,q) for G,g in zip(archive[tag+'_gram'],archive[tag+'_gamma'])]
        else:data=generate(seed)
        if not args.pilot and not args.replay:
            arrays={}
            for (q,n),nodes in data.items():
                tag=f'q{round(q*100):03d}_n{n}'
                arrays[tag+'_gram']=np.array([z.gram for z in nodes])
                arrays[tag+'_gamma']=np.array([z.gamma for z in nodes])
            np.savez_compressed(location/f'theory_mcar_moments_{seed}.npz',**arrays)
        for cfg in CONFIGS:
            nodes=data[cfg['q'],cfg['n']];ct=constants(nodes,cfg['f'],cfg['b'])
            rec=dict(rep=rep,seed=seed,config=cfg,constants=ct,truth_assisted_bounds=True)
            if ct['status']=='admissible':
                rec['fit']=instrument(nodes,cfg,seed,ct)
                if cfg['attack'] in ('none','gaussian'):
                    ref,info=envelope_fit(nodes,ct['A'],ct['B'],R0,ct['kappa'],ct['M'],S,rounds=ROUNDS,b=cfg['b'],f=cfg['f'],attack_kind=cfg['attack'],seed=seed)
                    err=float(np.max(np.abs(ref-np.array(rec['fit']['final_x']))))
                    comparisons.append(dict(seed=seed,config=cfg['name'],maximum_absolute_difference=err,passed=err<1e-11))
            records.append(rec)
        report=dict(plan=PLAN,records=records,summary=summarize(records),core_comparisons=comparisons,
            wall_seconds_current_invocation=time.time()-start,execution_mode='replay' if args.replay else 'generate',python=sys.version,numpy=np.__version__,platform=platform.platform(),
            script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
        save(location/(prefix+'.json'),report)
        save(location/(prefix+'_summary.json'),{k:v for k,v in report.items() if k!='records'})
        print(json.dumps(dict(rep=rep,seed=seed,seconds=round(time.time()-start,2),rows=[{k:r[k] for k in ('config','admissible','successful','mean_error','median_radius','threshold_guaranteed')} for r in report['summary']]),default=str),flush=True)
    if any(not c['passed'] for c in comparisons):raise RuntimeError('Core solver disagreement')
    if any(r.get('fit',{}).get('status')=='diagnostic_failed' for r in records):raise RuntimeError('Theoretical diagnostic failure')

if __name__=='__main__':
    with nullcontext():main()
