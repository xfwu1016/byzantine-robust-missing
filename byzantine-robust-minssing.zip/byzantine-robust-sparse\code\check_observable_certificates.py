"""Small mathematical regression checks for the observable certificates."""
import json,itertools
from pathlib import Path
import numpy as np
from certificates import local_certificate,calibration_certificate
from robust_sparse import soft
ROOT=Path(__file__).resolve().parents[1]
class Quadratic:
 def __init__(self,G):self.gram=G
 def mv(self,x):return self.gram@x
G=np.array([[2.,.2,.1],[.2,1.,.1],[.1,.1,-2.]])
w=np.array([.2,.2,1.]);star=np.array([1.,-1.,0.]);c=G@star+w*np.sign(star)
x=star+np.array([.01,-.01,0]);cert=local_certificate(Quadratic(G),c,w,x)
assert np.linalg.eigvalsh(G)[0]<0 and cert['passed']
center=x.copy();trace=[]
for k in range(100):
 x=soft(x-(G@x-c)/cert['L'],w/cert['L'])
 assert x[2]==0 and np.linalg.norm(x-center)<=cert['radius']+1e-12
 trace.append(float(np.linalg.norm(x-star)))
assert trace[-1]<1e-12 and all(b<=cert['contraction']*a+1e-14 for a,b in zip(trace,trace[1:]))
c_bad=c.copy();c_bad[2]=2.;assert not local_certificate(Quadratic(G),c_bad,w,center)['passed']
assert not local_certificate(Quadratic(-np.eye(3)),c,w,center)['passed']
assert local_certificate(Quadratic(G),w,w,np.zeros(3))['passed']
# Exhaustive masked expectations: a bounded two-coordinate design.
theta=np.array([.7,0.]);candidate=np.array([.6,.1]);H=1.;Y=1.;q=.6
EG=np.zeros((2,2));Ed=np.zeros(2);scoremax=0.
for xx in itertools.product([-1.,1.],repeat=2):
 X=np.array(xx)
 for noise in [-.2,.2]:
  y=X@theta+noise
  for mask in itertools.product([0,1],repeat=2):
   M=np.array(mask);z=X*M;prob=.125*np.prod(np.where(M,q,1-q));A=np.outer(z,z)
   gi=(A-(1-q)*np.diag(np.diag(A)))/q**2;di=z*y/q
   EG+=prob*gi;Ed+=prob*di;scoremax=max(scoremax,float(np.max(abs(gi@candidate-di))))
assert np.allclose(EG,np.eye(2)) and np.allclose(Ed,theta)
assert scoremax<=H*H*np.linalg.norm(candidate,1)/q**2+H*Y/q
# Every principal block is bounded below by the computed Gershgorin bound.
A=np.array([[1.,.08,-.04],[.08,.9,.02],[-.04,.02,1.1]])
for r in range(1,4):
 off=abs(A).copy();np.fill_diagonal(off,0);b=min(np.diag(A)-np.sort(off,axis=1)[:,::-1][:,:r-1].sum(1))
 for size in range(1,r+1):
  for U in itertools.combinations(range(3),size):assert np.linalg.eigvalsh(A[np.ix_(U,U)])[0]>=b-1e-12
cc=calibration_certificate(np.eye(2),theta,[candidate],100000,q,H,Y,1)[0]
assert cc['passed'] and np.linalg.norm(candidate-theta)<=cc['radius']
out=dict(indefinite_local_contraction=True,inactive_violation_rejected=True,nonpositive_active_block_rejected=True,empty_support_boundary=True,enumerated_mcar_moments=True,score_range_verified=True,gershgorin_supports_verified=True,calibration_radius_checked=True)
(ROOT/'results/observable_checks.json').write_text(json.dumps(out,indent=2));print(out)
