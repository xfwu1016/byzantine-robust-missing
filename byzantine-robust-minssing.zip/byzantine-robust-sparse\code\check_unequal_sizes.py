"""Verify unequal-size gradients, weighted concentration algebra and solver use."""
from pathlib import Path
import json
import numpy as np
from robust_sparse import Node,fit
ROOT=Path(__file__).resolve().parents[1]
sizes=[240,80,120,160,200,280,320,400]
rng=np.random.default_rng(98734);p=20;q=.9;truth=np.zeros(p);truth[:2]=[1.,-1.]
nodes=[];errors=[]
for n in sizes:
 X=rng.normal(size=(n,p));y=X@truth+rng.normal(scale=.2,size=n);z=X*(rng.random((n,p))<q)
 node=Node(z,y,q);nodes.append(node);A=z.T@z/n;G=(A-(1-q)*np.diag(np.diag(A)))/q**2
 test=rng.normal(size=p);err=np.max(abs(node.grad(test)-(G@test-z.T@y/(n*q))));errors.append(float(err));assert err<1e-11
honest=sizes[:-1];h=len(honest);weights=np.concatenate([np.full(n,1/(h*n)) for n in honest]);neff=h*h/sum(1/n for n in honest)
assert np.isclose(weights.sum(),1) and np.isclose(weights@weights,1/neff)
assert np.isclose(weights.max(),1/(h*min(honest))) and neff<=sum(honest)
x,info=fit(nodes,np.std(nodes[0].y,ddof=1)/q,.6,'trim','scad',1,1,'gaussian',978)
assert info['status']=='ok' and np.isfinite(x).all()
try:fit(nodes,1.,.6,'vrmom','scad',1,1,'gaussian',978)
except ValueError:vrmom_rejected=True
else:raise AssertionError('Unequal-size VRMOM must not silently use common variance')
# Compare the preserved equal-size branch against the preceding implementation.
eq=[Node(node.z[:80],node.y[:80],q) for node in nodes]
a,ia=fit(eq,1.,1.2,'trim','scad',1,1,'gaussian',978)
fixture=json.loads((ROOT/'results/equal_size_reference.json').read_text())
assert np.array_equal(a,fixture['coefficients'])
assert ia==fixture['info']
result=dict(node_sizes=sizes,local_gradient_max_error=max(errors),honest_effective_n=neff,honest_total_n=sum(honest),weight_identities=True,unequal_fit_status=info['status'],unequal_l2=float(np.linalg.norm(x-truth)),equal_branch_identical=True,vrmom_unequal_rejected=vrmom_rejected)
(ROOT/'results/unequal_size_checks.json').write_text(json.dumps(result,indent=2));print(result)
