"""Fast correctness checks for the numerical core.

Runs in seconds, needs no data files and no network. It verifies the
matrix-free and dense corrected moments, the trimming/median/VRMOM
aggregation identities, the KKT residual, and the constructed indefinite
quadratic used for the theorem checks.

Run from the repository root:

    python code/smoke_test.py
"""
import numpy as np

from robust_sparse import Node, aggregate, envelope_fit, kkt


def check_moments():
    rng = np.random.default_rng(23)
    z = rng.normal(size=(150, 80)) * (rng.random((150, 80)) < 0.7)
    y = rng.normal(size=150)
    a = Node(z, y, 0.7)
    b = Node(z, y, 0.7, dense=True)
    v = rng.normal(size=80)
    assert np.allclose(a.mv(v), b.mv(v), atol=1e-12)
    assert np.allclose(a.grad(v), b.grad(v), atol=1e-12)
    raw = z * (z @ v - y * 0.7)[:, None] / 0.7**2 - 0.3 * z * z * v / 0.7**2
    assert np.allclose(raw.mean(0), a.grad(v), atol=1e-12)
    print('moments: matrix-free equals dense; score identity holds')


def check_aggregators():
    rng = np.random.default_rng(5)
    msgs = rng.normal(size=(20, 80))
    sd = np.ones(80)
    assert np.allclose(aggregate(msgs, 'trim', 0), aggregate(msgs, 'mean'))
    assert np.allclose(aggregate(msgs + 3, 'vrmom', 2, sd, 150),
                       aggregate(msgs, 'vrmom', 2, sd, 150) + 3)
    assert np.allclose(aggregate(np.ones((20, 80)), 'vrmom', 2, sd, 150), 1)
    print('aggregators: trimming, VRMOM translation equivariance and constant limit hold')


class _Quadratic:
    """Constructed indefinite quadratic: global negative curvature, sparse PD blocks."""

    def __init__(self, p, truth, score):
        self.p = p
        self.diag = np.full(p, 1 - 1.2 / p)
        self.gamma = self.mv(truth) - score

    def mv(self, x):
        return x - 1.2 * np.sum(x) / self.p

    def grad(self, x):
        return self.mv(x) - self.gamma


def check_envelope_policy():
    p = 4000
    truth = np.zeros(p)
    truth[:2] = [1.2, -1.2]
    score = np.linspace(-0.001, 0.001, p)
    nodes = [_Quadratic(p, truth, score) for _ in range(10)]
    x, info = envelope_fit(nodes, 0.002, 0.005, 2.0, 0.98, 1.0, 2,
                           rounds=6, b=1, f=1, attack_kind='gaussian')
    assert info['status'] == 'ok'
    assert all(t['max_support'] <= info['K'] for t in info['trace'])
    assert np.linalg.norm(x - truth) <= info['trace'][-1]['radius']
    assert 1 - 1.2 * 4 * info['K'] / 4000 >= 0.98
    print('envelope policy: sparse-path and error bound hold on the constructed quadratic')


if __name__ == '__main__':
    check_moments()
    check_aggregators()
    check_envelope_policy()
    print('smoke test passed')
