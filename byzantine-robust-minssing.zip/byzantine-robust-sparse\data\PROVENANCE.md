# Public dataset provenance

- Dataset: **Superconductivty Data** (the official UCI title retains this spelling).
- Creator: Kam Hamidieh, 2018.
- Repository: UCI Machine Learning Repository, dataset 464.
- DOI: https://doi.org/10.24432/C53P47
- Dataset page: https://archive.ics.uci.edu/dataset/464/superconductivty+data
- Download source: https://archive.ics.uci.edu/static/public/464/superconductivty+data.zip
- License: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/
- Retrieved: 2026-10-08. The downloaded archive is unchanged; its SHA-256 is recorded in the real-data result metadata and package manifest.

The analysis reads `train.csv`, containing 21,263 rows, 81 predictors and the critical-temperature response. The new grouped evaluation uses `unique_m.csv` to keep identical normalized element compositions in one partition. Earlier random row splits do not isolate compositions. The supplied code introduces artificial independent missingness after training-only standardization; complete validation and test features are retained.

Changes made for analysis: random splitting, training-only centering/scaling, artificial masks, node partitioning, and response standardization. Original archive contents are not modified. Redistribution is under the dataset's stated CC BY 4.0 license with attribution above.

## Abalone

- Creators: Warwick Nash, Tracy Sellers, Simon Talbot, Andrew Cawthorn, Wes Ford (1994).
- UCI dataset page: https://archive.ics.uci.edu/dataset/1/abalone
- DOI: https://doi.org/10.24432/C55C7W
- Original archive: https://archive.ics.uci.edu/static/public/1/abalone.zip
- Retrieved: 2026-10-09; SHA-256 is recorded in the package manifest.
- License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/

The unchanged archive contains 4,177 records. The evaluation omits categorical sex, uses seven continuous measurements, and predicts ring count. Changes for analysis are training-only scaling, random splits, artificial MCAR masks, node partitioning, and response scaling. The original archive remains unchanged and is redistributed with the attribution above.

## Bundled checksums (SHA-256)

- `superconductivity.zip`: `87f4490d73390ff94ee01dbf0d7d32abc80b22f2c803d471765cfc46a9f6371e`
- `abalone.zip`: `755a6a67c5b266961a3f149ea13be2cfb6e6c727e48cee3c83bc0b4526210ee4`

The archives are redistributed unchanged under CC BY 4.0 with the attribution
above. The code applies random splitting, training-only centring and scaling,
artificial MCAR masks, node partitioning and response scaling at analysis time;
it does not modify the archives themselves.

## Bundled fonts

`code/assets/DejaVuSans.ttf` and `code/assets/DejaVuSans-Bold.ttf` are used
only for reproducible vector artwork and are distributed under the DejaVu
licence; see `code/assets/LICENSE-DejaVu.txt`.
