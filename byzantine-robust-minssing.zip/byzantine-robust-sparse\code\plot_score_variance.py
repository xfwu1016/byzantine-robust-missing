"""Plot the analytical score-variance decomposition in Section 4.1.

This is an illustration of the stated independent, standardized predictor
model, not a simulation result or a fit to either real-data example.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    output_dir = Path(__file__).resolve().parents[1] / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)

    q = np.linspace(0.2, 1.0, 401)
    noise_variance = 1.0
    other_signal_energy = 1.0
    noise = noise_variance / q
    missing = (1.0 - q) * other_signal_energy / q**2
    total = noise + missing
    assert np.allclose(total, q**-2)
    assert np.isclose(missing[-1], 0.0)

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["DejaVu Serif"],
            "font.size": 10,
            "axes.labelsize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "legend.fontsize": 9,
            "mathtext.fontset": "dejavuserif",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    fig, ax = plt.subplots(figsize=(5.3, 2.15))
    ax.plot(q, total, color="#2166AC", linewidth=1.9, label="Total")
    ax.plot(
        q,
        missing,
        color="#D97706",
        linestyle=(0, (5, 2.4)),
        linewidth=1.8,
        label="Missing-covariate contribution",
    )
    ax.plot(
        q,
        noise,
        color="#666666",
        linestyle=(0, (1.2, 1.8)),
        linewidth=1.9,
        label="Response-noise contribution",
    )
    ax.set_xlabel(r"Observation probability $q$")
    ax.set_ylabel(r"Score variance $\nu_l^2$")
    ax.set_xlim(0.2, 1.0)
    ax.set_ylim(0, 26)
    ax.set_xticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticks([0, 5, 10, 15, 20, 25])
    ax.grid(axis="y", color="#D8D8D8", linewidth=0.5, alpha=0.6)
    ax.set_axisbelow(True)
    ax.tick_params(direction="out", length=3, width=0.6)
    ax.spines["left"].set_linewidth(0.6)
    ax.spines["bottom"].set_linewidth(0.6)
    ax.legend(loc="upper right", frameon=False, handlelength=2.8, labelspacing=0.6)
    fig.subplots_adjust(left=0.115, right=0.965, bottom=0.24, top=0.97)
    fig.savefig(output_dir / "score_variance.pdf", metadata={"Title": "Analytical score-variance decomposition"})
    fig.savefig(output_dir / "score_variance.png", dpi=220)
    plt.close(fig)

    provenance = {
        "kind": "analytical illustration",
        "source": "Section 4.1, independent standardized covariates and independent noise",
        "formula": "nu_l^2 = sigma^2/q + (1-q)*||theta_star_minus_l||_2^2/q^2",
        "parameters": {"sigma_squared": noise_variance, "other_signal_energy": other_signal_energy},
        "q_range": [0.2, 1.0],
        "grid_points": len(q),
        "relation_to_empirical_results": "Illustrative parameter choices; not fitted to simulation or real-data results.",
        "checks": {"total_equals_q_to_minus_two": True, "missing_contribution_zero_at_q_one": True},
        "generator": "code/plot_score_variance.py",
        "outputs": ["figures/score_variance.pdf", "figures/score_variance.png"],
    }
    (output_dir / "score_variance_provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print("Created analytical score-variance figure (PDF and PNG).")


if __name__ == "__main__":
    main()
