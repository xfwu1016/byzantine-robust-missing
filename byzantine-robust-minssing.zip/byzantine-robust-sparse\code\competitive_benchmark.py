"""Prespecified paired MCAR/Byzantine benchmark; every outcome is retained.

All corrected competitors use the unchanged robust_sparse solver.  The traced
wrapper below only records outer iterates.  SLARD-ZF uses the squared-loss
median/trimmed gradient plus local Lasso update on zero-filled covariates.
It shares our validation-selected penalty schedule, not the original paper's
unknown-constant theoretical tuning.  Runtime is serial, not network timing.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
import argparse
import hashlib
import json
import math
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
try:
    from threadpoolctl import threadpool_limits
except ImportError:
    # BLAS thread limits above are set before importing NumPy.
    from contextlib import nullcontext
    def threadpool_limits(limits=1):
        return nullcontext()
import robust_sparse as core

ROOT = Path(__file__).resolve().parents[1]
GRID = [.075, .15, .3, .6, 1.2, 2.4, 4.8]
METHODS = [
    ('Trim-SCAD', 'trim', 'scad', True),
    ('Trim-MCP', 'trim', 'mcp', True),
    ('Trim-Lasso', 'trim', 'lasso', True),
    ('VRMOM-SCAD', 'vrmom', 'scad', True),
    ('Median-SCAD', 'median', 'scad', True),
    ('Mean-SCAD', 'mean', 'scad', True),
    ('NoCorrection-SCAD', 'trim', 'scad', False),
    ('M-SLARD-ZF', 'median', 'lasso', False),
    ('T-SLARD-ZF', 'trim', 'lasso', False),
]


def clean(obj):
    if isinstance(obj, dict):
        return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return clean(obj.tolist())
    if isinstance(obj, (np.floating, float)):
        return float(obj) if np.isfinite(obj) else None
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj


def configurations():
    out = []
    def add(label, q=.7, f=2, attack='gaussian', rho=.6, p=256,
            n=512, layout='clustered'):
        out.append(dict(label=label, q=q, f=f, b=f, attack=attack,
                        rho=rho, p=p, n=n, m=12, layout=layout,
                        noise_sd=1., coefficient_magnitude=1.))
    for q in [.9, .7, .5]:
        add(f'q{q:.1f}_clean', q=q, f=0, attack='none')
        for f in [1, 2]:
            for attack in ['gaussian', 'stealth']:
                add(f'q{q:.1f}_f{f}_{attack}', q=q, f=f, attack=attack)
    add('independent', rho=0.)
    add('q0.3_gaussian', q=.3)
    add('q0.3_stealth', q=.3, attack='stealth')
    add('complete', q=1.)
    add('highdim_gaussian', p=768)
    add('highdim_stealth', p=768, attack='stealth')
    add('spread', layout='spread')
    add('alternating', layout='alternating')
    return out


def make_plan(mode, repeats):
    configs = configurations()
    if mode == 'pilot':
        names = ['q0.7_f2_gaussian', 'q0.5_f2_stealth', 'highdim_gaussian']
        configs = [c for c in configs if c['label'] in names]
    seed_start = 28011001 if mode == 'pilot' else 28021001
    return dict(
        created_utc=datetime.now(timezone.utc).isoformat(), mode=mode,
        purpose='Joint missing-covariate and Byzantine competitiveness; no outcome selection',
        configurations=configs, repeats=repeats,
        seeds=list(range(seed_start, seed_start+repeats)), grid=GRID,
        methods=[dict(name=n, aggregation=a, penalty=p, corrected=c)
                 for n, a, p, c in METHODS],
        rounds=8, stage_iteration_cap=1200, validation_n=400, test_n=2000,
        selection='Lowest complete-validation MSE among fully successful candidates',
        failures='All candidate failures retained; no successful candidate is a failed repetition',
        truth_use='Evaluation and the prespecified stealth attack only; never tuning or fitting',
        scale='Master response SD / q for corrected methods; master response SD for zero-filled methods',
        pairing='Shared latent data, masks, validation and test within seeds/configurations; nested masks across q',
        support_threshold=1e-6, targets=[.1, .2, .5],
        timing='Serial fitting and validation wall time including all candidate initializations; excludes moment construction and has no interprocess or network claim',
        slard='Squared-loss SLARD update structure with zero filling; shared validation grid, proximal solver and eight-round schedule replace original BIC/FISTA/five-round numerical choices',
        core_sha256=hashlib.sha256((ROOT/'code'/'robust_sparse.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        numpy=np.__version__, python=platform.python_version(), platform=platform.platform())


def ar(rng, n, p, rho):
    x = rng.normal(size=(n, p))
    for j in range(1, p):
        x[:, j] = rho*x[:, j-1] + math.sqrt(1-rho*rho)*x[:, j]
    return x


def make_data(cf, seed):
    layout_code = {'clustered': 0, 'spread': 1, 'alternating': 2}[cf['layout']]
    rng = np.random.default_rng(np.random.SeedSequence(
        [seed, cf['p'], cf['n'], round(cf['rho']*100), layout_code]))
    p, n, q = cf['p'], cf['n'], cf['q']
    theta = np.zeros(p)
    active = ([0, 1, 2, p//2, p//2+1, p//2+2]
              if cf['layout'] != 'spread' else [j*(p//6) for j in range(6)])
    values = ([1, -1, 1, -1, 1, -1]
              if cf['layout'] == 'alternating' else [1, 1, 1, -1, -1, -1])
    theta[active] = np.array(values)*cf['coefficient_magnitude']
    corrected, zero_filled = [], []
    digest = hashlib.sha256()
    for j in range(cf['m']):
        x = ar(rng, n, p, cf['rho'])
        y = x@theta + rng.normal(scale=cf['noise_sd'], size=n)
        z = x*(rng.random(x.shape) < q)
        corrected.append(core.Node(z, y, q, dense=True))
        # Reuse the same observed products exactly, not an independently masked copy.
        zero_filled.append(core.Node(z, y, 1., dense=True))
        digest.update(z.tobytes()); digest.update(y.tobytes())
    xv = ar(rng, 400, p, cf['rho'])
    yv = xv@theta + rng.normal(scale=cf['noise_sd'], size=400)
    xt = ar(rng, 2000, p, cf['rho'])
    yt = xt@theta + rng.normal(scale=cf['noise_sd'], size=2000)
    for a in [xv, yv, xt, yt]:
        digest.update(a.tobytes())
    direction = np.sign(theta)
    for j in active:
        false = (j+6) % p
        if theta[false] == 0:
            direction[false] = -1
    covariance = cf['rho']**np.abs(np.arange(p)[:, None]-np.arange(p)[None, :])
    meta = dict(data_sha256=digest.hexdigest(), active=active, truth=theta.tolist(),
                master_min_eigenvalue=float(np.linalg.eigvalsh(corrected[0].gram)[0]))
    return corrected, zero_filled, xv, yv, xt, yt, theta, direction, covariance, meta


def metric(x, theta):
    active = np.abs(x) > 1e-6
    truth = theta != 0
    tp = int(np.sum(active & truth)); fp = int(np.sum(active & ~truth))
    fn = int(np.sum(~active & truth))
    return dict(l2=float(np.linalg.norm(x-theta)), exact=bool(np.array_equal(active, truth)),
                fp=fp, fn=fn, selected=int(active.sum()),
                f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 1.)


def traced_fit(nodes, scale, factor, agg, penalty, b, f, attack_kind,
               seed, direction, theta, rounds=8):
    """Exact core.fit updates, plus passive outer-iterate records."""
    master = nodes[0]; m = len(nodes); p = master.p
    x, local, initial_info = core.initial(master, scale, factor)
    x = x.copy()
    trace = []
    paths = [dict(round=0, **metric(x, theta))]
    coefs = [x.copy()]
    if initial_info['status'] != 'ok':
        return x, dict(status='initial_failed', initial=initial_info,
                       trace=trace, path=paths), coefs
    floor = factor*scale*(np.sqrt(np.log(p)/(m*master.n))
                          +(b/m)*np.sqrt(np.log(p)/master.n))
    for t in range(rounds):
        raw = np.array([node.grad(x) for node in nodes])
        sent = core.attack(raw, f, attack_kind, t, seed, direction)
        sd = master.score_sd(x) if agg == 'vrmom' else None
        g = core.aggregate(sent, agg, b, sd, master.n)
        c = master.mv(x)-g
        target = max(floor, local*.65**(t+1))
        base = max(target, local*.65**t)
        x, info = core.homotopy(master, c, x, core.penalty_weights(x, base, penalty), base, target)
        trace.append(dict(info, lambda_value=float(target)))
        paths.append(dict(round=t+1, **metric(x, theta)))
        coefs.append(x.copy())
        if info['status'] != 'ok':
            break
    return x, dict(status=trace[-1]['status'], initial=initial_info,
                   trace=trace, path=paths), coefs


def fit_method(cf, seed, method, dataset):
    corrected, zero_filled, xv, yv, xt, yt, theta, direction, covariance, meta = dataset
    name, agg, penalty, correction = method
    nodes = corrected if correction else zero_filled
    scale = float(np.std(nodes[0].y, ddof=1)/(cf['q'] if correction else 1.))
    candidates, stored = [], []
    for factor in GRID:
        start = time.perf_counter()
        x, info, coefs = traced_fit(nodes, scale, factor, agg, penalty, cf['b'], cf['f'],
                                    cf['attack'], seed, direction, theta)
        fitting_seconds = time.perf_counter()-start
        valid = info['status'] == 'ok'
        val = float(np.mean((yv-xv@x)**2)) if valid else None
        seconds = time.perf_counter()-start
        updates = info['initial'].get('iterations', 0)+sum(z['iterations'] for z in info['trace'])
        stages = info['initial'].get('stages', 0)+sum(z.get('stages', 0) for z in info['trace'])
        record = dict(factor=factor, validation_mse=val, seconds=seconds,
                      fitting_seconds=fitting_seconds,
                      total_updates=updates, total_stages=stages,
                      communication_rounds=len(info['trace']),
                      vector_payload_bytes=16*(cf['m']-1)*cf['p']*len(info['trace']), **info,
                      final_diagnostic=metric(x, theta))
        candidates.append(record); stored.append((x, coefs))
    eligible = [i for i, r in enumerate(candidates) if r['status'] == 'ok']
    selected = min(eligible, key=lambda i: candidates[i]['validation_mse']) if eligible else None
    result = dict(method=name, scale=scale, candidates=candidates,
                  candidate_successes=len(eligible), selected_index=selected,
                  total_search_seconds=sum(r['seconds'] for r in candidates),
                  total_search_updates=sum(r['total_updates'] for r in candidates),
                  total_search_stages=sum(r['total_stages'] for r in candidates),
                  total_search_rounds=sum(r['communication_rounds'] for r in candidates),
                  total_search_vector_payload_bytes=sum(r['vector_payload_bytes'] for r in candidates),
                  status='ok' if eligible else 'all_candidates_failed')
    if selected is not None:
        x, coefs = stored[selected]
        delta = x-theta
        path = candidates[selected]['path']
        attained = {str(target): next((a['round'] for a in path if a['l2'] <= target), None)
                    for target in [.1, .2, .5]}
        result.update(metric(x, theta), factor=candidates[selected]['factor'],
                      selected_candidate_seconds=candidates[selected]['seconds'],
                      selected_candidate_updates=candidates[selected]['total_updates'],
                      selected_candidate_stages=candidates[selected]['total_stages'],
                      selected_candidate_vector_payload_bytes=candidates[selected]['vector_payload_bytes'],
                      final_lambda=candidates[selected]['trace'][-1]['lambda_value'],
                      validation_mse=candidates[selected]['validation_mse'],
                      test_mse=float(np.mean((yt-xt@x)**2)),
                      population_prediction_excess=float(delta@covariance@delta),
                      coefficient=x.tolist(), outer_coefficients=[a.tolist() for a in coefs],
                      path=path, first_target_round=attained,
                      grid_edge=selected in [0, len(GRID)-1])
    return result


def audit_wrapper(cf, seed, dataset, factors=(.6,)):
    checks = []
    corrected, zero_filled, xv, yv, xt, yt, theta, direction, covariance, meta = dataset
    for name, agg, penalty, correction in METHODS:
        nodes = corrected if correction else zero_filled
        scale = np.std(nodes[0].y, ddof=1)/(cf['q'] if correction else 1.)
        for factor in factors:
            args = (nodes, scale, factor, agg, penalty, cf['b'], cf['f'], cf['attack'], seed)
            a, ia, _ = traced_fit(*args, direction, theta)
            b, ib = core.fit(*args, direction=direction)
            err = float(np.max(np.abs(a-b)))
            ok = err <= 1e-12 and ia['status'] == ib['status'] and ia['trace'] == ib['trace']
            assert ok, (name, factor, err, ia['status'], ib['status'])
            checks.append(dict(method=name, factor=factor, status=ia['status'],
                               max_endpoint_difference=err, passed=ok))
    return checks


def run(mode, repeats, resume=False):
    results = ROOT/'results'; results.mkdir(exist_ok=True)
    plan_path = results/f'competitive_{mode}_plan.json'
    output = results/f'competitive_{mode}.jsonl'
    if plan_path.exists():
        if not resume:
            raise FileExistsError(f'{plan_path}: use --resume to continue the fixed plan')
        plan = json.loads(plan_path.read_text(encoding='utf-8'))
        expected = make_plan(mode, repeats)
        for key in ('repeats', 'core_sha256', 'script_sha256', 'configurations',
                    'seeds', 'grid', 'methods', 'rounds', 'stage_iteration_cap',
                    'validation_n', 'test_n', 'selection', 'failures', 'scale',
                    'pairing', 'support_threshold', 'targets', 'timing', 'slard'):
            assert plan[key] == expected[key], f'Frozen protocol changed: {key}'
    else:
        plan = make_plan(mode, repeats)
        plan_path.write_text(json.dumps(plan, indent=2), encoding='utf-8')
    done = set()
    if output.exists():
        for line in output.read_text(encoding='utf-8').splitlines():
            row = json.loads(line); done.add((row['configuration']['label'], row['seed'], row['method']))
    start_all = time.perf_counter()
    with output.open('a', encoding='utf-8') as stream:
        for ci, cf in enumerate(plan['configurations']):
            configuration_start = time.perf_counter()
            for rep, seed in enumerate(plan['seeds']):
                missing = [met for met in METHODS if (cf['label'], seed, met[0]) not in done]
                if not missing:
                    continue
                started = time.perf_counter(); dataset = make_data(cf, seed)
                if mode == 'pilot' and ci == 0 and rep == 0:
                    audit = audit_wrapper(cf, seed, dataset)
                    (results/'competitive_core_equivalence.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
                order = np.random.default_rng(np.random.SeedSequence([seed, ci, 8173])).permutation(len(METHODS))
                for order_index, mi in enumerate(order):
                    method = METHODS[mi]
                    if (cf['label'], seed, method[0]) in done:
                        continue
                    record = fit_method(cf, seed, method, dataset)
                    row = dict(mode=mode, configuration=cf, rep=rep, seed=seed,
                               execution_order=order_index, dataset=dataset[-1], **record)
                    stream.write(json.dumps(clean(row), separators=(',', ':'))+'\n'); stream.flush()
                if mode == 'pilot':
                    print(json.dumps(dict(mode=mode, configuration=cf['label'], repeat=rep+1,
                                          seconds=round(time.perf_counter()-started, 2),
                                          elapsed_seconds=round(time.perf_counter()-start_all, 2))), flush=True)
            if mode == 'full':
                print(json.dumps(dict(mode=mode, configuration=cf['label'], repeats=plan['repeats'],
                                      seconds=round(time.perf_counter()-configuration_start, 2),
                                      elapsed_seconds=round(time.perf_counter()-start_all, 2))), flush=True)
    print('Finished', output, flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['pilot', 'full'], required=True)
    ap.add_argument('--repeats', type=int, required=True)
    ap.add_argument('--resume', action='store_true')
    args = ap.parse_args()
    with threadpool_limits(limits=1):
        run(args.mode, args.repeats, args.resume)
