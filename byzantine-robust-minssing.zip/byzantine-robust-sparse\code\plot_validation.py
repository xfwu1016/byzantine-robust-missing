"""Readable annotated benchmark matrices from the unchanged summary records."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

ROOT=Path(__file__).resolve().parents[1]

def draw():
 rows=json.loads((ROOT/'results/revision_summary.json').read_text())['revision_synthetic.json']
 configs=list(dict.fromkeys(x['config'] for x in rows))
 methods=list(dict.fromkeys(x['method'] for x in rows))
 labels=['Reference','High missing','High corr.','Stealth','Undertrim','Clean']
 errors=np.full((len(methods),len(configs)),np.nan)
 success=np.zeros_like(errors);exact=np.zeros_like(errors)
 for i,m in enumerate(methods):
  for j,c in enumerate(configs):
   r=next(x for x in rows if x['method']==m and x['config']==c)
   assert r['N']==30
   errors[i,j]=r['mean'] if r['mean'] is not None else np.nan
   success[i,j]=r['success'];exact[i,j]=round(30*r['exact'])
   assert abs(exact[i,j]-30*r['exact'])<1e-7
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42})
 fig,axs=plt.subplots(1,3,figsize=(7.2,3.55),sharey=True)
 fig.subplots_adjust(left=.155,right=.99,bottom=.33,top=.87,wspace=.14)
 for k,(ax,mat,title) in enumerate(zip(axs,[errors,success,exact],
  ['(a) Mean coefficient error','(b) Successful fits / 30','(c) Exact support / 30'])):
  cmap=plt.get_cmap('YlOrRd' if k==0 else 'Blues').copy();cmap.set_bad('#e5e5e5')
  norm=Normalize(0,2.4 if k==0 else 30)
  im=ax.imshow(mat,cmap=cmap,norm=norm,aspect='auto')
  ax.set_title(title,fontsize=8,pad=10)
  ax.set_xticks(range(6),labels,rotation=45,ha='right',rotation_mode='anchor',fontsize=7)
  ax.set_yticks(range(7),methods,fontsize=8)
  ax.tick_params(axis='both',length=0,pad=4)
  ax.set_xticks(np.arange(-.5,6,1),minor=True);ax.set_yticks(np.arange(-.5,7,1),minor=True)
  ax.grid(which='minor',color='white',linewidth=1);ax.tick_params(which='minor',length=0)
  for spine in ax.spines.values():spine.set_visible(False)
  for i in range(7):
   for j in range(6):
    val=mat[i,j];s='—' if np.isnan(val) else f'{val:.3f}' if k==0 else str(int(val))
    ax.text(j,i,s,ha='center',va='center',fontsize=6.7 if k==0 else 7,color='white' if np.isfinite(val) and norm(val)>.6 else '#151515')
 # Error colors show magnitude; the count panels use an identical scale.
 fig.text(.155,.035,'Error: lower is better. Counts: higher is better. Gray cells: no successful fit.',fontsize=7)
 fig.savefig(ROOT/'figures/validation_benchmark.pdf')
 fig.savefig(ROOT/'figures/validation_benchmark.png',dpi=240)
 plt.close(fig)

if __name__=='__main__':draw()
