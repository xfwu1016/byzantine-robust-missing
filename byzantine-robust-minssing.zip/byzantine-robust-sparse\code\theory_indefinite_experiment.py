"""Prespecified conditional-theorem checks on heterogeneous indefinite quadratics.

These are controlled quadratic instances, not sampled MCAR observations.
All envelope inputs are fixed analytically before seeds are run. Truth and honest
identities enter construction, attack generation and audits, not penalty tuning.
The original solver and all older experimental records remain unchanged.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse
import json
import math
from pathlib import Path
import time
import numpy as np
from robust_sparse import soft, penalty_weights, kkt, aggregate, attack, envelope_fit

ROOT = Path(__file__).resolve().parents[1]
PLAN = {
    'purpose': 'Conditional sparse-path and outer-recursion checks on globally indefinite heterogeneous quadratics',
    'sampled_mcar': False,
    'p': 4000, 's': 2, 'm': 10, 'rounds': 12,
    'rank_one_strength': 1.2, 'diagonal_halfwidth': .004,
    'common_score_bound': .0005, 'raw_centered_score_halfwidth': .001,
    'kappa': .98, 'M': 1.01, 'R0': math.sqrt(2)*1.2,
    'seeds': list(range(2026102100, 2026102120)),
    'pilot_seeds': [2026102198, 2026102199],
    'configurations': [
        {'name': 'clean_b0', 'b': 0, 'f': 0, 'attack': 'none'},
        {'name': 'clean_b1', 'b': 1, 'f': 0, 'attack': 'none'},
        {'name': 'clean_b2', 'b': 2, 'f': 0, 'attack': 'none'},
        {'name': 'gaussian_b1', 'b': 1, 'f': 1, 'attack': 'gaussian'},
        {'name': 'gaussian_b2', 'b': 2, 'f': 2, 'attack': 'gaussian'},
        {'name': 'adaptive_b1', 'b': 1, 'f': 1, 'attack': 'adaptive_range'},
        {'name': 'adaptive_b2', 'b': 2, 'f': 2, 'attack': 'adaptive_range'},
    ],
    'eta': 12/13, 'max_inner_updates': 10000,
    'precision': 'float64',
    'failure_rule': 'Record all seeds/configurations; no resampling or deletion after a failed check.',
    'curvature_proof': 'For |U|<=4K, lambda_min(Gamma_1,UU)>=1-delta-1.2|U|/p; lambda_max<=1+delta. Along v=1/sqrt(p), v^T Gamma_1 v=1+delta_1-1.2<0.',
    'score_proof': 'Honest scores r_j=mu+xi_j-average_H(xi), |mu_l|<=a_H and |xi_jl|<=tau/2. Their average is mu and max centered deviation is <=tau. Gamma_j-Gamma_H=(delta_j-delta_H)I gives d<=2 delta.',
    'adaptive_attack': 'At each iterate, coordinatewise choose the near-lower or near-upper honest-range report giving the larger absolute surrogate score at truth. Report is repeated at all Byzantine nodes; choice is recomputed each round.',
}


class RankOneNode:
    def __init__(self, delta, score, truth, strength):
        self.delta = float(delta)
        self.p = len(truth)
        self.strength = strength
        self.diag = np.full(self.p, 1+delta-strength/self.p)
        self.gamma = self.mv(truth)-score

    def mv(self, x):
        return (1+self.delta)*x-self.strength*np.mean(x)

    def grad(self, x):
        return self.mv(x)-self.gamma


def constants(cfg):
    p, s = PLAN['p'], PLAN['s']
    kap, upper = PLAN['kappa'], PLAN['M']
    K = 2*s+math.ceil((32/3)**2*(upper/kap-1)**2*s)
    omega = 3*cfg['b']/(PLAN['m']-2*cfg['b'])
    a = PLAN['common_score_bound']
    tau = 2*PLAN['raw_centered_score_halfwidth']
    d = 2*PLAN['diagonal_halfwidth']
    A, B = a+omega*tau, (1+omega)*d
    rho = 16*math.sqrt(s)*B/kap
    return dict(K=K, kappa=kap, M=upper, omega=omega, a_H=a, tau=tau,
                d=d, A=A, B=B, rho=rho,
                floor=16*math.sqrt(s)*A/(kap*(1-rho)),
                sparse_eigen_lower=1-PLAN['diagonal_halfwidth']-PLAN['rank_one_strength']*min(4*K,p)/p,
                sparse_eigen_upper=1+PLAN['diagonal_halfwidth'],
                global_negative_upper=1+PLAN['diagonal_halfwidth']-PLAN['rank_one_strength'])


def make_nodes(seed, f):
    rng = np.random.default_rng(seed)
    p, m = PLAN['p'], PLAN['m']
    truth = np.zeros(p);truth[:2] = [1.2,-1.2]
    deltas = rng.uniform(-PLAN['diagonal_halfwidth'], PLAN['diagonal_halfwidth'], m)
    mu = rng.uniform(-PLAN['common_score_bound'], PLAN['common_score_bound'], p)
    xi = rng.uniform(-PLAN['raw_centered_score_halfwidth'], PLAN['raw_centered_score_halfwidth'], (m,p))
    h = m-f
    score = mu+xi-xi[:h].mean(0)
    nodes = [RankOneNode(delta, r, truth, PLAN['rank_one_strength']) for delta,r in zip(deltas,score)]
    return nodes,truth,mu,deltas


def messages(nodes, x, truth, cfg, t, seed):
    raw = np.asarray([node.grad(x) for node in nodes])
    f,b = cfg['f'],cfg['b']
    if cfg['attack'] != 'adaptive_range':
        return raw,attack(raw,f,cfg['attack'],t,seed)
    honest = raw[:-f]
    lo,hi = honest.min(0),honest.max(0)
    candidates = [lo+.001*(hi-lo), hi-.001*(hi-lo)]
    values=[];reports=[]
    for candidate in candidates:
        sent=raw.copy();sent[-f:]=candidate
        values.append(aggregate(sent,'trim',b)+nodes[0].mv(truth-x))
        reports.append(candidate)
    high=np.abs(values[1])>np.abs(values[0])
    sent=raw.copy();sent[-f:]=np.where(high,reports[1],reports[0])
    return raw,sent


def fixed_point_on_support(node,c,w,x):
    ids=np.flatnonzero(x)
    out=np.zeros_like(x)
    if ids.size:
        rhs=c[ids]-w[ids]*np.sign(x[ids]);a=1+node.delta;v=node.strength/node.p
        out[ids]=rhs/a+v*rhs.sum()/(a*(a-v*ids.size))
    return out


def traced_stage(node,c,w,x,lam,final,co,truth):
    x=x.copy();M=co['M'];kap=co['kappa'];s=PLAN['s'];K=co['K']
    tol=min(1e-5,lam/1000) if final else lam/26
    tol=min(tol,lam/4*math.sqrt(s/(2*K)))
    paths=[x.copy()]
    status='max_iter'
    for i in range(PLAN['max_inner_updates']+1):
        gradient=node.mv(x)-c
        residual=kkt(gradient,x,w)
        if residual<=tol:
            status='ok';break
        if i==PLAN['max_inner_updates']:break
        x=soft(x-gradient/M,w/M)
        paths.append(x.copy())
        if not np.isfinite(x).all():status='nonfinite';break
    fixed=fixed_point_on_support(node,c,w,x)
    fixed_kkt=kkt(node.mv(fixed)-c,fixed,w)
    errors=np.array([np.linalg.norm(z-truth) for z in paths])
    distances=np.array([np.linalg.norm(z-fixed) for z in paths])
    supports=[int(np.count_nonzero(z)) for z in paths]
    contraction=1-kap/M
    contraction_violation=float(np.max(distances[1:]-contraction*distances[:-1],initial=-1.))
    path_radius=4*math.sqrt(s)*lam/kap
    checks=dict(support=max(supports)<=K,
                neighborhood=bool(np.all(errors<=path_radius+1e-10)),
                local_contraction=contraction_violation<=1e-10,
                exact_fixed_point=fixed_kkt<1e-10,
                fixed_point_neighborhood=bool(np.linalg.norm(fixed-truth)<=path_radius+1e-10),
                stopping=status=='ok',
                endpoint_accuracy=float(errors[-1])<2*math.sqrt(s)*lam/kap+1e-10)
    return x,dict(status=status,updates=len(paths)-1,kkt=residual,tolerance=tol,
        max_support=max(supports),path_radius=path_radius,max_inner_error=float(errors.max()),
        errors=errors.tolist(),supports=supports,distances_to_fixed_point=distances.tolist(),
        fixed_point_kkt=fixed_kkt,max_contraction_violation=contraction_violation,checks=checks)


def run_fit(seed,cfg,return_endpoint=False):
    co=constants(cfg);nodes,truth,mu,deltas=make_nodes(seed,cfg['f'])
    h=PLAN['m']-cfg['f'];x=np.zeros(PLAN['p']);R=PLAN['R0'];trace=[]
    observed_a=float(np.abs(mu).max())
    scores=np.array([node.grad(truth) for node in nodes[:h]])
    scoremean=scores.mean(0)
    observed_tau=float(np.abs(scores-scoremean).max())
    observed_d=float(np.abs(deltas[:h]-deltas[:h].mean()).max())
    checks=dict(sparse_curvature=co['sparse_eigen_lower']>=co['kappa'] and co['sparse_eigen_upper']<=co['M'],
        global_indefiniteness=co['global_negative_upper']<0,
        rho=co['rho']<1,score_constants=observed_a<=co['a_H']+1e-12 and observed_tau<=co['tau']+1e-12,
        curvature_mismatch=observed_d<=co['d']+1e-12,
        initial_radius=bool(np.linalg.norm(truth)<=R+1e-12))
    for t in range(PLAN['rounds']):
        u=x.copy();previous_error=float(np.linalg.norm(u-truth))
        raw,sent=messages(nodes,u,truth,cfg,t,seed)
        g=aggregate(sent,'trim',cfg['b']);c=nodes[0].mv(u)-g
        lam=8*(co['A']+co['B']*R)
        base=max(lam,R/(2.35*math.sqrt(PLAN['s'])),co['kappa']*R/(2*math.sqrt(PLAN['s'])))
        weights=penalty_weights(u,base,'scad')
        exceptional=np.flatnonzero((np.abs(u)>2.35*base)| (truth!=0))
        outside=np.ones(PLAN['p'],dtype=bool);outside[exceptional]=False
        weight_check=len(exceptional)<=2*PLAN['s'] and bool(np.all(weights[outside]>=base/2-1e-12))
        score=float(np.abs(nodes[0].mv(truth)-c).max())
        agg_error=float(np.abs(g-raw[:h].mean(0)).max())
        checks[f'round_{t+1}_score']=score<=co['A']+co['B']*previous_error+1e-10 and score<=lam/8+1e-10
        checks[f'round_{t+1}_weights']=weight_check
        stage_lambda=base;stages=[]
        while True:
            final=stage_lambda<=lam*(1+1e-12)
            x,stage=traced_stage(nodes[0],c,weights*(stage_lambda/base),x,stage_lambda,final,co,truth)
            stage['lambda']=stage_lambda;stages.append(stage)
            if final or stage['status']!='ok':break
            stage_lambda=max(lam,stage_lambda*PLAN['eta'])
        R=2*math.sqrt(PLAN['s'])*lam/co['kappa']
        error=float(np.linalg.norm(x-truth))
        closed=co['floor']+co['rho']**(t+1)*(PLAN['R0']-co['floor'])
        thresholded=np.flatnonzero(np.abs(x)>R)
        support_premise=1.2>2*R
        support_ok=bool(np.array_equal(thresholded,np.flatnonzero(truth)))
        round_checks=dict(inner=all(all(z['checks'].values()) for z in stages),
            outer_error=error<=R+1e-10,closed_recursion=abs(R-closed)<1e-10,
            threshold_support=(not support_premise) or support_ok)
        checks.update({f'round_{t+1}_{k}':v for k,v in round_checks.items()})
        trace.append(dict(round=t+1,error=error,radius=R,score=score,
            score_upper=co['A']+co['B']*previous_error,aggregation_error=agg_error,
            target=lam,base=base,raw_support=int(np.count_nonzero(x)),
            exact_raw_support=bool(np.array_equal(np.flatnonzero(x),np.flatnonzero(truth))),
            threshold_premise=support_premise,threshold_exact=support_ok,
            max_support=max(z['max_support'] for z in stages),
            stages=stages,checks=round_checks))
        if stages[-1]['status']!='ok':break
    record=dict(seed=seed,configuration=cfg['name'],config=cfg,constants=co,
        observed_a=observed_a,observed_tau=observed_tau,observed_d=observed_d,
        master_delta=float(deltas[0]),master_global_negative_direction=1+deltas[0]-PLAN['rank_one_strength'],
        initial_error=float(np.linalg.norm(truth)),trace=trace,checks=checks,
        passed=all(checks.values()) and len(trace)==PLAN['rounds'])
    return (record,x) if return_endpoint else record


def core_equivalence():
    records=[]
    for seed in PLAN['pilot_seeds']:
        for cfg in PLAN['configurations']:
            if cfg['attack']=='adaptive_range':continue
            traced,xt=run_fit(seed,cfg,return_endpoint=True)
            nodes,truth,_,_=make_nodes(seed,cfg['f']);co=constants(cfg)
            xc,info=envelope_fit(nodes,co['A'],co['B'],PLAN['R0'],co['kappa'],co['M'],PLAN['s'],
                rounds=PLAN['rounds'],b=cfg['b'],f=cfg['f'],attack_kind=cfg['attack'],seed=seed)
            difference=float(np.max(np.abs(xc-xt)))
            records.append(dict(seed=seed,configuration=cfg['name'],max_endpoint_difference=difference,
                                core_status=info['status'],passed=difference<1e-8 and info['status']=='ok'))
    return dict(checks=records,all_passed=all(r['passed'] for r in records))


def summary(records):
    rows=[]
    for cfg in PLAN['configurations']:
        rr=[r for r in records if r['configuration']==cfg['name']]
        if not rr:continue
        errors=[r['trace'][-1]['error'] for r in rr]
        rows.append(dict(configuration=cfg['name'],N=len(rr),passed=sum(r['passed'] for r in rr),
            constants=constants(cfg),error_mean=float(np.mean(errors)),
            error_se=float(np.std(errors,ddof=1)/np.sqrt(len(errors))) if len(errors)>1 else None,
            max_inner_support=max(t['max_support'] for r in rr for t in r['trace']),
            exact_raw_support=sum(r['trace'][-1]['exact_raw_support'] for r in rr),
            threshold_premise=sum(r['trace'][-1]['threshold_premise'] for r in rr),
            threshold_exact=sum(r['trace'][-1]['threshold_exact'] for r in rr),
            mean_aggregation_error=float(np.mean([t['aggregation_error'] for r in rr for t in r['trace']])),
            max_aggregation_error=max(t['aggregation_error'] for r in rr for t in r['trace']),
            total_updates=sum(st['updates'] for r in rr for t in r['trace'] for st in t['stages'])))
    return dict(rows=rows,all_checks_passed=all(r['passed'] for r in records),runs=len(records),
        total_inner_updates=sum(st['updates'] for r in records for t in r['trace'] for st in t['stages']))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args()
    resultdir=ROOT/'results';planpath=resultdir/'theory_indefinite_plan.json'
    if planpath.exists():
        assert json.loads(planpath.read_text())==PLAN,'Plan differs from saved prespecification.'
    else:planpath.write_text(json.dumps(PLAN,indent=2)+'\n',encoding='utf-8')
    seeds=PLAN['pilot_seeds'] if args.pilot else PLAN['seeds']
    stem='theory_indefinite_pilot' if args.pilot else 'theory_indefinite'
    records=[];start=time.time()
    equivalence=core_equivalence() if args.pilot else None
    if equivalence is not None:
        (resultdir/'theory_indefinite_core_equivalence.json').write_text(json.dumps(equivalence,indent=2)+'\n',encoding='utf-8')
    for seed in seeds:
        for cfg in PLAN['configurations']:
            record=run_fit(seed,cfg);records.append(record)
            print(seed,cfg['name'],'passed',record['passed'],'error',round(record['trace'][-1]['error'],6),flush=True)
        (resultdir/(stem+'.json')).write_text(json.dumps(dict(plan=PLAN,records=records,elapsed_seconds=time.time()-start),indent=2)+'\n',encoding='utf-8')
    out=summary(records)
    if equivalence is not None:out['core_solver_equivalence']=equivalence
    (resultdir/(stem+'_summary.json')).write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
