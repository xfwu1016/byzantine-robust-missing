"""Selection-safe envelope experiment and post-hoc MCAR certificate audit.

MCAR bounds use hidden honest labels and truth AFTER sampling: diagnostics only.
They are never advertised as deployable estimated bounds.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import Node,envelope_fit,fit
ROOT=Path(__file__).resolve().parents[1]
class Quadratic:
 def __init__(self,G,gamma,n,q):
  self.gram=G;self.gamma=gamma;self.p=len(gamma);self.n=n;self.q=q;self.diag=np.diag(G)
 def mv(self,x):return self.gram@x
 def grad(self,x):return self.mv(x)-self.gamma
def generate(rng,n,p,q,truth):
 G=np.zeros((p,p));gamma=np.zeros(p)
 for first in range(0,n,10000):
  size=min(10000,n-first);x=rng.normal(size=(size,p));y=x@truth+rng.normal(size=size)
  z=x*(rng.random(x.shape)<q);G+=z.T@z;gamma+=z.T@y
 A=G/n;G=(A-(1-q)*np.diag(np.diag(A)))/q**2
 return Quadratic(G,gamma/(n*q),n,q)
def run():
 records=[];start=time.time();p=12;m=10;s=1;b=f=1;omega=3*(b/m)/(1-2*b/m)
 for q in [.7,.9]:
  for n in [2000,20000,200000]:
   for rep in range(5):
    seed=20261009+rep+100*n+int(q*10);rng=np.random.default_rng(seed);truth=np.zeros(p);truth[0]=1.2
    nodes=[generate(rng,n,p,q,truth) for _ in range(m)];hon=nodes[:-f]
    eig=np.linalg.eigvalsh(nodes[0].gram);kappa=float(eig[0]);M=float(eig[-1]);K=2+int(np.ceil((32/3)**2*(M/kappa-1)**2)) if kappa>0 else p
    GH=np.mean([j.gram for j in hon],axis=0);scores=np.array([j.grad(truth) for j in hon]);scoreH=scores.mean(0)
    a=float(np.max(np.abs(scoreH)));tau=float(np.max(np.abs(scores-scoreH)))
    r=min(K+s,p);d=max(float(np.sqrt(np.sort((j.gram-GH)**2,axis=1)[:,-r:].sum(1)).max()) for j in hon)
    A=max(a+omega*tau,1e-15);B=(1+omega)*d;rho=16*B/kappa if kappa>0 else float('inf')
    xv=rng.normal(size=(1000,p));yv=xv@truth+rng.normal(size=1000);opts=[]
    for inflation in [1.,1.25,1.5,2.]:
     if inflation*rho>=1:continue
     x,info=envelope_fit(nodes,A,B,1.5,kappa,M,s,rounds=8,b=b,f=f,attack_kind='gaussian',seed=seed,inflation=inflation)
     assert info['status']=='ok'
     assert np.linalg.norm(x-truth)<=info['trace'][-1]['radius']+1e-9
     assert all(z['max_support']<=info['K'] for z in info['trace'])
     opts.append(dict(inflation=inflation,val=float(np.mean((yv-xv@x)**2)),l2=float(np.linalg.norm(x-truth)),radius=info['trace'][-1]['radius'],max_support=max(z['max_support'] for z in info['trace']),trace=info['trace']))
    practical=[]
    for factor in [.3,.6,1.2,2.4]:
     x,info=fit(nodes,np.sqrt(1+1.2**2)/q,factor,'trim','scad',b,f,'gaussian',seed)
     practical.append(dict(factor=factor,status=info['status'],val=float(np.mean((yv-xv@x)**2)) if info['status']=='ok' else None,l2=float(np.linalg.norm(x-truth))))
    selected=min(opts,key=lambda z:z['val']) if opts else None
    good=[z for z in practical if z['status']=='ok'];pr=min(good,key=lambda z:z['val']) if good else None
    records.append(dict(q=q,n=n,p=p,m=m,rep=rep,seed=seed,kappa=kappa,M=M,K=K,A=A,B=B,rho=rho,certified_candidates=opts,selected=selected,practical=pr,practical_candidates=practical,bounds_use_truth_and_honest_labels=True))
   print('MCAR audit',q,n,'elapsed',round(time.time()-start),flush=True)
   (ROOT/'results'/'bridge_audit.json').write_text(json.dumps(dict(records=records,notes='Post-hoc truth/honest-label diagnostics; no claim of deployable MCAR certification.'),indent=2))
if __name__=='__main__':
 with threadpool_limits(limits=1):run()
