"""Audit and summarize the paired no-attack trimming-budget experiment."""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
raw = json.loads((RESULTS / 'no_attack_budget.json').read_text(encoding='utf-8'))
records = raw['records']
assert raw['penalty_budget'] == 0
assert raw['budgets'] == [0, 2, 4]
by_budget = {b: sorted((r for r in records if r['b'] == b), key=lambda r: r['rep']) for b in raw['budgets']}
assert all(len(rows) == 30 for rows in by_budget.values())
assert all([r['rep'] for r in rows] == list(range(30)) for rows in by_budget.values())
assert all(r['m_byzantine'] == 0 for r in records)
assert all(by_budget[b][i]['seed'] == by_budget[0][i]['seed'] for b in (2, 4) for i in range(30))
reference = json.loads((RESULTS / 'revision_synthetic.json').read_text(encoding='utf-8'))['records']
reference = {r['rep']: r for r in reference if r['config'] == 'clean' and r['method'] == 'Trim-SCAD'}
assert len(reference) == 30
assert all(np.isclose(by_budget[0][i]['l2'], reference[i]['l2'])
           and by_budget[0][i]['exact'] == reference[i]['exact'] for i in range(30))

summary = {'design': {k: raw[k] for k in ('budgets', 'm', 'n', 'p', 'q', 'rho', 'validation_n', 'test_n', 'penalty_budget')},
           'reproduces_clean_reference': True, 'by_budget': {}, 'paired': {}, 'fixed_factor_1_2': {}}
for b, rows in by_budget.items():
    good = [r for r in rows if r['successful']]
    l2 = np.array([r['l2'] for r in good])
    test = np.array([r['test_mse'] for r in good])
    summary['by_budget'][str(b)] = dict(
        successes=len(good), total=len(rows), exact_support=sum(r['exact'] for r in rows),
        l2_mean=float(l2.mean()), l2_se=float(l2.std(ddof=1) / np.sqrt(len(l2))),
        test_mse_mean=float(test.mean()),
        score_inf_mean=float(np.mean([r['score_inf'] for r in rows])),
        score_shift_inf_mean=float(np.mean([r['score_shift_inf'] for r in rows])),
    )
for b in (2, 4):
    paired = [(by_budget[b][i]['l2'] - by_budget[0][i]['l2'])
              for i in range(30) if by_budget[b][i]['successful'] and by_budget[0][i]['successful']]
    delta = np.array(paired)
    summary['paired'][str(b)] = dict(
        n=len(paired), mean=float(delta.mean()), se=float(delta.std(ddof=1) / np.sqrt(len(delta))),
        positive=int(np.sum(delta > 0)), median=float(np.median(delta)),
    )

fixed = {b: [next(c for c in row['candidates'] if c['factor'] == 1.2)
             for row in rows] for b, rows in by_budget.items()}
for b, candidates in fixed.items():
    successful = [c for c in candidates if c['status'] == 'ok']
    summary['fixed_factor_1_2'][str(b)] = dict(
        successes=len(successful), l2_mean=float(np.mean([c['l2'] for c in successful])),
        exact_support=sum(c['exact'] for c in candidates),
    )
for b in (2, 4):
    delta = np.array([fixed[b][i]['l2'] - fixed[0][i]['l2'] for i in range(30)
                      if fixed[b][i]['status'] == fixed[0][i]['status'] == 'ok'])
    summary['fixed_factor_1_2'][str(b)]['paired_mean'] = float(delta.mean())
    summary['fixed_factor_1_2'][str(b)]['paired_se'] = float(delta.std(ddof=1) / np.sqrt(len(delta)))
summary['same_selected_factor_all_budgets'] = sum(
    len({by_budget[b][i]['selected_factor'] for b in raw['budgets']}) == 1 for i in range(30))

(RESULTS / 'no_attack_budget_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
