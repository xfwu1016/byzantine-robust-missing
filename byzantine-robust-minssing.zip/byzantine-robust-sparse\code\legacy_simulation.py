"""Reproducible exploratory Byzantine ADANPH experiment; see research_draft.md.

No true coefficients/support are passed to the fitting routine. Oracle quantities
are used only by the attack simulator and the evaluation routines.
The indefinite corrected Gram matrix is never projected to the PSD cone.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import argparse
import json
import time
from pathlib import Path
import numpy as np
from scipy.linalg import eigvalsh
from threadpoolctl import threadpool_limits

METHODS = [('Mean-SCAD','mean','scad'), ('Mean-MCP','mean','mcp'),
           ('Trim-Lasso','trim','lasso'), ('Trim-SCAD','trim','scad'),
           ('Trim-MCP','trim','mcp')]

def corrected_stats(z, y, retention):
    a = z.T @ z / len(y)
    gram = (a - (1-retention)*np.diag(np.diag(a))) / retention**2
    gamma = z.T @ y / (len(y)*retention)
    return gram, gamma

def generate(seed, m, n, p, missing, signal=1.2, rho=0.3):
    rng = np.random.default_rng(seed)
    truth = np.zeros(p)
    support = np.array([0, p//4, p//2, 3*p//4])
    truth[support] = signal*np.array([1., -1., 1., -1.])
    grams, gammas, ys = [], [], []
    for _ in range(m):
        x = rng.normal(size=(n,p))
        for k in range(1,p):
            x[:,k] = rho*x[:,k-1] + np.sqrt(1-rho*rho)*x[:,k]
        y = x@truth + rng.normal(size=n)
        z = x * (rng.random((n,p)) >= missing)
        g, c = corrected_stats(z, y, 1-missing)
        grams.append(g); gammas.append(c); ys.append(y)
    sigma = rho**np.abs(np.arange(p)[:,None]-np.arange(p)[None,:])
    return np.array(grams), np.array(gammas), np.std(ys[0], ddof=1), truth, sigma

def kkt(grad, x, w):
    residual = np.maximum(np.abs(grad)-w, 0.)
    active = x != 0
    residual[active] = np.abs(grad[active] + w[active]*np.sign(x[active]))
    return float(np.max(residual))

def soft(x, w):
    return np.sign(x)*np.maximum(np.abs(x)-w,0.)

def weights(x, lam, penalty):
    z = np.abs(x)
    if penalty == 'lasso': return np.full(len(x),lam)
    if penalty == 'scad':
        return np.where(z<=lam, lam, np.maximum(3.7*lam-z,0.)/2.7)
    if penalty == 'mcp': return np.maximum(lam-z/3.,0.)
    raise ValueError(penalty)

def solve_stage(gram, c, w, x, tol, max_iter=600):
    x = x.copy()
    lip = max(float(np.max(np.diag(gram))), .1)
    grad = gram@x-c
    max_support = int(np.count_nonzero(x))
    for q in range(max_iter+1):
        residual = kkt(grad,x,w)
        if residual <= tol:
            return x, dict(status='ok', iterations=q, kkt=residual, max_support=max_support)
        if q == max_iter: break
        for _ in range(50):
            trial = soft(x-grad/lip, w/lip)
            delta = trial-x
            gd = gram@delta
            # Exact quadratic majorization test; valid also for indefinite Gram.
            if float(delta@gd) <= lip*float(delta@delta) + 1e-12:
                break
            lip *= 2
        else:
            return x, dict(status='line_search_failed',iterations=q,kkt=residual,max_support=max_support)
        x = trial
        grad += gd
        max_support = max(max_support, int(np.count_nonzero(x)))
        if not np.all(np.isfinite(x)) or np.linalg.norm(x)>1e4:
            return x, dict(status='diverged',iterations=q+1,kkt=float('inf'),max_support=max_support)
        lip = max(lip/1.05,.1)
    return x, dict(status='max_iter',iterations=max_iter,kkt=residual,max_support=max_support)

def homotopy(gram,c,x,base_w,base_lam,target_lam,eta=12/13):
    scale=1.; iters=0; max_support=int(np.count_nonzero(x)); stages=0
    while True:
        current = scale*base_lam
        final = current <= target_lam*(1+1e-12)
        tol = min(1e-5, target_lam/1000) if final else current/26
        x, info = solve_stage(gram,c,scale*base_w,x,tol)
        iters+=info['iterations']; stages+=1; max_support=max(max_support,info['max_support'])
        if info['status']!='ok' or final:
            info.update(iterations=iters,stages=stages,max_support=max_support)
            return x,info
        scale=max(scale*eta,target_lam/base_lam)

def make_initial(gram,gamma,scale,n,p,lambda_factor):
    local_lam=lambda_factor*scale*np.sqrt(np.log(p)/n)
    initial_lam=max(float(np.max(np.abs(gamma))),local_lam)
    x,info=homotopy(gram,gamma,np.zeros(p),np.full(p,initial_lam),initial_lam,local_lam)
    return x,local_lam,info

def attack_messages(messages, honest, bad, kind, round_id, seed, direction):
    if not len(bad): return messages
    out=messages.copy(); good=messages[honest]
    if kind=='gaussian':
        rng=np.random.default_rng(np.random.SeedSequence([seed,round_id,761]))
        out[bad]=rng.normal(0,20.,size=(len(bad),messages.shape[1]))
    elif kind=='signflip':
        out[bad]=-20*np.mean(good,axis=0)
    elif kind=='stealth':
        # Omniscient adaptive attack: target true and false coordinates, stay
        # inside coordinate-wise honest range using 30%/70% quantiles.
        lo,hi=np.quantile(good,[.3,.7],axis=0)
        center=np.median(good,axis=0)
        crafted=np.where(direction>0,hi,np.where(direction<0,lo,center))
        out[bad]=crafted
    elif kind!='none': raise ValueError(kind)
    return out

def fit(grams,gammas,initial,local_lam,scale,n,rounds,aggregation,penalty,
        bad,trim_b,attack,seed,direction,lambda_factor):
    m,p=gammas.shape
    honest=np.array([j for j in range(m) if j not in set(bad)])
    beta=trim_b/m
    # Same target lambda for Mean and Trim: isolates aggregation changes.
    target=lambda_factor*scale*(np.sqrt(np.log(p)/(m*n))+beta*np.sqrt(np.log(p)/n))
    x=initial.copy(); path=[x.copy()]; rounds_meta=[]
    for t in range(rounds):
        raw=np.einsum('mij,j->mi',grams,x,optimize=False)-gammas
        sent=attack_messages(raw,honest,bad,attack,t,seed,direction)
        if aggregation=='mean' or trim_b==0: agg=np.mean(sent,axis=0)
        else: agg=np.mean(np.sort(sent,axis=0)[trim_b:m-trim_b],axis=0)
        # The linear coefficient in L1(theta) - <grad L1(x)-agg,theta>.
        c=grams[0]@x-agg
        # Early rounds must cover the local-Hessian mismatch, not just the final
        # statistical floor. This deterministic schedule is experimental tuning,
        # not a claim that the theoretical unknown error envelope is estimated.
        round_target=max(target,local_lam*(.65**(t+1)))
        base=max(round_target,local_lam*(.65**t))
        w=weights(x,base,penalty)
        x,info=homotopy(grams[0],c,x,w,base,round_target)
        info.update(base_lambda=float(base),target_lambda=float(round_target))
        rounds_meta.append(info); path.append(x.copy())
        if info['status']!='ok': break
    return x,path,rounds_meta,target

def metrics(x,truth,sigma):
    err=x-truth; selected=np.abs(x)>1e-6; support=truth!=0
    return dict(l2=float(np.linalg.norm(err)), prediction=float(err@sigma@err),
                fp=int(np.sum(selected&~support)),fn=int(np.sum(~selected&support)),
                exact_support=bool(np.array_equal(selected,support)))

def checks():
    rng=np.random.default_rng(42); z=rng.normal(size=(40,12)); y=rng.normal(size=40)
    g,c=corrected_stats(z,y,1.)
    assert np.allclose(g,z.T@z/40) and np.allclose(c,z.T@y/40)
    x=rng.normal(size=12); v=rng.normal(size=12); h=1e-6
    loss=lambda a:.5*a@g@a-c@a
    assert np.isclose((loss(x+h*v)-loss(x-h*v))/(2*h),v@(g@x-c),rtol=1e-6,atol=1e-6)
    c=rng.normal(size=12); w=np.full(12,.3)
    sol,info=solve_stage(np.eye(12),c,w,np.zeros(12),1e-9)
    assert info['status']=='ok' and np.allclose(sol,soft(c,w),atol=1e-8)
    for _ in range(100):
        good=rng.normal(size=18); bad=rng.normal(0,50,size=2); allx=np.r_[good,bad]
        trimmed=np.sort(allx)[2:-2].mean()
        bound=6/16*np.max(np.abs(good-good.mean()))
        assert abs(trimmed-good.mean()) <= bound+1e-12
    # Correction unbiasedness: enumerate every mask for a fixed 3-vector.
    import itertools
    x=np.array([1.,-2.,.7]); r=.7; acc=np.zeros((3,3))
    for mask in itertools.product([0,1],repeat=3):
        mask=np.array(mask); prob=r**sum(mask)*(1-r)**(3-sum(mask))
        a=np.outer(mask*x,mask*x)
        acc+=prob*(a-(1-r)*np.diag(np.diag(a)))/r**2
    assert np.allclose(acc,np.outer(x,x))
    return ['complete-data correction','gradient finite difference','orthogonal soft threshold',
            'trimmed-mean deterministic bound','missingness unbiasedness by mask enumeration']

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repeats',type=int,default=30)
    ap.add_argument('--n',type=int,default=120); ap.add_argument('--p',type=int,default=240)
    ap.add_argument('--m',type=int,default=20); ap.add_argument('--rounds',type=int,default=8)
    ap.add_argument('--lambda-factor',type=float,default=.8)
    ap.add_argument('--seed-base',type=int,default=20262008)
    ap.add_argument('--signal',type=float,default=1.2)
    ap.add_argument('--retention-power',type=float,default=0.,
                    help='Scale tuning by (1-missing)^(-power); 0 is baseline, 2 is conservative missingness-aware tuning.')
    ap.add_argument('--output',default=str(Path(__file__).parent/'results.json'))
    ap.add_argument('--smoke',action='store_true')
    args=ap.parse_args(); start=time.time(); verified=checks()
    scenarios=[('none',0.,0.),('gaussian',.1,.1),('signflip',.1,.1),
               ('stealth',.1,.1),('stealth',.2,.2),('none',0.,.2)]
    missing_values=[.1,.3]
    if args.smoke: scenarios=scenarios[:4]; missing_values=[.1]
    records=[]; datasets=[]
    with threadpool_limits(limits=1):
      for missing in missing_values:
       for rep in range(args.repeats):
        seed=args.seed_base+rep
        grams,gammas,scale,truth,sigma=generate(seed,args.m,args.n,args.p,missing,args.signal)
        scale=scale/(1-missing)**args.retention_power
        initial,local_lam,init_info=make_initial(grams[0],gammas[0],scale,args.n,args.p,args.lambda_factor)
        sidx=np.flatnonzero(truth)
        datasets.append(dict(missing=missing,rep=rep,seed=seed,initial=metrics(initial,truth,sigma),
                             initial_status=init_info,local_lambda=float(local_lam),
                             master_min_eigen=float(eigvalsh(grams[0],subset_by_index=[0,0])[0]),
                             master_support_min_eigen=float(eigvalsh(grams[0][np.ix_(sidx,sidx)])[0])))
        for attack,alpha,beta in scenarios:
         f=int(round(alpha*args.m)); b=int(round(beta*args.m))
         bad=np.arange(args.m-f,args.m) if f else np.array([],dtype=int)
         honest=np.arange(args.m-f)
         direction=np.sign(truth)
         false_idx=np.array([min(i+3,args.p-1) for i in sidx]); direction[false_idx]=-1
         gh=grams[honest].mean(axis=0); ch=gammas[honest].mean(axis=0)
         oracle=np.zeros(args.p)
         oracle[sidx]=np.linalg.solve(gh[np.ix_(sidx,sidx)],ch[sidx])
         case=dict(missing=missing,rep=rep,seed=seed,attack=attack,alpha=alpha,beta=beta)
         records.append(dict(**case,method='Honest-Oracle',status='ok',rounds=0,
                             **metrics(oracle,truth,sigma),trajectory=[],optimization=[]))
         for name,agg,penalty in METHODS:
          if init_info['status']!='ok':
              records.append(dict(**case,method=name,status='initial_failed',rounds=0,
                                  l2=None,prediction=None,fp=None,fn=None,exact_support=False,
                                  trajectory=[],optimization=[])); continue
          x,path,meta,target=fit(grams,gammas,initial,local_lam,scale,args.n,args.rounds,agg,penalty,
                                bad,b,attack,seed,direction,args.lambda_factor)
          status=meta[-1]['status']; met=metrics(x,truth,sigma)
          records.append(dict(**case,method=name,status=status,rounds=len(meta),**met,
                              target_lambda=float(target),
                              honest_oracle_distance=float(np.linalg.norm(x-oracle)),
                              coefficients=x.tolist(),
                              trajectory=[metrics(z,truth,sigma)['l2'] for z in path],optimization=meta))
        print(json.dumps(dict(missing=missing,rep=rep+1,repeats=args.repeats,
                              elapsed_s=round(time.time()-start,1))),flush=True)
    payload=dict(config=vars(args),checks=verified,datasets=datasets,records=records,
                 elapsed_s=time.time()-start,
                 note='Exploratory implementation, not exact reproduction. Same initial estimator and lambda across matched methods. Failed fits retained.')
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    # Infinite KKT values from divergent runs are serialized as null, not JSON NaN.
    def clean(obj):
        if isinstance(obj,dict): return {k:clean(v) for k,v in obj.items()}
        if isinstance(obj,list): return [clean(v) for v in obj]
        if isinstance(obj,float) and not np.isfinite(obj): return None
        return obj
    Path(args.output).write_text(json.dumps(clean(payload),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Saved '+str(args.output),flush=True)

if __name__=='__main__': main()
