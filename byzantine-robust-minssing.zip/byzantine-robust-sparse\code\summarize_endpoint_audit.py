"""Write the complete post-fit diagnostic table from saved audit records."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def main():
    summary=json.loads((ROOT/'results/competitive_endpoint_summary.json').read_text())
    lookup={(r['study'],r['configuration'],r['method']):r for r in summary['summary']}
    rows=[]
    for study,prefix in [('competitive_full','C'),('competitive_sample_size','F')]:
        plan=json.loads((ROOT/'results'/f'{study}_plan.json').read_text())
        for i,cfg in enumerate(plan['configurations'],1):
            for method in ['Trim-SCAD','Trim-MCP']:
                r=lookup[study,cfg['label'],method]
                lo,hi=r['alpha_range']
                rows.append(f"{prefix}{i:02d} & {method[5:]} & {r['min_kappa']:.3f} & {r['positive_paths']} & {r['contractive_paths']} & {lo:.2f}--{hi:.2f} & {r['max_zeta']:.2f} & {r['max_support']}"+r' \\')
    source=r'''\subsection{Selected-Path Diagnostics}\label{sec:competitive_endpoints}
We evaluate the endpoint recursion in main-text Theorem~\ref{main-thm:endpoint} for every validation-selected Trim-SCAD and Trim-MCP path in the two studies. The audit covers 1740 paths and 13920 returned endpoints, comprising 1380 fixed-sample paths and 360 sample-size follow-up paths. These paths share 360 distinct datasets. Saved seeds reconstruct the moments and messages, and data hashes verify the reconstruction. The selected coefficients, tuning choices and fitted paths are unchanged. The true coefficient and honest-node identities are used only to evaluate the theorem's quantities after fitting.

At each round, we form $U_t=\cS\cup\supp(x_t)$ using all nonzero coefficients, without the $10^{-6}$ threshold used for support-recovery reporting. We evaluate $\kappa_t$, $\alpha_t$, $\zeta_t$ and the full KKT residual with the frozen weights and the surrogate formed at $x_{t-1}$. Recomputed residuals agree with the saved values to within $1.6\times10^{-15}$. All returned fits satisfy the prescribed residual tolerance, which is at most $10^{-5}$. At every endpoint with $\kappa_t>0$, the observed error satisfies the one-step inequality. A geometric recursion additionally requires $\alpha_t$ uniformly below one and a common bound on $\zeta_t$; positive endpoint curvature alone does not give that conclusion or control the intermediate iterates.

In the fixed-sample study, 1329 of 1380 paths have positive curvature at every endpoint, and 97 have $\alpha_t<1$ in all eight rounds. These 97 paths occur in the no-attack and structural-control settings. All 360 follow-up paths have positive endpoint curvature, but none has $\alpha_t<1$ throughout. Table~\ref{tab:competitive-endpoints} reports all configurations, including negative-curvature endpoints. The roundwise quantities and error bounds are saved in \texttt{results/competitive\_endpoint\_audit.jsonl}.

At the main reference ($q=0.7$, $m_{\rm B}=b=2$), all 120 method--attack paths have positive endpoint curvature. Across their endpoints, $\kappa_t\ge0.168$ and $2.25\le\alpha_t\le14.09$, so this sufficient condition does not certify geometric contraction. The 30 shared master samples also fail the uniform sparse-curvature condition: if $r_D=\max_l\Gamma_{1,ll}/\min_l\Gamma_{1,ll}$, any admissible curvature bounds must satisfy $M/\kappa\ge r_D$. Hence
\[
 K\ge 2s+\left\lceil(32/3)^2(r_D-1)^2s\right\rceil.
\]
This lower bound ranges from 178 to 422, making $4K\ge p=256$, whereas the full master matrices have minimum eigenvalues between $-0.356$ and $-0.329$. The uniform condition would require those matrices to be positive definite. The reference comparison therefore measures empirical performance outside the certified geometric regime; the separate conditional-theory experiments examine contraction where its sufficient conditions hold.

\par\begingroup\renewcommand{\baselinestretch}{1.2}\small\selectfont
\setlength{\tabcolsep}{3pt}\renewcommand{\arraystretch}{1.05}
\begin{longtable}{llrrrlrr}
\caption{Selected-path diagnostics. Configuration IDs refer to the preceding design tables. Pos. counts paths with $\kappa_t>0$ in all eight rounds; Contr. counts paths also having $\alpha_t<1$ throughout. Both counts are out of 30. Extrema are over all endpoints; $\alpha_t$ and $\zeta_t$ are evaluated only when $\kappa_t>0$. $S_{\max}$ is the largest recorded inner support along a selected path, including initialization.}\label{tab:competitive-endpoints}\\
\toprule ID & Penalty & $\min\kappa_t$ & Pos. & Contr. & $\alpha_t$ range & $\max\zeta_t$ & $S_{\max}$\\\midrule\endfirsthead
\toprule ID & Penalty & $\min\kappa_t$ & Pos. & Contr. & $\alpha_t$ range & $\max\zeta_t$ & $S_{\max}$\\\midrule\endhead
\bottomrule\endlastfoot
'''
    source+='\n'.join(rows)+'\n'+r'\end{longtable}\endgroup'+'\n'
    (ROOT/'results/competitive_endpoint_diagnostics.tex').write_text(source,encoding='utf-8')
    print(f'Wrote {len(rows)} diagnostic rows, covering every selected SCAD/MCP path.')

if __name__=='__main__':main()
