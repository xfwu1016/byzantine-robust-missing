"""Actual single-host process transport and complete surrogate solves.
No network latency emulation; no multi-machine speedup claim.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import time,json,platform,multiprocessing as mp,threading
import ctypes
from ctypes import wintypes
class MemoryCounters(ctypes.Structure):
 _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(name,ctypes.c_size_t) for name in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage']]
kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(MemoryCounters),wintypes.DWORD]
def rss(pid):
 handle=kernel.OpenProcess(0x0400|0x0010,False,pid)
 if not handle:return 0
 try:
  counters=MemoryCounters();counters.cb=ctypes.sizeof(counters)
  if not psapi.GetProcessMemoryInfo(handle,ctypes.byref(counters),counters.cb):return 0
  return counters.WorkingSetSize
 finally:kernel.CloseHandle(handle)

from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import Node,initial,aggregate,attack,homotopy,penalty_weights
ROOT=Path(__file__).resolve().parents[1]
def make(n,p,seed,q=.7):
 rng=np.random.default_rng(seed);truth=np.zeros(p);truth[:4]=[1.2,-1.2,1.2,-1.2]
 x=rng.normal(size=(n,p));y=x@truth+rng.normal(size=n);x*=rng.random(x.shape)<q
 return Node(x,y,q),truth
def worker(conn,n,p,seed,q):
 with threadpool_limits(limits=1):
  node,_=make(n,p,seed,q);conn.send_bytes(b'ready')
  while True:
   buf=conn.recv_bytes()
   if not buf:break
   conn.send_bytes(node.grad(np.frombuffer(buf,dtype=np.float64)).tobytes())
 conn.close()
def run(m,n,p,rep,q=.7):
 ctx=mp.get_context('spawn');conns=[];procs=[];t0=time.perf_counter();seed=20261109+rep*100
 master,truth=make(n,p,seed,q)
 for j in range(1,m):
  a,c=ctx.Pipe();proc=ctx.Process(target=worker,args=(c,n,p,seed+j,q));proc.start();c.close();conns.append(a);procs.append(proc)
 for c in conns:assert c.recv_bytes()==b'ready'
 setup=time.perf_counter()-t0;records=[];b=f=max(1,m//4)
 try:
  methods=[('trim','scad'),('trim','lasso'),('vrmom','scad')]
  np.random.default_rng(seed+991).shuffle(methods)
  for agg,pen in methods:
   stop_monitor=threading.Event();rss_samples=[]
   def monitor():
    while not stop_monitor.is_set():
     rss_samples.append(sum(rss(pid) for pid in [os.getpid()]+[proc.pid for proc in procs]))
     stop_monitor.wait(.02)
   sampler=threading.Thread(target=monitor,daemon=True);sampler.start()
   start=time.perf_counter();scale=np.std(master.y,ddof=1)/q;factor=.6
   x,local,ini=initial(master,scale,factor);initsecs=time.perf_counter()-start;initial_l2=float(np.linalg.norm(x-truth));trace=[];totalbytes=0
   floor=factor*scale*(np.sqrt(np.log(p)/(m*n))+(b/m)*np.sqrt(np.log(p)/n))
   if ini['status']=='ok':
    for t in range(8):
     tick=time.perf_counter();buf=x.tobytes()
     for c in conns:c.send_bytes(buf)
     localg=master.grad(x);received=[c.recv_bytes() for c in conns]
     messages=np.vstack([localg]+[np.frombuffer(z,dtype=np.float64) for z in received]);commgrad=time.perf_counter()-tick
     totalbytes+=len(buf)*(m-1)+sum(map(len,received));tick=time.perf_counter()
     sent=attack(messages,f,'gaussian',t,seed)
     g=aggregate(sent,agg,b,master.score_sd(x) if agg=='vrmom' else None,n);aggsecs=time.perf_counter()-tick
     cvec=master.mv(x)-g;target=max(floor,local*.65**(t+1));base=max(target,local*.65**t);tick=time.perf_counter()
     x,info=homotopy(master,cvec,x,penalty_weights(x,base,pen),base,target)
     trace.append(dict(round=t+1,status=info['status'],l2=float(np.linalg.norm(x-truth)),seconds=time.perf_counter()-start,payload_bytes=totalbytes,communication_gradient_seconds=commgrad,aggregation_seconds=aggsecs,inner_seconds=time.perf_counter()-tick,inner_iterations=info['iterations']))
     if info['status']!='ok':break
   elapsed=time.perf_counter()-start;stop_monitor.set();sampler.join()
   records.append(dict(q=q,sampled_peak_rss_bytes=max(rss_samples) if rss_samples else None,initial_l2=initial_l2,m=m,n=n,p=p,rep=rep,seed=seed,method=agg+'-'+pen,setup_seconds=setup,initial_seconds=initsecs,initial_status=ini['status'],status=trace[-1]['status'] if trace else ini['status'],seconds=elapsed,l2=float(np.linalg.norm(x-truth)),payload_bytes=totalbytes,trace=trace,design_array_bytes=m*n*p*8,avoided_dense_gram_bytes=m*p*p*8))
 finally:
  for c in conns:c.send_bytes(b'');c.close()
  for proc in procs:proc.join(timeout=30);assert proc.exitcode==0
 return records
if __name__=='__main__':
 allrecords=[]
 with threadpool_limits(limits=1):
  for q in [.5,.7,.9]:
   for p in [1000,4000,10000]:
    for rep in range(10):
     allrecords+=run(8,1024,p,rep,q)
     print('matched-target benchmark',q,p,rep,flush=True)
     (ROOT/'results'/'matched_cost_runs.json').write_text(json.dumps(dict(records=allrecords,single_host=True,platform=platform.platform(),logical_cpus=os.cpu_count(),targets=[.1,.2],notes='Ten seeds; fixed factor .6, 25% Gaussian attacks, eight rounds, randomized method order. 20ms aggregate RSS sampling includes coordinator and worker processes; sampling overhead included in timing. Targets use simulation truth for retrospective evaluation only.'),indent=2))
