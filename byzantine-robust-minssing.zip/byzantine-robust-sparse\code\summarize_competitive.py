"""Validate and summarize the complete, paired competitiveness benchmark.

Final output requires every planned configuration/seed/method.  --partial
writes an explicitly incomplete JSON preview under work/revision28 only;
it never writes tables or figures into the submission package.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics as stats

ROOT = Path(__file__).resolve().parents[1]
DISPLAY = {'NoCorrection-SCAD': 'Uncorrected SCAD'}
PLOT_METHODS = ['Trim-SCAD', 'Trim-MCP', 'Trim-Lasso', 'VRMOM-SCAD',
                'NoCorrection-SCAD', 'T-SLARD-ZF']
PAIRED_COMPARATORS = ['Trim-Lasso', 'VRMOM-SCAD', 'Median-SCAD',
                      'NoCorrection-SCAD', 'M-SLARD-ZF', 'T-SLARD-ZF']


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def moments(values):
    values = [float(v) for v in values]
    if not values:
        return {'n': 0, 'mean': None, 'se': None, 'median': None,
                'minimum': None, 'maximum': None}
    assert all(math.isfinite(v) for v in values)
    return {'n': len(values), 'mean': stats.mean(values),
            'se': stats.stdev(values)/math.sqrt(len(values)) if len(values)>1 else None,
            'median': stats.median(values), 'minimum': min(values), 'maximum': max(values)}


def read_records(plan, path, partial=False, study='main'):
    cfgs = {c['label']: c for c in plan['configurations']}
    methods = [m['name'] for m in plan['methods']]
    expected = {(c, s, m) for c in cfgs for s in plan['seeds'] for m in methods}
    records = {}
    data_hashes = defaultdict(set)
    line_count = 0
    with path.open(encoding='utf-8') as f:
        for line_count, line in enumerate(f, 1):
            if not line.strip():
                raise AssertionError(f'Blank record at line {line_count}')
            r = json.loads(line)
            key = (r['configuration']['label'], r['seed'], r['method'])
            assert key in expected, ('Unplanned record', key)
            assert key not in records, ('Duplicate record', key)
            assert r['configuration'] == cfgs[key[0]], ('Configuration mismatch', key)
            assert r['mode'] == plan['mode']
            assert plan['seeds'][r['rep']] == r['seed']
            candidates = r['candidates']
            assert [c['factor'] for c in candidates] == plan['grid']
            eligible = [i for i,c in enumerate(candidates) if c['status']=='ok']
            assert r['candidate_successes'] == len(eligible)
            if eligible:
                selected = min(eligible, key=lambda i: candidates[i]['validation_mse'])
                assert r['selected_index'] == selected and r['status']=='ok'
                assert r['factor'] == candidates[selected]['factor']
                assert len(candidates[selected]['trace']) == plan['rounds']
                assert r['grid_edge'] == (selected in [0,len(candidates)-1])
                for metric in ['l2','test_mse','fp','fn','f1','population_prediction_excess']:
                    assert r[metric] is not None and math.isfinite(r[metric]), (key, metric)
                assert r['exact'] == (r['fp']==0 and r['fn']==0)
                # Recheck the declared coefficient accuracy and support metrics.
                delta = [a-b for a,b in zip(r['coefficient'],r['dataset']['truth'])]
                norm = math.sqrt(sum(v*v for v in delta))
                assert abs(norm-r['l2']) < 1e-10*(1+norm), key
                actual = {i for i,a in enumerate(r['coefficient']) if abs(a)>plan['support_threshold']}
                truth = {i for i,a in enumerate(r['dataset']['truth']) if a!=0}
                assert (len(actual-truth), len(truth-actual)) == (r['fp'],r['fn'])
            else:
                assert r['status']=='all_candidates_failed' and r['selected_index'] is None
            for c in candidates:
                assert c['communication_rounds'] == len(c['trace'])
                expected_bytes = 16*(r['configuration']['m']-1)*r['configuration']['p']*len(c['trace'])
                assert c['vector_payload_bytes'] == expected_bytes
            assert r['total_search_rounds'] == sum(c['communication_rounds'] for c in candidates)
            assert r['total_search_updates'] == sum(c['total_updates'] for c in candidates)
            assert r['total_search_vector_payload_bytes'] == sum(c['vector_payload_bytes'] for c in candidates)
            assert abs(r['total_search_seconds']-sum(c['seconds'] for c in candidates)) < 1e-8
            data_hashes[key[:2]].add(r['dataset']['data_sha256'])
            compact = {k:r.get(k) for k in [
                'method','seed','status','l2','test_mse','fp','fn','f1','exact','factor',
                'population_prediction_excess','selected_index','candidate_successes',
                'total_search_seconds','total_search_updates','total_search_rounds',
                'total_search_vector_payload_bytes','selected_candidate_seconds',
                'selected_candidate_updates','selected_candidate_vector_payload_bytes',
                'first_target_round']}
            compact['candidate_statuses'] = [c['status'] for c in candidates]
            compact['master_min_eigenvalue'] = r['dataset']['master_min_eigenvalue']
            records[key] = compact
    assert all(len(h)==1 for h in data_hashes.values()), 'Methods did not share data'
    missing = sorted(expected-records.keys())
    if not partial:
        assert not missing, f'Incomplete experiment: {len(missing)} missing records; first {missing[:5]}'
        assert study in ['main','sample_size']
        assert plan['mode']==('full' if study=='main' else 'sample_size'), 'Wrong experiment mode'
        assert len(cfgs)==(23 if study=='main' else 6) and len(plan['seeds'])==30 and len(methods)==9
    return records, {'expected_records':len(expected), 'observed_records':len(records),
                     'missing_records':len(missing), 'first_missing_keys':missing[:10],
                     'complete':not missing, 'paired_data_hashes_verified':True,
                     'candidate_selection_verified':True, 'coefficient_metrics_verified':True}


def aggregate(plan, records):
    methods = [m['name'] for m in plan['methods']]
    out, paired = [], []
    for ci, cf in enumerate(plan['configurations'],1):
        cfg = cf['label']
        for method in methods:
            rr = [records[(cfg,seed,method)] for seed in plan['seeds'] if (cfg,seed,method) in records]
            good = [r for r in rr if r['status']=='ok']
            statuses = Counter(s for r in rr for s in r['candidate_statuses'])
            row = dict(configuration=cfg, configuration_id=f'C{ci:02d}', method=method,
                       attempted=len(rr), planned=len(plan['seeds']), success=len(good),
                       exact=sum(bool(r['exact']) for r in good),
                       candidate_count=sum(len(r['candidate_statuses']) for r in rr),
                       candidate_failures=sum(s!='ok' for r in rr for s in r['candidate_statuses']),
                       candidate_statuses=dict(statuses),
                       grid_low=sum(r['selected_index']==0 for r in good),
                       grid_high=sum(r['selected_index']==len(plan['grid'])-1 for r in good),
                       selected_factor_counts=dict(Counter(str(r['factor']) for r in good)),
                       indefinite_master_samples=sum(r['master_min_eigenvalue']<0 for r in rr))
            for key in ['l2','test_mse','fp','fn','f1','population_prediction_excess',
                        'selected_candidate_seconds','selected_candidate_updates',
                        'selected_candidate_vector_payload_bytes']:
                row[key] = moments([r[key] for r in good])
            for key in ['total_search_seconds','total_search_updates','total_search_rounds',
                        'total_search_vector_payload_bytes']:
                row[key] = moments([r[key] for r in rr])
            row['targets'] = {}
            for target in plan['targets']:
                vals = [r['first_target_round'][str(target)] for r in good
                        if r['first_target_round'][str(target)] is not None]
                row['targets'][str(target)] = dict(attained=len(vals),denominator=len(rr),
                                                   rounds=moments(vals),
                                                   selected_path_vector_payload_bytes=moments([
                                                       16*(cf['m']-1)*cf['p']*t for t in vals]))
            out.append(row)
        for proposed in ['Trim-SCAD','Trim-MCP']:
            for comparator in PAIRED_COMPARATORS:
                both = [(records[(cfg,s,proposed)],records[(cfg,s,comparator)])
                        for s in plan['seeds'] if (cfg,s,proposed) in records and (cfg,s,comparator) in records]
                common = [(a,b) for a,b in both if a['status']=='ok' and b['status']=='ok']
                differences = [a['l2']-b['l2'] for a,b in common]
                paired.append(dict(configuration=cfg, configuration_id=f'C{ci:02d}',
                                   proposed=proposed, comparator=comparator,
                                   available_pairs=len(both), common_success=len(common),
                                   l2_difference=moments(differences),
                                   proposed_lower_error=sum(v<0 for v in differences),
                                   proposed_higher_error=sum(v>0 for v in differences),
                                   test_mse_difference=moments([a['test_mse']-b['test_mse'] for a,b in common]),
                                   exact_count_difference=sum(bool(a['exact']) if a['status']=='ok' else 0 for a,b in both)
                                       -sum(bool(b['exact']) if b['status']=='ok' else 0 for a,b in both)))
    return out, paired


def configuration_diagnostics(plan, records):
    """One curvature observation per configuration and seed, not per method."""
    result = []
    for ci, cf in enumerate(plan['configurations'],1):
        values = []
        for seed in plan['seeds']:
            seen = {r['master_min_eigenvalue'] for (cfg,s,m),r in records.items()
                    if cfg==cf['label'] and s==seed}
            assert len(seen)<=1, ('Inconsistent master spectrum',cf['label'],seed)
            if seen:
                values.append({'seed':seed,'master_min_eigenvalue':next(iter(seen))})
        eigenvalues = [v['master_min_eigenvalue'] for v in values]
        result.append({'configuration':cf['label'],'configuration_id':f'C{ci:02d}',
                       'distinct_seed_count':len(values),
                       'negative_master_eigenvalue_count':sum(v<0 for v in eigenvalues),
                       'master_min_eigenvalue_range':[min(eigenvalues),max(eigenvalues)] if values else None,
                       'by_seed':values})
    return result


def name(method):
    return DISPLAY.get(method,method)


def num(value, digits=3):
    return '--' if value is None else f'{value:.{digits}f}'


def mean_se(value, digits=3):
    if value['mean'] is None:
        return '--'
    if value['se'] is None:
        return '$'+num(value['mean'],digits)+'$'
    return '$'+num(value['mean'],digits)+r'\pm'+num(value['se'],digits)+'$'


def table(spec, header, rows, caption, label):
    return (r'\par\begingroup\renewcommand{\baselinestretch}{1.2}\small\selectfont\setlength{\tabcolsep}{3pt}'+'\n'
            +r'\renewcommand{\arraystretch}{1.05}'+'\n'
            +r'\begin{longtable}{'+spec+'}\n'
            +r'\caption{'+caption+r'}\label{'+label+r'}\\'+'\n'
            +r'\toprule '+header+r'\\\midrule\endfirsthead'+'\n'
            +r'\toprule '+header+r'\\\midrule\endhead'+'\n'
            +r'\bottomrule\endlastfoot'+'\n'
            +'\n'.join(' & '.join(row)+r' \\' for row in rows)+'\n'
            +r'\end{longtable}\endgroup'+'\n')


def write_tables(plan, summary, paired, output_root=None):
    destination = output_root or ROOT
    cfgrows = []
    for ci,c in enumerate(plan['configurations'],1):
        cfgrows.append([f'C{ci:02d}',num(c['q'],1),str(c['f']),
                        {'none':'None','gaussian':'Gaussian','stealth':'In-range'}[c['attack']],
                        num(c['rho'],1),str(c['p']),c['layout'].capitalize()])
    parts = [r'''Each setting has 30 independent seeds and nine methods. The same observations,
masks, validation sample, and test sample are used across methods within each seed.
All settings have 12 nodes, 512 observations per node, six nonzero coefficients,
and unit noise standard deviation. The trimming budget equals the Byzantine count.
The coefficient magnitude is one. Clustered signals occupy two three-coordinate
blocks with common signs within each block; the alternating setting reverses
successive signs, and the spread setting separates the six active coordinates.
''']
    parts.append(table('lrrlrrl',r'ID & $q$ & $m_{\rm B}$ & Attack & Corr. & $p$ & Signals',
                       cfgrows,'Configurations of the joint missingness and Byzantine benchmark.',
                       'tab:competitive-settings'))
    parts.append(r'''Accuracy summaries are conditional on successful selected fits. Exact support
recovery uses all 30 repetitions as the denominator, with failed fits counted as
failures. The support threshold is $10^{-6}$. Reported uncertainty is the Monte
Carlo standard error across independent seeds. F1 and test MSE also use successful
fits. No failed repetition is replaced by an arbitrary finite estimation error.
An SE is shown only when at least two fits succeed.
''')
    rows = [[r['configuration_id'],name(r['method']),f"{r['success']}/{r['planned']}",
             mean_se(r['l2']),f"{r['exact']}/{r['planned']}",num(r['f1']['mean']),
             mean_se(r['test_mse'])] for r in summary]
    parts.append(table('llrlrrl',r'ID & Method & Success & $\ell_2$ error & Exact & F1 & Test MSE',
                       rows,'Estimation, support recovery, and prediction in every planned setting.',
                       'tab:competitive-accuracy'))
    parts.append(r'''FP and FN are mean false-positive and false-negative counts among successful
fits. Candidate failures include unsuccessful initializations, iteration limits,
and numerical divergence. Low and High count successful repetitions selecting
the smallest and largest grid multipliers. Each cell attempts all seven candidates.
''')
    rows = [[r['configuration_id'],name(r['method']),num(r['fp']['mean'],2),
             num(r['fn']['mean'],2),f"{r['candidate_failures']}/{r['candidate_count']}",
             str(r['grid_low']),str(r['grid_high'])] for r in summary]
    parts.append(table('llrrrrr',r'ID & Method & FP & FN & Failed candidates & Low & High',
                       rows,'Selection and numerical diagnostics for the complete tuning search.',
                       'tab:competitive-diagnostics'))
    parts.append(r'''Paired differences are the proposed method minus its comparator on seeds
where both selected fits succeed. A negative value favors the proposed method.
The shared-success count is reported separately for each comparison; these
conditional differences do not subsume differences in failure rates.
''')
    rows = [[r['configuration_id'],r['proposed'].replace('Trim-',''),name(r['comparator']),
             str(r['common_success']),mean_se(r['l2_difference']),str(r['proposed_lower_error'])]
            for r in paired]
    parts.append(table('lllllr',r'ID & Proposed & Comparator & Pairs & $\Delta\ell_2$ & Lower',
                       rows,'Paired error differences (mean plus or minus Monte Carlo SE). Lower counts seeds with a smaller proposed-method error.',
                       'tab:competitive-paired'))
    parts.append(r'''Computational summaries are medians. Selected updates condition on successful
selection; search updates, search time, and vector payload include all seven
candidates and all failures. The serial elapsed time includes fitting and
validation scoring, but excludes data generation and moment construction.
Vector payload counts coefficient broadcasts and returned gradient vectors as
$16(m-1)p$ bytes per round; it excludes protocol overhead. These counts describe
the algorithmic messages and are not measured network traffic. Target counts
require a fully successful selected fit whose recorded path reaches error $0.2$.
''')
    rows = []
    for r in summary:
        rows.append([r['configuration_id'],name(r['method']),
                     num(r['selected_candidate_updates']['median'],0),
                     num(r['total_search_updates']['median'],0),
                     num(r['total_search_seconds']['median'],3),
                     num(r['total_search_vector_payload_bytes']['median']/1e6,3),
                     f"{r['targets']['0.2']['attained']}/{r['planned']}"])
    parts.append(table('llrrrrr',r'ID & Method & Sel. updates & All updates & Seconds & MB & Error $\le .2$',
                       rows,'Selected-solve updates, complete-search costs, and target attainment.',
                       'tab:competitive-costs'))
    (destination/'results'/'competitive_tables.tex').write_text('\n'.join(parts),encoding='utf-8')

    lookup = {(r['configuration'],r['method']):r for r in summary}
    rows = []
    for method in (m['name'] for m in plan['methods']):
        g = lookup[('q0.7_f2_gaussian',method)]
        s = lookup[('q0.7_f2_stealth',method)]
        rows.append([name(method),mean_se(g['l2']),f"{g['success']}/{g['exact']}",
                     mean_se(s['l2']),f"{s['success']}/{s['exact']}"])
    main = (r'\begin{table}[!htb]\centering'+'\n'
            +r'\caption{Coefficient error and support recovery with 30\% missingness and two Byzantine nodes among twelve. Errors are means $\pm$ SE among successful fits; $S/E$ counts successful fits/exact recoveries out of 30.}'+'\n'
            +r'\label{tab:competitive}'+'\n'
            +r'\par\begingroup\renewcommand{\baselinestretch}{1.2}\small\selectfont'+'\n'
            +r'\setlength{\tabcolsep}{3pt}\renewcommand{\arraystretch}{1.05}'+'\n'
            +r'\begin{tabular}{llr@{\hspace{1em}}lr}\toprule'+'\n'
            +r' & \multicolumn{2}{c}{Gaussian} & \multicolumn{2}{c}{In-range}\\'+'\n'
            +r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}'+'\n'
            +r'Method & $\ell_2$ error & $S/E$ & $\ell_2$ error & $S/E$\\\midrule'+'\n'
            +'\n'.join(' & '.join(row)+r' \\' for row in rows)+'\n'
            +r'\bottomrule\end{tabular}\endgroup\end{table}'+'\n')
    (destination/'results'/'competitive_main_table.tex').write_text(main,encoding='utf-8')


def plot_accuracy(plan, summary, source, plan_path, output_root=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,
                         'axes.labelsize':9,'axes.titlesize':9,
                         'xtick.labelsize':9,'ytick.labelsize':9,
                         'legend.fontsize':9,'pdf.fonttype':42,
                         'axes.spines.top':False,'axes.spines.right':False})
    lookup = {(r['configuration'],r['method']):r for r in summary}
    colors = ['#0072B2','#D55E00','#333333','#009E73','#CC79A7','#E69F00']
    markers = ['o','s','^','D','v','X']
    lines = ['-','--',':','-.','--',':']
    fig, axs = plt.subplots(1,2,figsize=(5.3,3.25),sharey=True)
    selected = []
    for ai, attack in enumerate(['gaussian','stealth']):
        ax = axs[ai]
        for method,color,marker,ls in zip(PLOT_METHODS,colors,markers,lines):
            rr = [lookup[(f'q{q:.1f}_f2_{attack}',method)] for q in [.9,.7,.5]]
            ys = [float('nan') if r['l2']['mean'] is None else r['l2']['mean'] for r in rr]
            es = [0 if r['l2']['se'] is None else r['l2']['se'] for r in rr]
            ax.errorbar([10,30,50],ys,yerr=es,color=color,marker=marker,ls=ls,
                        linewidth=1.25,markersize=3.8,elinewidth=.8,capsize=2,
                        markerfacecolor='white' if method in ['Trim-SCAD','Trim-MCP'] else color,
                        label=name(method))
            selected.extend({'configuration':r['configuration'],'method':method,
                             'success':r['success'],'planned':r['planned'],
                             'mean':r['l2']['mean'],'mcse':r['l2']['se']} for r in rr)
        ax.set_xticks([10,30,50]);ax.set_xlim(7,53)
        ax.set_xlabel('Missing features (%)')
        ax.set_title('(a) Gaussian replacement' if ai==0 else '(b) In-range attack',loc='left')
        ax.grid(axis='y',alpha=.2,linewidth=.6)
    axs[0].set_ylabel(r'Mean $\ell_2$ error')
    upper = max(r['mean']+(r['mcse'] or 0) for r in selected if r['mean'] is not None)
    axs[0].set_ylim(0,max(.05,upper*1.08))
    handles, labels = axs[0].get_legend_handles_labels()
    # Two rows of three entries; the displayed method set is fixed above.
    fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,
               bbox_to_anchor=(.5,.005),columnspacing=.9,handlelength=1.8,
               handletextpad=.4)
    fig.subplots_adjust(left=.12,right=.99,top=.90,bottom=.31,wspace=.15)
    directory = (output_root or ROOT)/'figures'
    fig.savefig(directory/'competitive_accuracy.pdf')
    fig.savefig(directory/'competitive_accuracy.png',dpi=220)
    plt.close(fig)
    provenance = {'source':str(source.relative_to(ROOT)) if source.is_relative_to(ROOT) else str(source.resolve()),
                  'source_sha256':sha256(source),
                  'plan':str(plan_path.relative_to(ROOT)) if plan_path.is_relative_to(ROOT) else str(plan_path.resolve()),
                  'plan_sha256':sha256(plan_path),
                  'script_sha256':sha256(Path(__file__)), 'seeds':plan['seeds'],
                  'rule':'f=b=2; p=256,n=512,rho=.6,clustered; q=.9,.7,.5; Gaussian and stealth',
                  'methods_fixed_before_full_results':PLOT_METHODS,
                  'points':'Mean L2 error among successful selected fits',
                  'bars':'One Monte Carlo standard error across successful independent seeds',
                  'failures':'Included in table success denominators; no arbitrary finite errors assigned',
                  'all_planned_seeds_accounted_for':True,'plotted_cells':selected}
    (directory/'competitive_accuracy_provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')


def write_sample_size_table(plan, summary):
    primary_path = ROOT/'results'/'competitive_summary.json'
    primary = json.loads(primary_path.read_text(encoding='utf-8'))
    assert primary['status']=='complete' and primary['checks']['complete']
    old = {(r['configuration'],r['method']):r for r in primary['summary']}
    cfgs = {c['label']:c for c in plan['configurations']}
    text = r'''The fixed-$n$ column below uses the original 30 seeds; the adjusted-$n$ column
uses the new 30 seeds. These are independent cohorts, so no paired standard
error is computed between the two columns. At $q=0.7$, the sample size remains
512, providing an independent repetition at the reference sample size.
Errors are means $\pm$ Monte Carlo SE among successful fits. Each count pair
$S/E$ gives successful fits and exact support recoveries, both out of 30.
'''
    settings = []
    for ci,c in enumerate(plan['configurations'],1):
        settings.append([f'F{ci:02d}',str(round(100*(1-c['q']))),str(c['n']),
                         'Gaussian' if c['attack']=='gaussian' else 'In-range'])
    text += table('lrrl',r'ID & Missing (\%) & Adjusted $n$ & Attack',settings,
                  'Settings of the independent sample-size follow-up.', 'tab:competitive-sample-settings')
    rows = []
    for r in summary:
        cf = cfgs[r['configuration']]
        fixed = (f"q{cf['q']:.1f}_f2_{cf['attack']}" if cf['q']!=.3
                 else f"q0.3_{cf['attack']}")
        before = old[(fixed,r['method'])]
        rows.append([r['configuration_id'],name(r['method']),mean_se(before['l2']),
                     f"{before['success']}/{before['exact']}",mean_se(r['l2']),
                     f"{r['success']}/{r['exact']}"])
    text += table('lllrlr',r'ID & Method & Fixed $n=512$ & $S/E$ & Adjusted $n$ & $S/E$',rows,
                  'Coefficient errors and support recovery at fixed and adjusted local sample sizes.',
                  'tab:competitive-sample-size')
    (ROOT/'results'/'competitive_sample_size_tables.tex').write_text(text,encoding='utf-8')
    return {'source':'results/competitive_summary.json','sha256':sha256(primary_path),
            'comparison':'Independent fixed-n and follow-up cohorts; no paired SE across cohorts'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--study',choices=['main','sample_size'],default='main')
    ap.add_argument('--input',type=Path)
    ap.add_argument('--plan',type=Path)
    ap.add_argument('--partial',action='store_true')
    ap.add_argument('--plot',action='store_true')
    args = ap.parse_args()
    stem = 'competitive_full' if args.study=='main' else 'competitive_sample_size'
    args.input = args.input or ROOT/'results'/f'{stem}.jsonl'
    args.plan = args.plan or ROOT/'results'/f'{stem}_plan.json'
    if args.partial and args.plot:
        raise ValueError('Partial previews cannot generate final figures')
    plan = json.loads(args.plan.read_text(encoding='utf-8'))
    before = args.input.stat()
    records, checks = read_records(plan,args.input,args.partial,args.study)
    if not args.partial:
        after = args.input.stat()
        assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns), 'Input still changing'
    summary, paired = aggregate(plan,records)
    diagnostics = configuration_diagnostics(plan,records)
    if args.study=='sample_size':
        for r in summary+paired+diagnostics:
            r['configuration_id'] = 'F'+r['configuration_id'][1:]
    result = {'generated_utc':datetime.now(timezone.utc).isoformat(),
              'status':'INTERNAL PREVIEW - NOT FINAL' if args.partial else 'complete',
              'input':str(args.input),'input_sha256':sha256(args.input),
              'plan_sha256':sha256(args.plan),'script_sha256':sha256(Path(__file__)),
              'checks':checks,'plan':plan,'summary':summary,'paired':paired,
              'configuration_diagnostics':diagnostics,
              'interpretation':{'accuracy':'Conditional on successful selected fits',
                                'exact':'Failed fits count as failed recovery',
                                'costs':'Complete search including failed candidates',
                                'paired':'Only jointly successful fits; count reported'}}
    if args.partial:
        preview = ROOT.parent.parent/'work'/'revision28'
        preview.mkdir(exist_ok=True,parents=True)
        out = preview/('competitive_preview.json' if args.study=='main' else 'competitive_sample_size_preview.json')
    else:
        if args.study=='main':
            out = ROOT/'results'/'competitive_summary.json'
            write_tables(plan,summary,paired)
            if args.plot:
                plot_accuracy(plan,summary,args.input,args.plan)
        else:
            if args.plot:
                raise ValueError('Sample-size follow-up uses complete tables; the main figure remains fixed-n')
            out = ROOT/'results'/'competitive_sample_size_summary.json'
            result['fixed_n_comparison_source'] = write_sample_size_table(plan,summary)
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':checks,'summary':str(out)},indent=2))


if __name__=='__main__':
    main()
