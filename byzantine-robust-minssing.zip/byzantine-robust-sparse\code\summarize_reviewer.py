"""Validate and summarize all added review experiments without dropping failures."""
from pathlib import Path
import json
import numpy as np
R=Path(__file__).resolve().parents[1]/'results'
u=json.loads((R/'reviewer_unequal.json').read_text())['records']
c=json.loads((R/'reviewer_calibration.json').read_text())['records']
assert len(u)==270 and sum(len(x['candidates']) for x in u)==1080
assert len(c)==60 and sum(len(x['baseline_candidates'])+len(x['baseline_scad_candidates']) for x in c)==480
def ms(vals):
    return (float(np.mean(vals)),float(np.std(vals,ddof=1)/np.sqrt(len(vals)))) if len(vals)>1 else (None,None)
def fmt(vals,digits=3):
    mean,se=ms(vals)
    return '--' if mean is None else f'${mean:.{digits}f}\\pm{se:.{digits}f}$'
us=[]
for key in dict.fromkeys((r['ratio'],r['master'],r['attacked'],r['method']) for r in u):
    a=[r for r in u if (r['ratio'],r['master'],r['attacked'],r['method'])==key];good=[r['selected'] for r in a if r['selected']]
    assert all(sum(r['sizes'])==2400 and len(r['sizes'])==8 for r in a)
    for r in a:
        ok=[v for v in r['candidates'] if v['status']=='ok']
        assert (r['selected'] is None)==(not ok)
        if ok:assert r['selected']['validation']==min(v['validation'] for v in ok)
    us.append(dict(key=key,N=len(a),success=len(good),local_pass=sum(x['certificate']['passed'] for x in good),l2=ms([x['l2'] for x in good]),rounds=ms([x['rounds'] for x in good])))
cs=[]
for key in dict.fromkeys((r['s'],r['latent_ar'],r['N']) for r in c):
    a=[r for r in c if (r['s'],r['latent_ar'],r['N'])==key];good=[r['candidates'][r['selected_index']] for r in a if r['selected_index'] is not None]
    for r in a:
        admitted=[(i,v) for i,v in enumerate(r['candidates']) if v['calibration']['passed'] and v['status']=='ok' and v['local']]
        assert all(v['covered'] for v in r['candidates'] if v['calibration']['passed'])
        assert (r['selected_index'] is None)==(not admitted)
        if admitted:assert r['selected_index']==min(admitted,key=lambda iv:iv[1]['calibration']['radius'])[0]
        for k in ['baseline','baseline_scad']:
            opts=r['baseline_candidates' if k=='baseline' else 'baseline_scad_candidates'];ok=[x for x in opts if x['status']=='ok']
            assert r[k] is not None and r[k]['validation']==min(x['validation'] for x in ok)
    cs.append(dict(key=key,N=len(a),admitted=len(good),covered=sum(x['covered'] for x in good),radius=ms([x['calibration']['radius'] for x in good]),distributed_l2=ms([x['l2'] for x in good]),lasso_l2=ms([x['baseline']['l2'] for x in a]),scad_l2=ms([x['baseline_scad']['l2'] for x in a]),moment_median=float(np.median([x['moment_seconds'] for x in a])),certificate_median=float(np.median([x['certificate_seconds'] for x in a])),baseline_median=float(np.median([x['baseline_fit_select_seconds'] for x in a]))))
(R/'reviewer_summary.json').write_text(json.dumps(dict(unequal=us,calibration=cs),indent=2))
lines=[r'''We fix $m=8$, $p=240$, $q=0.7$ and 2400 assigned observations. Gaussian AR(1) features have correlation 0.3, four equally spaced coefficients alternate between $1.2$ and $-1.2$, and Gaussian noise has standard deviation 0.5. A geometric allocation targets largest-to-smallest ratios 1, 4 and 16; integer rounding gives the sizes below. The master receives either the smallest or largest allocation. Among the remaining workers, two with the smallest or largest allocations send Gaussian replacement messages, with $m_{\rm B}=b=2$. Honest sample totals therefore vary with attack placement, while the total assigned budget is fixed. Honest observations remain IID.

Ten seeds per allocation, three methods and the common four-point tuning grid give 270 selections and 1080 candidate fits. A separate complete validation sample of size 400 selects the lowest-prediction-error converged fit. Each fit runs eight communication rounds; the last weighted subproblem is checked using the local certificate. No truth or honest labels enter selection. The same seed is shared across methods within a configuration; changing sample sizes changes the generated data stream.

\begin{center}\small
\begin{tabular}{rllrrrr}\toprule
Ratio & Master & Attacked & $n_1$ & $N_H$ & $N_{\rm eff}$ & Size range\\\midrule''']
for key in dict.fromkeys((r['ratio'],r['master'],r['attacked']) for r in u):
    r=next(x for x in u if (x['ratio'],x['master'],x['attacked'])==key)
    lines.append(f"{key[0]} & {key[1]} & {key[2]} & {r['sizes'][0]} & {r['honest_total']} & {r['honest_effective']:.1f} & {min(r['sizes'])}--{max(r['sizes'])} \\\\")
lines.append(r'''\bottomrule\end{tabular}\end{center}
\small
\begin{longtable}{rlllrrl}\toprule
Ratio & Master & Attacked & Method & Success & Local pass & L2 mean $\pm$ SE\\\midrule\endhead
\bottomrule\endlastfoot''')
for x in us:
    k=x['key'];a=[r['selected']['l2'] for r in u if (r['ratio'],r['master'],r['attacked'],r['method'])==k and r['selected']]
    lines.append(f'{k[0]} & {k[1]} & {k[2]} & {k[3]} & {x["success"]}/10 & {x["local_pass"]}/10 & {fmt(a)} \\\\')
lines.append(r'''\end{longtable}\normalsize
All selected fits complete eight rounds and pass the final local check. Their vector payload is therefore the same, $16(8-1)240\times8=215040$ bytes per selected fit, excluding the four-candidate tuning multiplier and control traffic. Nevertheless, estimation deteriorates sharply for the smallest master at ratio 16. These data-tuned runs illustrate that locally convergent optimization can coexist with substantial estimation error.''')
(R/'reviewer_unequal.tex').write_text('\n'.join(lines),encoding='utf-8')
lines=[r'''The trusted-resource comparison uses $p=240$, $q=0.7$, 20 training nodes with 120 observations each, two Gaussian replacement attackers and $b=2$. We use independent Rademacher features with $s=1$ or $s=4$, and a correlated four-signal design obtained by taking signs of Gaussian AR(1) features with latent correlation 0.3. The first $s$ coefficients alternate between $1.2$ and $-1.2$. Noise is uniform on $[-0.2,0.2]$, giving known bounds $H=1$ and $Y_{\max}=1.2s+0.2$.

For each of ten seeds per design, four distributed scaled-weight SCAD candidates are fixed before drawing trusted observations. Calibration uses $N_{\rm cal}=10000$ or 50000 with $\delta=0.05$, independently of fitting and attacks. Each size is prespecified; samples are nested within a seed, and there is no data-dependent stopping over sample sizes. The selection rule requires a successful fit, a passing final local check and positive calibrated curvature, then minimizes the radius.

Two trusted-only baselines receive the same trusted sample budget. They fit corrected Lasso or scaled-weight SCAD using $N_{\rm cal}-1000$ rows and select among the same four penalty multipliers using the remaining 1000 masked rows. Selection minimizes $x^\top\widetilde G_{\rm val}x-2\widetilde\gamma_{\rm val}^\top x$. This has the same population minimizer as squared prediction error, up to an additive constant. The SCAD baseline uses the single-node practical iteration for eight rounds. Baseline coefficient errors are evaluated against truth after selection. The methods use the same trusted sample budget with their respective fitting and tuning rules. Distributed fitting additionally uses the 2400 observations assigned to the distributed system.

\begin{center}\small
\begin{tabular}{rrrrrrr}\toprule
$s$ & Latent AR & $N_{\rm cal}$ & Admitted & Covered & Mean radius & Distributed L2\\\midrule''']
for x in cs:
    k=x['key'];ra='--' if x['radius'][0] is None else f'{x["radius"][0]:.3f}';err='--' if x['distributed_l2'][0] is None else f'{x["distributed_l2"][0]:.4f}'
    lines.append(f'{k[0]} & {k[1]:.1f} & {k[2]} & {x["admitted"]}/10 & {str(x["covered"])+"/"+str(x["admitted"]) if x["admitted"] else "--"} & {ra} & {err} \\\\')
lines.append(r'''\bottomrule\end{tabular}\end{center}
\begin{center}\small
\begin{tabular}{rrrll}\toprule
$s$ & Latent AR & $N_{\rm cal}$ & Trusted Lasso L2 $\pm$ SE & Trusted SCAD L2 $\pm$ SE\\\midrule''')
for x in cs:
    k=x['key'];a=[r for r in c if (r['s'],r['latent_ar'],r['N'])==k]
    lines.append(f'{k[0]} & {k[1]:.1f} & {k[2]} & {fmt([r["baseline"]["l2"] for r in a],4)} & {fmt([r["baseline_scad"]["l2"] for r in a],4)} \\\\')
lines.append(r'''\bottomrule\end{tabular}\end{center}
Every trusted-only selection succeeds (10/10 in each cell). Distributed errors and radii above are conditional on admission; an empty cell has no selected certified estimator. All admitted candidates are covered in the saved runs. Four independent signals require the larger calibration sample to admit candidates, and the correlated four-signal design has no admissions at either size. These outcomes quantify the certificate's conservative admission behavior.

\begin{center}\small
\begin{tabular}{rrrrrr}\toprule
$s$ & Latent AR & $N_{\rm cal}$ & Moments (s) & Certificate (s) & Two baseline grids (s)\\\midrule''')
for x in cs:
    k=x['key'];lines.append(f'{k[0]} & {k[1]:.1f} & {k[2]} & {x["moment_median"]:.3f} & {x["certificate_median"]:.3f} & {x["baseline_median"]:.3f} \\\\')
lines.append(r'''\bottomrule\end{tabular}\end{center}
Times are medians across ten seeds on the same host with one BLAS thread. Moment construction is streamed in batches of at most 5000 and excludes data generation. Certificate timing includes corrected moments and the four bounds; baseline timing includes both fitting/selection grids but excludes shared moment construction. The reported times measure the individual calibration and fitting components. One dense $240\times240$ float64 Gram matrix occupies 460800 bytes (0.439 MiB); other arrays and process overhead are additional. The calibration stage uses dense moments, unlike matrix-free distributed fitting.''')
(R/'reviewer_calibration.tex').write_text('\n'.join(lines),encoding='utf-8')
def get(s,corr,N):return next(x for x in cs if x['key']==(s,corr,N))
b=get(4,0,50000);b1=get(1,0,50000);bc=get(4,.3,50000)
text=r'''An additional study fixes 2400 assigned observations across eight nodes and varies the largest-to-smallest allocation ratio from 1 to approximately 16. It crosses small/large master allocations with attacks on small/large workers, using ten seeds and three methods. All 270 selected fits converge and pass the final local check. At ratio 16, Trim-SCAD error is $0.988$--$1.395$ with a 51-observation master, versus $0.107$--$0.173$ with an 821-observation master; the balanced reference gives $0.110$. Thus convergence certification can coexist with poor estimation. The supplement reports all allocations, errors and communication counts.

We also compare calibration with fitting directly on the same trusted sample budget at $q=0.7$. Trusted-only corrected Lasso and scaled-weight SCAD reserve 1000 masked rows for tuning and fit on the rest. With four independent signals, 10000 calibration observations admit no candidates; 50000 admit all ten, with mean radius '''+f'${b["radius"][0]:.3f}$ and error ${b["distributed_l2"][0]:.3f}$. Trusted-only SCAD has error ${b["scad_l2"][0]:.3f}$ at the larger budget. '+r'''For four correlated signals, calibration still abstains in all ten runs at 50000 observations, while both trusted-only estimators converge. The supplement includes the single-signal control, both baselines and calibration costs. Calibration provides finite-sample verification at a substantial trusted-sample cost in these settings.'''
(R/'reviewer_main.tex').write_text(text,encoding='utf-8')
print(json.dumps(dict(unequal_selections=len(u),unequal_candidates=1080,calibration_records=len(c),unique_distributed_calibration_candidates=120,trusted_candidates=480,calibration=cs),indent=2))
