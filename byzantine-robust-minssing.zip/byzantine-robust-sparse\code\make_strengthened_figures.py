"""Publication vector diagrams and plots drawn from saved results."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle,FancyArrowPatch
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
def box(ax,xy,w,h,label,color='#eaf2fa',size=9):
 ax.add_patch(FancyBboxPatch(xy,w,h,boxstyle='round,pad=.015,rounding_size=.07',edgecolor='#34506b',facecolor=color,lw=1))
 ax.text(xy[0]+w/2,xy[1]+h/2,label,ha='center',va='center',fontsize=size)
def arrow(ax,a,b,color='#34506b',style='-'):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=10,lw=1.2,color=color,linestyle=style))
def framework():
 fig,ax=plt.subplots(figsize=(7.2,3.0));ax.set_xlim(0,12);ax.set_ylim(0,5);ax.axis('off')
 ax.text(.15,4.7,'Distributed observations',weight='bold');ax.text(4.3,4.7,'Trusted master',weight='bold');ax.text(9.35,4.7,'Sparse learning',weight='bold')
 for row,y in enumerate([3.25,1.95]):
  box(ax,(.15,y),2.8,1.0,'',size=8)
  for i in range(3):
   for j in range(5):
    miss=(i+j+row)%4==0
    ax.add_patch(Rectangle((.32+.17*j,y+.22+.17*i),.135,.135,facecolor='white' if miss else '#397aa8',edgecolor='#397aa8',lw=.5))
    if miss:ax.text(.387+.17*j,y+.287+.17*i,'?',ha='center',va='center',fontsize=6)
  ax.text(2.05,y+.5,f'Honest worker {chr(65+row)}\nMCAR mask',ha='center',va='center',fontsize=8)
  arrow(ax,(2.98,y+.5),(4.05,3.45));
 box(ax,(.15,.55),2.8,.85,'Byzantine workers\nArbitrary gradient messages','#fae9e7',8)
 arrow(ax,(2.98,.98),(4.05,3.15),'#ab423b','--')
 box(ax,(4.1,2.8),3.65,1.15,'Coordinatewise trimming\n+ corrected local surrogate',size=9)
 box(ax,(4.1,1.05),3.65,1.15,'Folded-concave weights\nSparse continuation',size=9)
 arrow(ax,(5.9,2.78),(5.9,2.22))
 ax.text(5.95,.55,'Sparse curvature controls inner steps',ha='center',fontsize=7)
 arrow(ax,(7.8,1.62),(8.8,1.62))
 box(ax,(8.85,1.05),2.95,2.9,'',color='#edf5ef')
 xs=np.linspace(9.1,11.5,13);vs=[0,.55,0,0,-.4,0,0,0,.7,0,0,0,0]
 ax.plot([9.08,11.55],[3,3],color='#58705f',lw=.8)
 for x,v in zip(xs,vs):ax.plot([x,x],[3,3+v],color='#33734c',lw=1.8);ax.plot(x,3+v,'o',color='#33734c',ms=2)
 ax.text(10.33,2.32,'Sparse coefficient estimate',ha='center',fontsize=8)
 ax.text(10.33,1.55,'Path or endpoint bounds\nunder separate conditions',ha='center',fontsize=8)
 ax.annotate('',xy=(1.6,4.3),xytext=(5.85,4.3),arrowprops=dict(arrowstyle='->',color='#34506b',lw=1.1))
 ax.text(4.0,4.36,'Broadcast next iterate',ha='center',fontsize=7)
 fig.subplots_adjust(left=.01,right=.995,bottom=.02,top=.98)
 for ext in ['pdf','svg','png']:fig.savefig(ROOT/'figures'/f'framework.{ext}',dpi=250)
 plt.close(fig)
def results():
 rows=json.loads((ROOT/'results'/'bridge_audit.json').read_text())['records'];lines=[]
 fig,ax=plt.subplots(1,2,figsize=(7.1,2.6))
 for q,marker in [(.7,'o'),(.9,'s')]:
  ns=[2000,20000,200000];rates=[];errs=[];pr=[]
  for n in ns:
   a=[x for x in rows if x['q']==q and x['n']==n];good=[x['selected'] for x in a if x['selected']];rates.append(len(good)/len(a))
   errs.append(np.mean([z['l2'] for z in good]) if good else np.nan);pr.append(np.mean([z['practical']['l2'] for z in a if z['practical']]))
   rad=np.mean([z['radius'] for z in good]) if good else np.nan
   lines.append(f"{q} & {n} & {len(good)}/5 & "+(f'{errs[-1]:.3f} & {rad:.3f}' if good else '-- & --')+f" & {pr[-1]:.3f} \\\\")
  ax[0].plot(ns,rates,marker=marker,label=f'q={q}')
  ax[1].plot(ns,errs,marker=marker,label=f'Envelope, q={q}')
  ax[1].plot(ns,pr,marker=marker,ls='--',label=f'Practical, q={q}')
 for a in ax:a.set_xscale('log');a.set_xlabel('Observations per node');a.grid(alpha=.2);a.legend(fontsize=7)
 ax[0].set_ylabel('Post-hoc certificate pass fraction');ax[0].set_ylim(-.05,1.05);ax[1].set_ylabel('Mean coefficient error');fig.tight_layout()
 fig.savefig(ROOT/'figures'/'bridge_audit.pdf');fig.savefig(ROOT/'figures'/'bridge_audit.png',dpi=180);plt.close(fig)
 (ROOT/'results'/'bridge_table.tex').write_text('\n'.join(lines)+'\n'+r'\bottomrule'+'\n')
 rows=json.loads((ROOT/'results'/'end_to_end.json').read_text())['records'];summary=[];lines=[]
 for m,n,p in dict.fromkeys((z['m'],z['n'],z['p']) for z in rows):
  for method in ['trim-scad','trim-lasso','vrmom-scad']:
   a=[z for z in rows if (z['m'],z['n'],z['p'],z['method'])==(m,n,p,method)];good=[z for z in a if z['status']=='ok']
   rec=dict(m=m,n=n,p=p,method=method,success=len(good),N=len(a),seconds=float(np.mean([z['seconds'] for z in a])),seconds_sd=float(np.std([z['seconds'] for z in a],ddof=1)),l2=float(np.mean([z['l2'] for z in good])) if good else None,MB=float(np.mean([z['payload_bytes'] for z in a]))/1e6)
   summary.append(rec);lines.append(f"{m} & {p} & {method} & {len(good)}/{len(a)} & {rec['seconds']:.3f} $\\pm$ {rec['seconds_sd']:.3f} & "+(f"{rec['l2']:.3f}" if good else '--')+f" & {rec['MB']:.2f} \\\\")
 (ROOT/'results'/'end_to_end_table.tex').write_text('\n'.join(lines)+'\n'+r'\bottomrule'+'\n');(ROOT/'results'/'end_to_end_summary.json').write_text(json.dumps(summary,indent=2))
 fig,ax=plt.subplots(1,2,figsize=(7.1,2.6))
 for method,marker in [('trim-scad','o'),('trim-lasso','s'),('vrmom-scad','^')]:
  a=[x for x in rows if x['m']==8 and x['p']==4000 and x['method']==method]
  for k in range(8):
   tr=[x['trace'][k] for x in a if len(x['trace'])>k and x['trace'][k]['status']=='ok']
   if tr:
    ax[0].plot(np.mean([x['seconds'] for x in tr]),np.mean([x['l2'] for x in tr]),marker=marker,color={'trim-scad':'C0','trim-lasso':'C1','vrmom-scad':'C2'}[method],label=method if k==0 else None)
    ax[1].plot(np.mean([x['payload_bytes'] for x in tr])/1e6,np.mean([x['l2'] for x in tr]),marker=marker,color={'trim-scad':'C0','trim-lasso':'C1','vrmom-scad':'C2'}[method])
 ax[0].set_xlabel('Elapsed solve time (seconds)');ax[1].set_xlabel('Cumulative payload (MB)')
 for a in ax:a.set_ylabel('Mean coefficient error');a.grid(alpha=.2)
 ax[0].legend(fontsize=7);fig.tight_layout();fig.savefig(ROOT/'figures'/'end_to_end.pdf');fig.savefig(ROOT/'figures'/'end_to_end.png',dpi=180);plt.close(fig)
if __name__=='__main__':framework();results()
