# Code map

All scripts are run from the repository root, for example `python code/smoke_test.py`.
Paths are resolved relative to the repository root (`ROOT = Path(__file__).parents[1]`),
so the directory layout `code/`, `data/`, `results/`, `figures/` must be preserved.

## Core

| Script | Role |
|---|---|
| `robust_sparse.py` | Corrected moments (`Node`), trimmed/median/VRMOM aggregation, Gaussian/stealth/sign-flip attacks, proximal homotopy, validation-tuned `fit`, theorem policy `envelope_fit`, `certified_select` |
| `smoke_test.py` | Fast correctness checks: dense vs matrix-free moments, score identity, aggregator identities, envelope policy on a constructed indefinite quadratic |
| `certificates.py` | Local continuation certificate helper used by the path audit |

## Main comparison

| Script | Role |
|---|---|
| `competitive_benchmark.py` | Fixed-sample benchmark; `--mode pilot|full`, `--repeats`, `--resume`. Writes the plan and a JSONL record per method, configuration and seed |
| `competitive_sample_size.py` | Sample-size follow-up; needs the primary plan, writes its own plan and JSONL |
| `summarize_competitive.py` | Validates complete records and writes summary JSON and LaTeX tables; `--study main|sample_size`, `--plot` |
| `compare_competitive_summaries.py` | Compares official and independent summaries, writes `*_summary_crosscheck.json` |
| `revision29_displays.py` | Vector tables and figures via ReportLab from frozen records; needs the full JSONL |
| `main_empirical_figures.py` | Main-text figures from saved summaries (needs `path_ablation.json` for the path panels) |

## Theory checks

| Script | Role |
|---|---|
| `theory_mcar_experiment.py` | Conditional-theory study on Gaussian MCAR data; `--replay` reuses saved samples |
| `theory_indefinite_experiment.py` | Constructed indefinite quadratics with positive sparse blocks; `--pilot` for a small run |
| `theory_variance_experiment.py` | Monte Carlo check of the corrected-score variance formula |
| `plot_theory_validation.py` | Figure for the MCAR and indefinite checks |
| `plot_score_variance.py` | Figure for the variance identity |

## Sensitivity, ablation and real data

| Script | Role |
|---|---|
| `reviewer_experiments.py` | `unequal` (node-size imbalance) or `calibration` (masked trusted-sample calibration) |
| `no_attack_budget.py` | Paired trimming-budget comparison with no attacks |
| `summarize_no_attack_budget.py` | Summary and table for the no-attack comparison |
| `bridge_experiment.py` | Active-support bridge audit of the endpoint recursion |
| `certificate_experiments.py` | Local-certificate and masked-calibration experiments |
| `path_audit.py` | Path/ablation experiment and truth-assisted endpoint audit |
| `summarize_paths.py` | Path summaries and tables; also uses `plot_validation.draw` |
| `run_revision.py` | Synthetic sensitivity suite and superconductivity real-data experiments |
| `real_revision2.py` | Abalone and grouped superconductivity experiments |
| `summarize_revision2.py` | Summaries for the real-data revision experiments |
| `summarize_reviewer.py` | Summaries for the imbalance and calibration experiments |
| `verify_and_summarize.py` | Implementation checks plus synthetic/real summaries |
| `legacy_simulation.py` | Exploratory fixed-tuning suite documented in the supplement |

## Cost benchmarks

| Script | Role |
|---|---|
| `benchmark_end_to_end.py` | Single-host end-to-end solve cost over pipes |
| `benchmark_matched_cost.py` | Time and payload to reach a target coefficient error, plus memory sampling |
| `benchmark_scaling.py` | Gradient/aggregation microbenchmark across node counts |
| `make_scaling_report.py` | Summary and LaTeX table for the scaling benchmark |
| `make_strengthened_figures.py` | Bridge and cost tables and figures |

## Audits and checks

| Script | Role |
|---|---|
| `audit_competitive_endpoints.py` | Recomputes endpoint quantities and the recursion on selected paths |
| `audit_reference_curvature.py` | Audits the sparse-curvature condition on reference master samples |
| `audit_results.py` | Recomputes reported summaries and compares with stored values |
| `audit_strengthening.py` | Recomputes the strengthening checks |
| `check_competitive_results.py` | Verifies completeness and consistency of the competitive records |
| `check_slard_baseline.py` | Audits the SLARD comparator implementation |
| `check_unequal_sizes.py` | Rechecks unequal-size summaries |
| `check_sampled_curvature.py` | Negative-curvature audit for sampled MCAR designs |
| `check_observable_certificates.py` | Rechecks observable certificate outputs |
| `check_certified_selection.py` | Algebraic certificate check on a constructed quadratic |
| `check_review_theory.py` | Rechecks theoretical quantities used in review diagnostics |

## Utilities

| Script | Role |
|---|---|
| `download_data.py` | Downloads the two UCI archives into `data/` (not needed with the bundled files) |
| `plot_validation.py` | Shared plotting helper used by `summarize_paths.py` |
