"""Audit selection and KKT status against saved experiment records."""
from pathlib import Path
import json,hashlib,platform,sys
import numpy as np,scipy,matplotlib,threadpoolctl
ROOT=Path(__file__).resolve().parents[1]
out={}
for name,count in [('revision_synthetic.json',1260),('revision_real.json',210)]:
 d=json.loads((ROOT/'results'/name).read_text());assert len(d['records'])==count
 successful_candidates=0;failures=0
 for r in d['records']:
  assert len(r['candidates'])==4
  valid=[]
  for c in r['candidates']:
   if c['status']=='ok':
    assert len(c['trace'])==8
    for stage in c['trace']:
     assert stage['status']=='ok'
     assert stage['kkt']<=min(1e-5,stage['lambda_value']/1000)+1e-10
    assert c['val_mse'] is not None and np.isfinite(c['val_mse'])
    successful_candidates+=1;valid.append(c['val_mse'])
  assert r['all_candidates_failed']==(not valid)
  if valid:assert np.isclose(r['val_mse'],min(valid))
  else:failures+=1
 out[name]=dict(records=count,candidate_fits=count*4,successful_candidates=successful_candidates,failed_selections=failures,checks='counts, all successful KKT traces, validation minimum, failure accounting')
raw=ROOT/'data'/'superconductivity.zip'
assert hashlib.sha256(raw.read_bytes()).hexdigest()==json.loads((ROOT/'results/revision_real.json').read_text())['dataset_sha256']
d=json.loads((ROOT/'results/scaling.json').read_text())
assert len(d['records'])==24
assert all(r['payload_bytes']==2*r['m']*r['p']*8*r['rounds'] for r in d['records'])
out['scaling']='24 configurations/repetitions; payload accounting passed'
out['dataset']='SHA-256 verified against experiment metadata'
(ROOT/'results'/'audit.json').write_text(json.dumps(out,indent=2))
blas=threadpoolctl.threadpool_info()
for lib in blas:
 if 'filepath' in lib:lib['filepath']=Path(lib['filepath']).name
env=dict(python=sys.version,platform=platform.platform(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,threadpoolctl=threadpoolctl.__version__,blas=blas)
(ROOT/'results'/'environment.json').write_text(json.dumps(env,indent=2))
print(json.dumps(out))
