"""Audit the zero-filled square-loss SLARD baseline against independent QPs.

Tu, Liu and Mao (2023), Algorithm 1 and equations (11)--(12), specify
the quadratic subproblem; its lambda sequence is an input.  Our benchmark
uses common validation tuning and the existing schedule, not their BIC.
This audit checks that Node(..., q=1) plus Lasso solves those subproblems.
It does not claim to reproduce the original paper's experiments.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from robust_sparse import Node, fit, initial


def independent_lasso(S, c, lam, start):
    """Positive/negative variable splitting, solved with bounded L-BFGS-B."""
    p = len(c)
    def fun(v):
        x = v[:p] - v[p:]
        g = S @ x - c
        return (.5 * x @ (S @ x) - c @ x + lam * v.sum(),
                np.concatenate((g + lam, -g + lam)))
    v0 = np.concatenate((np.maximum(start, 0), np.maximum(-start, 0)))
    result = minimize(fun, v0, jac=True, bounds=[(0, None)] * (2*p),
                      method='L-BFGS-B',
                      options={'ftol': 1e-15, 'gtol': 1e-10,
                               'maxiter': 20000, 'maxls': 60})
    x = result.x[:p] - result.x[p:]
    # Compute the full-coordinate KKT residual independently of core.kkt.
    g = S @ x - c
    residual = np.where(x != 0, np.abs(g + lam*np.sign(x)),
                        np.maximum(np.abs(g) - lam, 0))
    if not result.success or residual.max() > 2e-7:
        raise AssertionError((result.message, residual.max()))
    return x, float(residual.max())


def independent_path(nodes, scale, factor, kind, b, f, seed, rounds=5):
    p, n, m = nodes[0].p, nodes[0].n, len(nodes)
    S = [node.z.T @ node.z / n for node in nodes]
    r = [node.z.T @ node.y / n for node in nodes]
    local = factor * scale * np.sqrt(np.log(p) / n)
    floor = factor * scale * (np.sqrt(np.log(p)/(m*n))
                              + (b/m)*np.sqrt(np.log(p)/n))
    x, residual = independent_lasso(S[0], r[0], local, np.zeros(p))
    out = [{'round': 0, 'coefficient': x.tolist(), 'kkt': residual}]
    for t in range(rounds):
        raw = np.array([a @ x - d for a, d in zip(S, r)])
        if f:
            rng = np.random.default_rng(np.random.SeedSequence([seed,t,761]))
            raw[-f:] = rng.normal(0,20,(f,p))
        # Include the trusted master's report, as in Algorithm 1.
        ordered = np.sort(raw, axis=0)
        if kind == 'median':
            assert m % 2 == 1
            g = ordered[m//2]
        elif kind == 'trim':
            g = ordered[b:m-b].sum(axis=0)/(m-2*b)
        else:
            raise ValueError(kind)
        c = S[0] @ x - g
        lam = max(floor, local * .65**(t+1))
        x, residual = independent_lasso(S[0], c, lam, x)
        out.append({'round': t+1, 'coefficient': x.tolist(),
                    'lambda': float(lam), 'kkt': residual})
    return out


def main():
    checks = []
    for data_seed, corr, qobs in [(2802101, .3, .7), (2802102, .6, .5)]:
        rng = np.random.default_rng(data_seed)
        m, n, p = 7, 160, 8
        truth = np.array([1.2,-.8,0,0,.6,0,0,0])
        C = corr**np.abs(np.subtract.outer(np.arange(p),np.arange(p)))
        L = np.linalg.cholesky(C)
        nodes = []
        for j in range(m):
            x = rng.normal(size=(n,p)) @ L.T
            y = x @ truth + rng.normal(0,.5,n)
            z = x * (rng.uniform(size=x.shape) < qobs)
            # q=1 in the fitting moments denotes zero-filled preprocessing.
            nodes.append(Node(z,y,1.,dense=True))
        for kind in ['median','trim']:
            for f in [0,1]:
                b = 1
                scale, factor, seed = 1.1, .8, data_seed+100
                path = independent_path(nodes,scale,factor,kind,b,f,seed)
                xi,_,ii = initial(nodes[0],scale,factor)
                assert ii['status'] == 'ok'
                differences = [float(np.max(np.abs(xi-path[0]['coefficient'])))]
                core_kkt = [ii['kkt']]
                for t in range(1,6):
                    x,info = fit(nodes,scale,factor,kind,'lasso',b,f,
                                 'gaussian',seed,rounds=t)
                    assert info['status'] == 'ok'
                    differences.append(float(np.max(np.abs(x-path[t]['coefficient']))))
                    core_kkt.append(info['trace'][-1]['kkt'])
                assert max(differences) < 8e-5, differences
                checks.append({'data_seed':data_seed,'observed_probability':qobs,
                               'correlation':corr,'aggregator':kind,'byzantine':f,
                               'trim_budget':b,'nodes_including_master':m,
                               'p':p,'n':n,'rounds':5,
                               'max_abs_coefficient_differences':differences,
                               'core_kkt':core_kkt,
                               'independent_kkt':[r['kkt'] for r in path]})
    result = {'description':'Independent convex-QP audit of square-loss SLARD updates',
              'cases':checks,'all_passed':True,
              'max_abs_coefficient_difference':max(max(c['max_abs_coefficient_differences']) for c in checks),
              'max_independent_kkt':max(max(c['independent_kkt']) for c in checks)}
    out = Path(__file__).resolve().parents[1]/'results'/'slard_baseline_audit.json'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))


if __name__ == '__main__':
    main()
