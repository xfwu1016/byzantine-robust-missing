"""Equal-grid validation benchmark; all failures retained, no oracle tuning."""
import argparse,json,time,zipfile,hashlib,platform
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import Node,fit,initial
ROOT=Path(__file__).resolve().parents[1]
METHODS=[('Mean-SCAD','mean','scad'),('Trim-Lasso','trim','lasso'),('Trim-SCAD','trim','scad'),
 ('Trim-MCP','trim','mcp'),('Median-SCAD','median','scad'),('VRMOM-Lasso','vrmom','lasso'),('VRMOM-SCAD','vrmom','scad')]
GRID=[.3,.6,1.2,2.4]

def clean(o):
 if isinstance(o,dict):return {k:clean(v) for k,v in o.items()}
 if isinstance(o,list):return [clean(v) for v in o]
 if isinstance(o,(np.floating,float)):return float(o) if np.isfinite(o) else None
 if isinstance(o,np.integer):return int(o)
 return o
def save(name,records,**kwargs):
 (ROOT/'results'/name).write_text(json.dumps(clean(dict(records=records,grid=GRID,**kwargs)),indent=2),encoding='utf-8')
def ar(rng,n,p,rho):
 x=rng.normal(size=(n,p))
 for j in range(1,p):x[:,j]=rho*x[:,j-1]+np.sqrt(1-rho*rho)*x[:,j]
 return x
def metrics(x,truth):
 a=np.abs(x)>1e-6;s=truth!=0
 return dict(l2=float(np.linalg.norm(x-truth)),exact=bool(np.array_equal(a,s)),fp=int(np.sum(a&~s)),fn=int(np.sum(~a&s)))
def candidates(nodes,xval,yval,scale,agg,pen,b,f,kind,seed,direction=None):
 opts=[];inits={fac:initial(nodes[0],scale,fac) for fac in GRID}
 for fac in GRID:
  start=time.perf_counter()
  x,info=fit(nodes,scale,fac,agg,pen,b,f,kind,seed,direction=direction,init=inits[fac])
  val=float(np.mean((yval-xval@x)**2)) if info['status']=='ok' else float('inf')
  opts.append((val,x,dict(factor=fac,val_mse=val,seconds=time.perf_counter()-start,**info)))
 best=min(range(len(opts)),key=lambda j:opts[j][0]);val,x,info=opts[best]
 return x,dict(info,candidates=[z[2] for z in opts],all_candidates_failed=not np.isfinite(val))

def synthetic(reps):
 configs=[dict(label='reference',q=.7,rho=.3,n=120,alpha=.1,beta=.1,kind='gaussian'),
 dict(label='high_missing',q=.3,rho=.3,n=120,alpha=.1,beta=.1,kind='gaussian'),
 dict(label='correlated',q=.7,rho=.9,n=120,alpha=.1,beta=.1,kind='gaussian'),
 dict(label='stealth',q=.7,rho=.3,n=120,alpha=.2,beta=.2,kind='stealth'),
 dict(label='undertrim',q=.7,rho=.3,n=120,alpha=.2,beta=.1,kind='gaussian'),
 dict(label='clean',q=.7,rho=.3,n=120,alpha=0.,beta=0.,kind='none')]
 records=[];p=240;m=20;t0=time.time()
 for ci,cf in enumerate(configs):
  for rep in range(reps):
   seed=20268008+10000*ci+rep;rng=np.random.default_rng(seed);truth=np.zeros(p)
   truth[[0,60,120,180]]=[1.2,-1.2,1.2,-1.2];nodes=[]
   for _ in range(m):
    x=ar(rng,cf['n'],p,cf['rho']);y=x@truth+rng.normal(size=cf['n'])
    nodes.append(Node(x*(rng.random(x.shape)<cf['q']),y,cf['q'],dense=True))
   xv=ar(rng,400,p,cf['rho']);yv=xv@truth+rng.normal(size=400)
   xt=ar(rng,2000,p,cf['rho']);yt=xt@truth+rng.normal(size=2000)
   direction=np.sign(truth);direction[[3,63,123,183]]=-1
   # q^-1 is a heuristic grid scale, not an estimate of the theorem envelope.
   scale=np.std(nodes[0].y,ddof=1)/cf['q']
   for name,agg,pen in METHODS:
    x,info=candidates(nodes,xv,yv,scale,agg,pen,round(cf['beta']*m),round(cf['alpha']*m),cf['kind'],seed,direction)
    records.append(dict(config=cf['label'],rep=rep,seed=seed,method=name,**info,**metrics(x,truth),test_mse=float(np.mean((yt-xt@x)**2))))
  print('Synthetic',cf['label'],reps,'elapsed',round(time.time()-t0,1),flush=True)
  save('revision_synthetic.json',records,configs=configs,repeats=reps,m=m,p=p,validation_n=400,test_n=2000)

def real(reps,data_path):
 raw=Path(data_path).read_bytes();datahash=hashlib.sha256(raw).hexdigest()
 with zipfile.ZipFile(data_path) as z:
  import io
  a=np.loadtxt(io.BytesIO(z.read('train.csv')),delimiter=',',skiprows=1)
 records=[];m=20;q=.7;t0=time.time()
 for rep in range(reps):
  seed=20269008+rep;rng=np.random.default_rng(seed);ids=rng.permutation(len(a))
  train=a[ids[:14000]];val=a[ids[14000:17000]];test=a[ids[17000:]]
  # Training-only complete covariates define a controlled preprocessing benchmark.
  # This additional access is disclosed; no test data are used for scaling.
  mu=train[:,:-1].mean(0);sd=train[:,:-1].std(0);sd[sd==0]=1
  my=train[:,-1].mean();sy=train[:,-1].std()
  x=(train[:,:-1]-mu)/sd;y=(train[:,-1]-my)/sy
  xv=(val[:,:-1]-mu)/sd;yv=(val[:,-1]-my)/sy;xt=(test[:,:-1]-mu)/sd
  nodes=[]
  for j in range(m):
   z=x[j*700:(j+1)*700]*(rng.random((700,81))<q)
   nodes.append(Node(z,y[j*700:(j+1)*700],q,dense=True))
  for kind,f,b in [('none',0,0),('gaussian',2,2),('stealth',4,4)]:
   for name,agg,pen in METHODS:
    coef,info=candidates(nodes,xv,yv,np.std(nodes[0].y,ddof=1)/q,agg,pen,b,f,kind,seed)
    mse=float(np.mean((test[:,-1]-(my+sy*(xt@coef)))**2))
    records.append(dict(rep=rep,seed=seed,attack=kind,method=name,**info,test_rmse=float(np.sqrt(mse)),
      selected=int(np.sum(np.abs(coef)>1e-6)),constant_rmse=float(np.sqrt(np.mean((test[:,-1]-my)**2)))))
  print('UCI split',rep+1,'elapsed',round(time.time()-t0,1),flush=True)
  save('revision_real.json',records,repeats=reps,q=q,m=m,train_n=14000,val_n=3000,test_n=len(test),
       dataset_sha256=datahash,dataset='UCI 464, DOI 10.24432/C53P47',notes='Artificial MCAR after training-only scaling; complete trusted validation and test covariates; no support ground truth.')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--synthetic-repeats',type=int,default=30);ap.add_argument('--real-repeats',type=int,default=10)
 ap.add_argument('--data',default=str(ROOT/'data'/'superconductivity.zip'));args=ap.parse_args()
 with threadpool_limits(limits=1):
  if args.synthetic_repeats:synthetic(args.synthetic_repeats)
  if args.real_repeats:real(args.real_repeats,args.data)
