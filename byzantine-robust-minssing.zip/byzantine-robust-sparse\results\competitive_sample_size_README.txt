Independent sample-size follow-up

This experiment was designed after inspecting the fixed-local-sample-size
benchmark. It is an explicitly disclosed follow-up, not part of the original
23-configuration plan. The primary results, including every unfavorable
case, remain unchanged. The new plan was frozen before any of the new seeds
were generated; competitive_sample_size_plan.json records this chronology.

The allocation is n=ceil(512*(0.7/q)^2), giving n=512,1004,2788 at q=0.7,0.5,0.3.
It keeps n*q^2 approximately constant as a variance-motivated allocation.
It is not a claim that q^-2 is an exact or optimal sample-complexity rate.
All three allocations are evaluated under Gaussian and in-range attacks,
with m=12, p=256, rho=0.6, the same six clustered coefficients, and f=b=2.
The nine methods, seven factors, eight rounds, stopping rules and validation
selection are exactly those of the frozen primary benchmark. No allocation
or tuning change is made in response to follow-up outcomes.

Thirty new seeds, 28031001--28031030, are used in every configuration. Methods
share data within a configuration. Gaussian and in-range attacks at the
same n,q use the same observations, masks and validation/test samples.
Different n values enter different data-generator streams, so the samples
are not nested across q. The new seeds are disjoint from both primary and
pilot seeds. All 6*30*9=1620 method outcomes and 11340 candidates are retained.

Run from the package root in a separate reproduction copy:
  python code/competitive_sample_size.py

If the plan already exists, or to continue an interrupted run:
  python code/competitive_sample_size.py --resume

To write the plan without generating observations, append --plan-only.
The distributed primary plan must remain present: its hash is recorded in
the follow-up plan. Resume strictly verifies the follow-up script, imported
benchmark source, solver, primary plan and all policy fields. The script
reuses competitive_benchmark.make_data and fit_method without modifying
the primary source or records.

The output competitive_sample_size.jsonl has the same schema as the primary
JSONL, with mode="sample_size" and labels ss_q0.7_gaussian/stealth,
ss_q0.5_gaussian/stealth and ss_q0.3_gaussian/stealth. Timing includes candidate
initialization, fitting and validation but excludes moment construction;
message counts remain theoretical vector payloads. All costs are reported
alongside the larger allocations. See competitive_README.txt for full field,
failure, baseline and reproducibility definitions.
