"""Fresh Monte Carlo check of the MCAR score-variance identity.

All prespecified replications are retained; no fitting or selection is involved.
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, hashlib, time, platform
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
PLAN=dict(experiment="MCAR score variance",correlations=[0.0,0.5],q_values=[0.2,0.3,0.5,0.7,0.9,1.0],replications=30,n=50000,p=3,theta=[0.7,2**-0.5,-2**-0.5],noise_sd=1.0,coordinate=0,seed_base=2710213000,selection="none; all replications retained",pairing="Within each repetition, latent covariates, noise and mask uniforms are shared across q and correlation settings.")
def main():
 out=ROOT/'results';(out/'theory_variance_plan.json').write_text(json.dumps(PLAN,indent=2),encoding='utf-8')
 start=time.time();rows=[];theta=np.array(PLAN['theta']);maxdiff=0.
 for rep in range(PLAN['replications']):
  rng=np.random.default_rng(PLAN['seed_base']+rep)
  base=rng.standard_normal((PLAN['n'],3));eps=rng.standard_normal(PLAN['n']);unif=rng.random(base.shape)
  for corr in PLAN['correlations']:
   S=corr**np.abs(np.arange(3)[:,None]-np.arange(3)[None,:]);X=base@np.linalg.cholesky(S).T;y=X@theta+eps
   fourth=np.array([S[0,0]*S[k,k]+2*S[0,k]**2 for k in (1,2)])
   energy=float((theta[1:]**2)@fourth)
   for q in PLAN['q_values']:
    mask=unif<q;z=mask*X
    noise=-X[:,0]*mask[:,0]*eps/q
    missing=mask[:,0]*X[:,0]/q*np.sum((mask[:,1:]/q-1)*X[:,1:]*theta[1:],axis=1)
    phi=z[:,0]*(z@theta)/q**2-(1-q)*z[:,0]**2*theta[0]/q**2-z[:,0]*y/q
    discrepancy=float(np.max(np.abs(phi-noise-missing)));maxdiff=max(maxdiff,discrepancy)
    assert discrepancy<1e-10
    empirical=dict(total=float(np.var(phi,ddof=1)),noise=float(np.var(noise,ddof=1)),missing=float(np.var(missing,ddof=1)))
    theoretical=dict(noise=1/q,missing=(1-q)*energy/q**2);theoretical['total']=sum(theoretical.values())
    rows.append(dict(rep=rep,seed=PLAN['seed_base']+rep,correlation=corr,q=q,n=PLAN['n'],empirical=empirical,theoretical=theoretical,score_mean=float(np.mean(phi)),identity_max_error=discrepancy))
 summary=[]
 for corr in PLAN['correlations']:
  for q in PLAN['q_values']:
   group=[r for r in rows if r['correlation']==corr and r['q']==q]
   stats={}
   for key in ('total','noise','missing'):
    values=np.array([r['empirical'][key] for r in group]);truth=group[0]['theoretical'][key]
    stats[key]=dict(mean=float(values.mean()),se=float(values.std(ddof=1)/np.sqrt(len(values))),theory=truth,relative_error=float(values.mean()/truth-1) if truth else None)
   summary.append(dict(correlation=corr,q=q,n=PLAN['n'],replications=len(group),statistics=stats))
 result=dict(plan=PLAN,records=rows,summary=summary,checks=dict(all_replications_retained=len(rows)==360,max_score_identity_discrepancy=maxdiff),environment=dict(python=platform.python_version(),numpy=np.__version__),elapsed_seconds=time.time()-start)
 (out/'theory_variance.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(dict(records=len(rows),elapsed=result['elapsed_seconds'],largest_total_relative_error=max(abs(r['statistics']['total']['relative_error']) for r in summary),max_identity_discrepancy=maxdiff),indent=2))
if __name__=='__main__':main()
