import json,itertools
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from robust_sparse import Node,aggregate,envelope_fit
R=Path(__file__).resolve().parents[1]
def run_checks():
 rng=np.random.default_rng(23);z=rng.normal(size=(150,80))*(rng.random((150,80))<.7);y=rng.normal(size=150)
 a=Node(z,y,.7);b=Node(z,y,.7,True);v=rng.normal(size=80)
 assert np.allclose(a.mv(v),b.mv(v),atol=1e-12)
 assert np.allclose(a.grad(v),b.grad(v),atol=1e-12)
 raw=z*(z@v-y*.7)[:,None]/.7**2-.3*z*z*v/.7**2
 assert np.allclose(raw.mean(0),a.grad(v))
 msgs=rng.normal(size=(20,80));sd=np.ones(80)
 assert np.allclose(aggregate(msgs,'trim',0),aggregate(msgs,'mean'))
 # VRMOM translation equivariance and constant-message limit.
 assert np.allclose(aggregate(msgs+3,'vrmom',2,sd,150),aggregate(msgs,'vrmom',2,sd,150)+3)
 assert np.allclose(aggregate(np.ones((20,80)),'vrmom',2,sd,150),1)
 class Quadratic:
  def __init__(self):
   self.p=4000;self.diag=np.full(self.p,1-1.2/self.p);self.gamma=self.mv(truth)-score
  def mv(self,x):return x-1.2*np.sum(x)/self.p
  def grad(self,x):return self.mv(x)-self.gamma
 truth=np.zeros(4000);truth[:2]=[1.2,-1.2];score=np.linspace(-.001,.001,4000)
 nodes=[Quadratic() for _ in range(10)]
 x,info=envelope_fit(nodes,.002,.005,2.,.98,1.,2,rounds=6,b=1,f=1,attack_kind='gaussian')
 assert info['status']=='ok' and all(t['max_support']<=info['K'] for t in info['trace'])
 assert np.linalg.norm(x-truth)<=info['trace'][-1]['radius']
 assert 1-1.2*4*info['K']/4000>=.98
 out=dict(matrix_free_equivalence='pass',individual_score_identity='pass',vrmom_checks='pass',
  envelope_example=info,example_error=float(np.linalg.norm(x-truth)),example_global_min_eigen=-.2,
  caution='Constructed quadratic certificate is not a certification of empirical MCAR datasets.')
 (R/'results'/'implementation_checks.json').write_text(json.dumps(out,indent=2))

def summarize():
 summaries={}
 for filename,group,metric in [('revision_synthetic.json','config','l2'),('revision_real.json','attack','test_rmse')]:
  d=json.loads((R/'results'/filename).read_text());rows=[]
  for cfg in dict.fromkeys(x[group] for x in d['records']):
   for method in dict.fromkeys(x['method'] for x in d['records']):
    a=[x for x in d['records'] if x[group]==cfg and x['method']==method];good=[x for x in a if not x['all_candidates_failed']]
    vals=[x[metric] for x in good]
    for x in a:
     valid=[v['val_mse'] for v in x['candidates'] if v['status']=='ok']
     if valid:assert np.isclose(x['val_mse'],min(valid))
    row=dict(config=cfg,method=method,N=len(a),success=len(good),metric=metric,
      mean=float(np.mean(vals)) if vals else None,se=float(np.std(vals,ddof=1)/np.sqrt(len(vals))) if len(vals)>1 else None,
      exact=sum(x.get('exact',False) and not x['all_candidates_failed'] for x in a)/len(a) if metric=='l2' else None)
    if metric=='test_rmse':row['constant_rmse']=float(np.mean([x['constant_rmse'] for x in a]))
    rows.append(row)
  summaries[filename]=rows
 (R/'results'/'revision_summary.json').write_text(json.dumps(summaries,indent=2))
 plt.rcParams.update({'font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
 syn=summaries['revision_synthetic.json'];configs=list(dict.fromkeys(x['config'] for x in syn))
 fig,ax=plt.subplots(1,2,figsize=(7.1,2.65))
 methods=['Trim-Lasso','Trim-SCAD','Trim-MCP','Median-SCAD','VRMOM-SCAD']
 for mi,method in enumerate(methods):
  a=[x for x in syn if x['method']==method];pos=np.arange(len(a))+(mi-2)*.11
  ax[0].errorbar(pos,[x['mean'] if x['mean'] is not None else np.nan for x in a],yerr=[x['se'] or 0 for x in a],fmt='o',markersize=3,label=method)
  ax[1].plot(pos,[x['exact'] for x in a],'o',markersize=3)
 for aa in ax:aa.set_xticks(range(len(configs)),configs,rotation=35,ha='right');aa.grid(axis='y',alpha=.2)
 ax[0].set_ylabel('L2 error (successful selections)');ax[1].set_ylabel('Exact support / all repetitions');ax[1].set_ylim(-.05,1.05)
 fig.legend(loc='upper center',ncol=5,fontsize=7);fig.tight_layout(rect=[0,0,1,.91]);fig.savefig(R/'figures'/'validation_benchmark.pdf');fig.savefig(R/'figures'/'validation_benchmark.png',dpi=180);plt.close(fig)
 # TeX tables used verbatim by manuscript generation.
 for key,rows in summaries.items():
  lines=[]
  for x in rows:
   val='--' if x['mean'] is None else f"{x['mean']:.3f} $\\pm$ {x['se'] or 0:.3f}"
   extra=f"{100*x['exact']:.0f}\\%" if x['exact'] is not None else '--'
   lines.append(f"{x['config'].replace('_',' ')} & {x['method']} & {x['success']}/{x['N']} & {val} & {extra} \\\\")
  (R/'results'/key.replace('.json','.tex')).write_text('\n'.join(lines))
 for rows in summaries.values():
  for row in rows:print(row)
if __name__=='__main__':
 with threadpool_limits(limits=1):run_checks();summarize()
