# Bundled fonts

`DejaVuSans.ttf` and `DejaVuSans-Bold.ttf` are bundled so that
`revision29_displays.py` produces identical vector artwork on machines without
Arial. They are taken from the DejaVu font family (version shipped with
TeX Live 2024) and are distributed under the DejaVu licence; see
`LICENSE-DejaVu.txt` in this directory. When Arial is installed it is used
instead, matching the original Windows build.

`revision29_displays.py` prefers, in order: Windows Arial, macOS Arial, system
DejaVu (common on Linux), then the bundled files.
