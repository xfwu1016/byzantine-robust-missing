"""Single-host multiprocessing gradient/aggregation microbenchmark.
Not a multi-machine network experiment and not full solver timing.
"""
import os,time,json,platform,multiprocessing as mp
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from robust_sparse import Node,aggregate,soft
ROOT=Path(__file__).resolve().parents[1]
def worker(conn,n,p,seed):
 with threadpool_limits(limits=1):
  rng=np.random.default_rng(seed);x=rng.normal(size=(n,p));truth=np.zeros(p);truth[:4]=[1.2,-1.2,1.2,-1.2]
  y=x@truth+rng.normal(size=n);x*=rng.random(x.shape)<.7
  node=Node(x,y,.7);conn.send_bytes(b'ready')
  while True:
   buf=conn.recv_bytes()
   if not buf:break
   u=np.frombuffer(buf,dtype=np.float64);conn.send_bytes(node.grad(u).tobytes())
 conn.close()
def run(m,n,p,rep,rounds=20):
 ctx=mp.get_context('spawn');workers=[];conns=[];t0=time.perf_counter()
 for j in range(m):
  parent,child=ctx.Pipe();proc=ctx.Process(target=worker,args=(child,n,p,20271008+rep*100+j))
  proc.start();child.close();workers.append(proc);conns.append(parent)
 for c in conns:assert c.recv_bytes()==b'ready'
 setup=time.perf_counter()-t0;u=np.zeros(p);lat=[];aggtime=[];payload=0
 try:
  # Warmup excluded, then time the actual send_bytes / recv_bytes transport.
  for t in range(rounds+1):
   start=time.perf_counter();buf=u.tobytes()
   for c in conns:c.send_bytes(buf)
   received=[c.recv_bytes() for c in conns]
   a=time.perf_counter();messages=np.array([np.frombuffer(z,dtype=np.float64) for z in received])
   if m>=8:messages[-max(1,m//10):]=20
   g=aggregate(messages,'trim',max(1,m//10));u=soft(u-.02*g,.02*.2)
   stop=time.perf_counter()
   if t:
    lat.append(stop-start);aggtime.append(stop-a);payload+=m*len(buf)+sum(map(len,received))
 finally:
  for c in conns:c.send_bytes(b'');c.close()
  for proc in workers:proc.join(timeout=30);assert proc.exitcode==0
 return dict(m=m,n=n,p=p,rep=rep,rounds=rounds,setup_seconds=setup,
  mean_round_seconds=float(np.mean(lat)),median_round_seconds=float(np.median(lat)),
  mean_aggregation_update_seconds=float(np.mean(aggtime)),payload_bytes=payload,
  expected_payload_bytes=2*m*p*8*rounds,raw_design_bytes=m*n*p*8,dense_gram_bytes=m*p*p*8,
  notes='Float64 payload only; excludes Pipe framing, setup, OS scheduling and control messages from byte count. Latency includes IPC, worker gradients, aggregation and one update, not inner optimization.')
if __name__=='__main__':
 configs=[('dimension',8,256,1000),('dimension',8,256,4000),('dimension',8,256,10000),
 ('weak',4,256,4000),('weak',16,256,4000),('strong',4,1024,4000),('strong',8,512,4000),('strong',16,256,4000)]
 records=[]
 for label,m,n,p in configs:
  for rep in range(3):
   r=run(m,n,p,rep);r['axis']=label;assert r['payload_bytes']==r['expected_payload_bytes'];records.append(r)
  print(label,m,n,p,flush=True)
  (ROOT/'results'/'scaling.json').write_text(json.dumps(dict(records=records,platform=platform.platform(),processor=platform.processor(),logical_cpus=os.cpu_count(),single_host=True),indent=2))
