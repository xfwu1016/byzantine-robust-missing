"""Independent, explicitly post-primary-study sample-size follow-up.

The fixed-n study remains intact. This script fixes n=ceil(512*(.7/q)^2)
before generating new seeds and reuses the frozen benchmark fitting policy.
It tests a variance-motivated sample allocation, not an optimal-rate claim.
"""
import argparse
import hashlib
import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path
import competitive_benchmark as benchmark

ROOT = Path(__file__).resolve().parents[1]


def configurations():
    reference = next(c for c in benchmark.configurations() if c['label'] == 'q0.7_f2_gaussian')
    result = []
    for q in [.7, .5, .3]:
        n = math.ceil(512*(.7/q)**2)
        for attack in ['gaussian', 'stealth']:
            result.append(dict(reference, label=f'ss_q{q:.1f}_{attack}', q=q, n=n, attack=attack))
    return result


def make_plan():
    plan = benchmark.make_plan('full', 30)
    plan.update(
        created_utc=datetime.now(timezone.utc).isoformat(), mode='sample_size',
        configurations=configurations(), seeds=list(range(28031001, 28031031)),
        purpose='Independent sample-size follow-up after inspection of the fixed-n results',
        design_trigger='The fixed-n results suggested a bias-variance tradeoff under heavier missingness. This follow-up was designed after inspecting those results; it does not replace or alter any primary-study outcomes.',
        sample_size_rule='n=ceil(512*(0.7/q)^2), fixed at 512, 1004, 2788 for q=0.7, 0.5, 0.3',
        sample_size_rationale='Variance-motivated inverse-square allocation; no further n/grid changes based on follow-up outcomes, and no claim of optimal or exact sample-complexity scaling',
        pairing='Methods share data, masks, validation and test within each configuration; Gaussian and stealth attacks share data at the same q and n. Different n values use different streams, so data are not nested across q.',
        primary_plan_sha256=hashlib.sha256((ROOT/'results'/'competitive_full_plan.json').read_bytes()).hexdigest(),
        benchmark_source_sha256=hashlib.sha256(Path(benchmark.__file__).read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    return plan


def run(resume=False, plan_only=False):
    results = ROOT/'results'
    plan_path = results/'competitive_sample_size_plan.json'
    output = results/'competitive_sample_size.jsonl'
    if plan_path.exists():
        if not resume:
            raise FileExistsError(f'{plan_path}: use --resume to continue the fixed plan')
        plan = json.loads(plan_path.read_text(encoding='utf-8'))
        expected = make_plan()
        for key in expected:
            if key != 'created_utc':
                assert plan[key] == expected[key], f'Frozen follow-up protocol changed: {key}'
    else:
        plan = make_plan()
        plan_path.write_text(json.dumps(plan, indent=2), encoding='utf-8')
    if plan_only:
        print('Frozen plan written:', plan_path, flush=True)
        return
    done = set()
    if output.exists():
        for line in output.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            done.add((row['configuration']['label'], row['seed'], row['method']))
    start_all = time.perf_counter()
    with output.open('a', encoding='utf-8') as stream:
        for ci, cf in enumerate(plan['configurations']):
            configuration_start = time.perf_counter()
            for rep, seed in enumerate(plan['seeds']):
                if all((cf['label'], seed, met[0]) in done for met in benchmark.METHODS):
                    continue
                dataset = benchmark.make_data(cf, seed)
                order = benchmark.np.random.default_rng(
                    benchmark.np.random.SeedSequence([seed, ci, 8173])).permutation(len(benchmark.METHODS))
                for order_index, mi in enumerate(order):
                    method = benchmark.METHODS[mi]
                    if (cf['label'], seed, method[0]) in done:
                        continue
                    record = benchmark.fit_method(cf, seed, method, dataset)
                    row = dict(mode='sample_size', configuration=cf, rep=rep, seed=seed,
                               execution_order=order_index, dataset=dataset[-1], **record)
                    stream.write(json.dumps(benchmark.clean(row), separators=(',', ':'))+'\n')
                    stream.flush()
            print(json.dumps(dict(mode='sample_size', configuration=cf['label'], repeats=30,
                                  seconds=round(time.perf_counter()-configuration_start, 2),
                                  elapsed_seconds=round(time.perf_counter()-start_all, 2))), flush=True)
    print('Finished', output, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    with benchmark.threadpool_limits(limits=1):
        run(args.resume, args.plan_only)
