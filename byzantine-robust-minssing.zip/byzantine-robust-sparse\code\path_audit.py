"""Path/ablation experiment and truth-assisted support-local theorem audit.

Truth is used only for saved diagnostics; it never changes fitting or selection.
The core solver is unchanged. The traced implementation is checked against it.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time,argparse,platform,sys
from pathlib import Path
import numpy as np
import scipy
from threadpoolctl import threadpool_limits
from robust_sparse import Node,soft,kkt,penalty_weights,attack,aggregate,fit
from certificates import local_certificate
ROOT=Path(__file__).resolve().parents[1]
GRID=[.3,.6,1.2,2.4]
MODES=['Full','NoCorrection','DirectTarget','StageRefresh','Lasso','VRMOM']
CONFIGS=[dict(name='reference',n=256,q=.7,corr=.3,attack='gaussian'),
 dict(name='larger_master',n=512,q=.7,corr=.3,attack='gaussian'),
 dict(name='more_missing',n=256,q=.5,corr=.3,attack='gaussian'),
 dict(name='correlated',n=256,q=.7,corr=.7,attack='gaussian'),
 dict(name='signflip',n=256,q=.7,corr=.3,attack='signflip'),
 dict(name='clustered_signals',n=256,q=.7,corr=.7,attack='gaussian')]

def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
 if isinstance(x,np.integer):return int(x)
 if isinstance(x,np.bool_):return bool(x)
 return x

def ar(rng,n,p,corr):
 x=rng.normal(size=(n,p))
 for j in range(1,p):x[:,j]=corr*x[:,j-1]+np.sqrt(1-corr*corr)*x[:,j]
 return x

def make(cf,rep,p=768):
 seed=202610101+1000*CONFIGS.index(cf)+rep;rng=np.random.default_rng(seed)
 truth=np.zeros(p);inds=np.arange(4) if cf['name']=='clustered_signals' else np.arange(4)*(p//4)
 truth[inds]=[1.2,-1.2,1.2,-1.2]
 nodes=[];naive=[]
 for j in range(8):
  x=ar(rng,cf['n'],p,cf['corr']);y=x@truth+rng.normal(scale=.5,size=cf['n'])
  z=x*(rng.random(x.shape)<cf['q']);node=Node(z,y,cf['q'],dense=True);nodes.append(node)
  # Reuse the same zero-filled observations; q=1 omits all moment corrections.
  nn=Node(z,y,1.,dense=False);nn.gram=cf['q']**2*node.gram+(1-cf['q'])*cf['q']*np.diag(node.diag);naive.append(nn)
 xv=ar(rng,400,p,cf['corr']);yv=xv@truth+rng.normal(scale=.5,size=400)
 return seed,truth,nodes,naive,xv,yv

def traced_stage(node,c,w,x,tol,truth):
 x=x.copy();g=node.mv(x)-c;lip=max(float(node.diag.max()),.1);hist=[];maxsupp=int(np.count_nonzero(x))
 for it in range(1201):
  r=kkt(g,x,w);hist.append(dict(l2=float(np.linalg.norm(x-truth)),support=int(np.count_nonzero(x)),kkt=r))
  if r<=tol:return x,dict(status='ok',iterations=it,kkt=r,max_support=maxsupp),hist
  if it>=1200:break
  for _ in range(50):
   trial=soft(x-g/lip,w/lip);d=trial-x;gd=node.mv(d)
   if d@gd<=lip*(d@d)+1e-12:break
   lip*=2
  else:return x,dict(status='line_search_failed',iterations=it,kkt=r,max_support=maxsupp),hist
  x=trial;g+=gd;maxsupp=max(maxsupp,int(np.count_nonzero(x)))
  if not np.isfinite(x).all() or np.linalg.norm(x)>1e4:return x,dict(status='diverged',iterations=it+1,kkt=None,max_support=maxsupp),hist
  lip=max(.1,lip/1.05)
 return x,dict(status='max_iter',iterations=1200,kkt=r,max_support=maxsupp),hist

def traced_hom(node,c,x,w,base,target,truth,mode):
 lam=target if mode=='DirectTarget' else base;hist=[];total=0;maximum=int(np.count_nonzero(x));stages=0
 while True:
  final=lam<=target*(1+1e-12);tol=min(1e-5,target/1000) if final else lam/26
  if mode=='StageRefresh':w=penalty_weights(x,base,'scad')
  used=w*(lam/base)
  x,info,hh=traced_stage(node,c,used,x,tol,truth)
  hist.extend([dict(z,stage=stages,level=lam) for z in hh]);total+=info['iterations'];maximum=max(maximum,info['max_support']);stages+=1
  if final or info['status']!='ok':return x,dict(info,iterations=total,max_support=maximum,stages=stages),hist,used
  lam=max(target,lam*(12/13))

def endpoint_audit(nodes,truth,prev,x,c,w,b=1,f=1):
 # No audit quantity is passed back to the solver or validation selector.
 S=np.flatnonzero(truth);U=np.union1d(S,np.flatnonzero(x));W=np.union1d(S,np.flatnonzero(prev));r=len(U)
 hon=nodes[:-f];G=np.mean([j.gram for j in hon],axis=0)
 scores=np.array([j.grad(truth)[U] for j in hon]);mean=scores.mean(0)
 a=float(np.max(np.abs(mean)));tau=float(np.max(np.abs(scores-mean)))
 kap=float(np.linalg.eigvalsh(nodes[0].gram[np.ix_(U,U)])[0]);om=3*b/(len(nodes)-2*b)
 D=[j.gram[np.ix_(U,W)]-G[np.ix_(U,W)] for j in hon]
 d=max(float(np.linalg.norm(z,axis=1).max()) for z in D)
 mismatch=float(np.linalg.norm(D[0],ord=2));eps=kkt(nodes[0].mv(x)-c,x,w)
 if kap>0:
  eta=(mismatch+om*np.sqrt(r)*d)/kap
  floor=(np.sqrt(r)*(a+om*tau+eps)+np.linalg.norm(w[U]))/kap
  rhs=eta*np.linalg.norm(prev-truth)+floor
  assert np.linalg.norm(x-truth)<=rhs+1e-8
 else:eta=floor=rhs=None
 return dict(curvature=kap,support_union=r,previous_union=len(W),eta=eta,offset=floor,one_step_bound=rhs,
  actual_error=float(np.linalg.norm(x-truth)),previous_error=float(np.linalg.norm(prev-truth)),residual=eps,
  local=local_certificate(nodes[0],c,w,x))

def solve(nodes,truth,mode,factor,seed,kind):
 master=nodes[0];p=master.p;m=len(nodes);scale=np.std(master.y,ddof=1)/(nodes[0].q if mode!='NoCorrection' else 1.)
 # For NoCorrection, q=1 is also its own natural tuning scale; common factors/grid.
 local=factor*scale*np.sqrt(np.log(p)/master.n);base=max(local,np.abs(master.gamma).max())
 x,ini,ih,_=traced_hom(master,master.gamma,np.zeros(p),np.full(p,base),base,local,truth,'Full')
 initial=dict(ini,l2=float(np.linalg.norm(x-truth)));path=[dict(z,round=0) for z in ih];rounds=[]
 if ini['status']!='ok':return x,dict(status='initial_failed',initial=initial,path=path,rounds=rounds)
 floor=factor*scale*(np.sqrt(np.log(p)/(m*master.n))+(1/m)*np.sqrt(np.log(p)/master.n))
 for t in range(8):
  prev=x.copy();raw=np.array([j.grad(x) for j in nodes]);sent=attack(raw,1,kind,t,seed)
  agg='vrmom' if mode=='VRMOM' else 'trim';pen='lasso' if mode=='Lasso' else 'scad'
  g=aggregate(sent,agg,1,master.score_sd(x) if agg=='vrmom' else None,master.n);c=master.mv(x)-g
  target=max(floor,local*.65**(t+1));base=max(target,local*.65**t)
  x,info,hh,w=traced_hom(master,c,x,penalty_weights(x,base,pen),base,target,truth,mode)
  path.extend([dict(z,round=t+1) for z in hh]);rec=dict(info,l2=float(np.linalg.norm(x-truth)),target=target,support=int(np.count_nonzero(x)))
  if mode=='Full' and info['status']=='ok':rec['audit']=endpoint_audit(nodes,truth,prev,x,c,w)
  rounds.append(rec)
  if info['status']!='ok':break
 return x,dict(status=info['status'],initial=initial,path=path,rounds=rounds)

def run(reps,pilot=False,append_clustered=False):
 records=json.loads((ROOT/'results/path_ablation.json').read_text())['records'] if append_clustered else []
 start=time.time()
 for cf in (CONFIGS[-1:] if append_clustered else CONFIGS[:1] if pilot else CONFIGS):
  for rep in range(reps):
   seed,truth,nodes,naive,xv,yv=make(cf,rep)
   for mode in (['Full'] if pilot else MODES):
    opts=[]
    for factor in GRID:
     ns=naive if mode=='NoCorrection' else nodes
     x,info=solve(ns,truth,mode,factor,seed,cf['attack'])
     if pilot:
      expected,ei=fit(nodes,np.std(nodes[0].y,ddof=1)/cf['q'],factor,'trim','scad',1,1,cf['attack'],seed)
      assert np.allclose(x,expected,atol=1e-10,rtol=1e-10),(factor,np.linalg.norm(x-expected))
      assert info['status']==ei['status']
     val=float(np.mean((yv-xv@x)**2)) if info['status']=='ok' else None
     opts.append(dict(info,factor=factor,val=val,l2=float(np.linalg.norm(x-truth)),exact=bool(np.array_equal(np.abs(x)>1e-6,truth!=0))))
    ids=[j for j,z in enumerate(opts) if z['val'] is not None];idx=min(ids,key=lambda j:opts[j]['val']) if ids else None
    rec=dict(config=cf['name'],rep=rep,seed=seed,method=mode,selected_index=idx,candidates=opts)
    if idx is not None:rec['selected']=opts[idx]
    records.append(rec)
   print(cf['name'],rep+1,'elapsed',round(time.time()-start,1),flush=True)
   if pilot:
    z=records[-1].get('selected',{});print('pilot full l2',z.get('l2'),'eta',[round(a['audit']['eta'],3) if a.get('audit',{}).get('eta') else None for a in z.get('rounds',[])],flush=True)
   name='path_pilot.json' if pilot else 'path_ablation.json'
   (ROOT/'results'/name).write_text(json.dumps(clean(dict(records=records,configs=CONFIGS,p=768,m=8,b=1,f=1,s=4,repeats=reps,grid=GRID,validation_n=400,noise_sd=.5,rounds=8,environment=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform()),notes='Endpoint audits use truth and honest labels only after fitting; not deployable certificates. Dense moments accelerate these statistical experiments; runtime claims use the separate matrix-free benchmark.')),indent=1),encoding='utf-8')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--reps',type=int,default=10);ap.add_argument('--pilot',action='store_true');ap.add_argument('--append-clustered',action='store_true');args=ap.parse_args()
 with threadpool_limits(limits=1):run(args.reps,args.pilot,args.append_clustered)
