Revision 28 competitive benchmark

The fixed full-study protocol is competitive_full_plan.json. The original
six-case pilot (three configurations, two independent seeds each) remains in
competitive_pilot_plan.json and competitive_pilot.jsonl. Pilot seeds are
28011001--28011002; full-study seeds are 28021001--28021030. All 23 full-study
configurations and all nine methods were fixed before full-study outcomes.

Reproduction from the package root, in a separate working copy:
  python code/competitive_benchmark.py --mode pilot --repeats 2
  python code/competitive_benchmark.py --mode full --repeats 30

The commands intentionally refuse to overwrite existing plans. To reproduce
from the beginning, use a separate copy without the corresponding generated
competitive_<mode>_plan.json and competitive_<mode>.jsonl, preserving the
distributed records as the reference. To continue an interrupted run with
the same source and protocol, append --resume. Resume verifies the solver
and benchmark source hashes, all configurations and seeds, method list,
factor grid, iteration policies, selection rule and reporting definitions.
It never silently discards a malformed result line.

The numerical environment is recorded in competitive_environment.json.
NumPy and SciPy are required. The script sets BLAS thread limits to one
before importing NumPy; threadpoolctl is optional. No external dataset or
network connection is needed. All observations are generated from the
recorded seed and configuration. make_data(configuration, seed) recreates
the corrected and zero-filled Node objects, validation and test samples,
truth, attack direction, population covariance and data hash.

Each JSONL line is one method on one configuration and seed. It records:
  * data/mask/validation/test hash and master corrected minimum eigenvalue;
  * all seven candidates, including failed initializations and solves;
  * stage KKT residuals, supports, proximal updates and communication rounds;
  * tuning factor, actual final lambda, selected coefficient and outer path;
  * coefficient, prediction and support metrics, with truth used only for
    evaluation and for the declared stealth attack, never for selection;
  * serial fitting plus validation times for every candidate and their sum;
  * theoretical vector-payload counts from actual communication rounds.

Timing includes each candidate's local initialization, all attempted inner
updates, aggregation and validation scoring. It excludes observed-moment
construction and data generation. It is not an end-to-end multi-host or
network benchmark. Payload counts assume coefficient broadcasts and worker
gradient vectors, 16*(m-1)*p bytes per round; initialization has no messages.

Selection uses the smallest validation MSE among candidates whose complete
eight-round path succeeds. If none succeeds, the repetition is marked
all_candidates_failed. Accuracy means are conditional on success; success
and exact-support fractions use the full prescribed repeat count. Failed
candidate endpoint diagnostics do not enter accuracy averages. Candidate
success, grid-edge selections and paired-comparison denominators remain
available so the summaries can be checked.

M-SLARD-ZF and T-SLARD-ZF retain the squared-loss median/trimmed-gradient
SLARD update structure on zero-filled covariates. They use this benchmark's
common validation grid, proximal solver and eight-round schedule rather
than the original paper's BIC/FISTA/five-round numerical choices. They are
not missingness-corrected implementations. NoCorrection-SCAD additionally
separates correction from the folded-concave penalty. The seven-factor
grid is common, while the natural scale is SD(Y)/q for corrected methods
and SD(Y) for zero-filled methods, so equal factors need not give equal
penalty values.

The original solver robust_sparse.py was not changed. Passive outer-path
instrumentation is checked against it in competitive_core_equivalence.json
and competitive_core_equivalence_fullgrid.json. The latter covers all 63
method/factor combinations, including 25 failed candidates, with identical
endpoints, statuses and stage records. competitive_protocol_amendment.txt
records documentation and audit changes made after the pilot but before
the full study. The full-study source is frozen during execution.
