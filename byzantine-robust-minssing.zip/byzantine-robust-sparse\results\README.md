# Frozen results from the manuscript

These files are the small summary records from the manuscript revision shipped
with the code. They let readers inspect the final numbers and compare them with
regenerated output without downloading the raw traces.

Raw experiment records are **not** distributed: `competitive_full.jsonl`
(about 176 MB), `competitive_sample_size.jsonl` (about 42 MB),
`path_ablation.json` (about 70 MB), `theory_indefinite.json` (about 11 MB) and
the per-sample `theory_mcar_moments_*.npz` arrays. Regenerate them with the
drivers listed below.

| File | Produced by | Consumed by |
|---|---|---|
| `competitive_README.txt` | Experiment protocol (manual) | Readers of the benchmark |
| `competitive_sample_size_README.txt` | Experiment protocol (manual) | Readers of the follow-up |
| `competitive_summary.json` | `summarize_competitive.py --study main` | `revision29_displays.py`, `main_empirical_figures.py` |
| `competitive_sample_size_summary.json` | `summarize_competitive.py --study sample_size` | `revision29_displays.py` |
| `revision_real.json` | `run_revision.py` | `verify_and_summarize.py` |
| `revision_summary.json` | `verify_and_summarize.py` | Readers of the real-data summary |
| `theory_mcar.json` | `theory_mcar_experiment.py` | `plot_theory_validation.py` |
| `theory_indefinite_core_equivalence.json` | `theory_indefinite_experiment.py` | Readers of the solver equivalence check |
| `theory_variance.json` | `theory_variance_experiment.py` | `plot_score_variance.py` |
| `no_attack_budget.json` | `no_attack_budget.py` | `summarize_no_attack_budget.py` |
| `no_attack_budget_summary.json` | `summarize_no_attack_budget.py` | LaTeX table for the supplement |
| `reviewer_unequal.json` | `reviewer_experiments.py unequal` | `summarize_reviewer.py`, `main_empirical_figures.py` |
| `reviewer_calibration.json` | `reviewer_experiments.py calibration` | `summarize_reviewer.py` |
| `reviewer_summary.json` | `summarize_reviewer.py` | `main_empirical_figures.py` |
| `real_revision2.json` | `real_revision2.py` | `summarize_revision2.py` |
| `revision2_summary.json` | `summarize_revision2.py` | Readers of the real-data summary |
| `path_summary.json` | `summarize_paths.py` | `main_empirical_figures.py` |
| `sampled_curvature.json` | `check_sampled_curvature.py` | `summarize_paths.py` |
| `matched_cost_runs.json` | `benchmark_matched_cost.py` | Cost tables |
| `end_to_end.json` | `benchmark_end_to_end.py` | `make_strengthened_figures.py` |
| `scaling.json` | `benchmark_scaling.py` | `make_scaling_report.py` |
| `scaling_summary.json` | `make_scaling_report.py` | Readers of the scaling summary |
| `local_certificates.json` | `certificate_experiments.py` | Supplement certificate tables |
| `calibration_certificates.json` | `certificate_experiments.py` | Supplement calibration tables |
| `certified_selection.json` | `check_certified_selection.py` | Algebraic certificate check |
| `bridge_audit.json` | `bridge_experiment.py` | `make_strengthened_figures.py` |
| `slard_baseline_audit.json` | `check_slard_baseline.py` | Readers of the baseline audit |
| `strengthening_audit.json` | `audit_strengthening.py` | Readers of the strengthening audit |

To regenerate a missing summary, run the producing script after its input
records exist. The two protocol READMEs describe the exact grid, seeds,
selection rules and failure accounting of the two competitive studies.
