"""Necessary-condition audit for the existing 30 reference master samples.
Uses the original generator and seeds; does not refit or change estimates.
"""
from pathlib import Path
import json
import numpy as np
from run_revision import ar
ROOT=Path(__file__).resolve().parents[1]
records=[]
for rep in range(30):
 seed=20268008+rep;rng=np.random.default_rng(seed);n=120;p=240;q=.7;s=4
 x=ar(rng,n,p,.3);truth=np.zeros(p);truth[[0,60,120,180]]=[1.2,-1.2,1.2,-1.2]
 y=x@truth+rng.normal(size=n);z=x*(rng.random(x.shape)<q)
 diagonal=np.mean(z*z,axis=0)/q
 ratio=float(diagonal.max()/diagonal.min())
 K_lower=2*s+int(np.ceil((32/3)**2*(ratio-1)**2*s))
 # Single-coordinate restrictions force M/kappa >= max(diag)/min(diag).
 # If 4*K>=p the theorem demands global PD. But n<p, q<1 and positive
 # diagonals imply a strictly negative quadratic direction in ker(Z).
 incompatible=bool(4*K_lower>=p and n<p and q<1 and np.all(diagonal>0))
 records.append(dict(rep=rep,seed=seed,n=n,p=p,q=q,s=s,diagonal_ratio=ratio,K_lower_bound=K_lower,incompatible_with_stated_curvature=incompatible))
out=dict(records=records,incompatible_count=sum(r['incompatible_with_stated_curvature'] for r in records),interpretation='Necessary-condition exclusion for the stated K and spectral assumption; not an algorithm failure or a counterexample to the conditional theorem.')
(ROOT/'results'/'reference_curvature_audit.json').write_text(json.dumps(out,indent=2))
print('Reference samples outside stated curvature condition:',out['incompatible_count'],'/30')
