"""Corrected quadratic learning. No PSD projection or hidden ridge.

The envelope policy implements the stated conditional theorem. The practical
policy is validation-tuned and is explicitly not automatically certified.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import itertools
import numpy as np
from scipy.special import ndtri

def soft(x,w):return np.sign(x)*np.maximum(np.abs(x)-w,0)
def penalty_weights(x,lam,penalty):
    z=np.abs(x)
    if penalty=='lasso':return np.full(x.size,lam)
    if penalty=='scad':return np.where(z<=lam,lam,np.maximum(3.7*lam-z,0)/2.7)
    if penalty=='mcp':return np.maximum(lam-z/3,0)
    raise ValueError(penalty)
def kkt(g,x,w):
    r=np.maximum(np.abs(g)-w,0);a=x!=0;r[a]=np.abs(g[a]+w[a]*np.sign(x[a]))
    return float(r.max())

class Node:
    def __init__(self,z,y,q,dense=False):
        self.z=np.ascontiguousarray(z,dtype=float);self.y=np.asarray(y,dtype=float);self.q=q
        self.n,self.p=z.shape;self.diag=np.mean(z*z,axis=0)/q
        self.gamma=z.T@y/(self.n*q);self.gram=None
        if dense:
            a=z.T@z/self.n
            self.gram=(a-(1-q)*np.diag(np.diag(a)))/q**2
    def mv(self,x):
        if self.gram is not None:return self.gram@x
        return self.z.T@(self.z@x)/(self.n*self.q**2)-(1-self.q)*self.diag*x/self.q
    def grad(self,x):return self.mv(x)-self.gamma
    def score_sd(self,x):
        q=self.q;z=self.z
        a=z*(z@x-self.y*q)[:,None]/q**2-(1-q)*z*z*x/q**2
        return np.std(a,axis=0,ddof=0)

def aggregate(messages,kind,b=0,sd=None,n=None):
    if kind=='mean':return messages.mean(axis=0)
    if kind=='median':return np.median(messages,axis=0)
    if kind=='trim':return np.sort(messages,axis=0)[b:len(messages)-b].mean(axis=0)
    if kind=='vrmom':
        # Tu et al. (2021), Eq. (6), ten equally spaced quantiles.
        med=np.median(messages,axis=0);se=np.maximum(sd/np.sqrt(n),1e-12)
        levels=np.arange(1,11)/11;z=ndtri(levels)
        counts=sum(((messages<=med+se*t)-level).sum(axis=0) for t,level in zip(z,levels))
        return med-se*counts/(len(messages)*np.exp(-z*z/2).sum()/np.sqrt(2*np.pi))
    raise ValueError(kind)

def attack(raw,f,kind,t,seed,direction=None):
    if f==0:return raw
    out=raw.copy();good=raw[:-f]
    if kind=='gaussian':out[-f:]=np.random.default_rng(np.random.SeedSequence([seed,t,761])).normal(0,20,(f,raw.shape[1]))
    elif kind=='signflip':out[-f:]=-20*good.mean(axis=0)
    elif kind=='stealth':
        if direction is None:direction=np.sign(np.median(good,axis=0))
        lo,hi=np.quantile(good,[.3,.7],axis=0)
        out[-f:]=np.where(direction>0,hi,np.where(direction<0,lo,np.median(good,axis=0)))
    elif kind=='none':pass
    else:raise ValueError(kind)
    return out

def stage(node,c,w,x,tol,step_upper=None,max_iter=1200):
    x=x.copy();g=node.mv(x)-c;lip=step_upper or max(float(node.diag.max()),.1)
    maxsupport=int(np.count_nonzero(x))
    for it in itertools.count():
        r=kkt(g,x,w)
        if r<=tol:return x,dict(status='ok',iterations=it,kkt=r,max_support=maxsupport)
        if max_iter is not None and it>=max_iter:break
        for _ in range(50):
            trial=soft(x-g/lip,w/lip);d=trial-x;gd=node.mv(d)
            if step_upper is not None or d@gd<=lip*(d@d)+1e-12:break
            lip*=2
        else:return x,dict(status='line_search_failed',iterations=it,kkt=r,max_support=maxsupport)
        x=trial;g+=gd;maxsupport=max(maxsupport,int(np.count_nonzero(x)))
        if not np.isfinite(x).all() or (step_upper is None and np.linalg.norm(x)>1e4):
            return x,dict(status='diverged',iterations=it+1,kkt=None,max_support=maxsupport)
        if step_upper is None:lip=max(.1,lip/1.05)
    return x,dict(status='max_iter',iterations=max_iter,kkt=r,max_support=maxsupport)

def homotopy(node,c,x,w,base,target,step_upper=None,s=None,K=None,eta=12/13,max_iter=1200):
    lam=base;iterations=0;maxsupport=int(np.count_nonzero(x));stages=0
    while True:
        final=lam<=target*(1+1e-12)
        tol=min(1e-5,target/1000) if final else lam/26
        if s is not None:tol=min(tol,lam/4*np.sqrt(s/(2*K)))
        x,info=stage(node,c,w*(lam/base),x,tol,step_upper,max_iter)
        iterations+=info['iterations'];stages+=1;maxsupport=max(maxsupport,info['max_support'])
        if final or info['status']!='ok':
            return x,dict(info,iterations=iterations,stages=stages,max_support=maxsupport)
        lam=max(target,lam*eta)

def initial(node,scale,factor):
    lam=factor*scale*np.sqrt(np.log(node.p)/node.n);base=max(lam,np.abs(node.gamma).max())
    x,info=homotopy(node,node.gamma,np.zeros(node.p),np.full(node.p,base),base,lam)
    return x,lam,info

def fit(nodes,scale,factor,agg,penalty,b,f,attack_kind,seed,rounds=8,direction=None,init=None,penalty_budget=None):
    master=nodes[0];m=len(nodes);p=master.p
    sizes=np.asarray([node.n for node in nodes],dtype=float)
    if np.any(sizes<=0):raise ValueError('Node sample sizes must be positive.')
    equal_sizes=bool(np.all(sizes==sizes[0]))
    if agg=='vrmom' and not equal_sizes:raise ValueError('The VRMOM comparator requires equal node sample sizes.')
    x,local,initial_info=initial(master,scale,factor) if init is None else init
    x=x.copy();trace=[]
    if initial_info['status']!='ok':return x,dict(status='initial_failed',trace=[],initial=initial_info)
    floor_budget=b if penalty_budget is None else penalty_budget
    if not 0<=floor_budget<m/2:raise ValueError('Invalid penalty budget.')
    if equal_sizes:
        floor=factor*scale*(np.sqrt(np.log(p)/(m*master.n))+(floor_budget/m)*np.sqrt(np.log(p)/master.n))
    else:
        effective_n=m*m/np.sum(1/sizes)
        floor=factor*scale*(np.sqrt(np.log(p)/effective_n)+(floor_budget/m)*np.sqrt(np.log(p)/sizes.min()))
    for t in range(rounds):
        raw=np.array([node.grad(x) for node in nodes]);sent=attack(raw,f,attack_kind,t,seed,direction)
        sd=master.score_sd(x) if agg=='vrmom' else None
        g=aggregate(sent,agg,b,sd,master.n);c=master.mv(x)-g
        target=max(floor,local*.65**(t+1));base=max(target,local*.65**t)
        x,info=homotopy(master,c,x,penalty_weights(x,base,penalty),base,target)
        trace.append(dict(info,lambda_value=float(target)))
        if info['status']!='ok':break
    return x,dict(status=trace[-1]['status'],trace=trace,initial=initial_info)

def envelope_fit(nodes,A,B,R0,kappa,M,s,rounds=5,b=0,f=0,attack_kind='none',seed=0,penalty='scad',inflation=1.):
    """Exact theorem policy; bounds are inputs, not estimated from ground truth.
    Does not assert that supplied bounds are valid. The caller must certify them.
    """
    if inflation<1:raise ValueError('inflation must be at least one')
    K=2*s+int(np.ceil((32/3)**2*(M/kappa-1)**2*s));rho=16*inflation*np.sqrt(s)*B/kappa
    if rho>=1:raise ValueError('The supplied constants do not imply contraction.')
    x=np.zeros(nodes[0].p);R=R0;trace=[];ch=2.35 if penalty=='scad' else 1.5
    for t in range(rounds):
        lam=8*inflation*(A+B*R);base=max(lam,R/(ch*np.sqrt(s)),kappa*R/(2*np.sqrt(s)))
        raw=np.array([node.grad(x) for node in nodes]);g=aggregate(attack(raw,f,attack_kind,t,seed),'trim',b)
        c=nodes[0].mv(x)-g
        x,info=homotopy(nodes[0],c,x,penalty_weights(x,base,penalty),base,lam,M,s,K,max_iter=None)
        R=2*np.sqrt(s)*lam/kappa;trace.append(dict(info,radius=R,lambda_value=lam,base=base))
        if info['status']!='ok':break
    return x,dict(status=trace[-1]['status'],trace=trace,K=K,rho=rho)

def certified_select(nodes,xval,yval,A,B,R0,kappa,M,s,inflations=(1.,1.25,1.5,2.),**kwargs):
    """Validation choice among envelope policies, conditional on valid input bounds.
    The routine checks algebraic admissibility, not the statistical validity of
    A, B, R0, kappa or M. No true parameter is accepted or used for selection.
    """
    if not (A>0 and B>=0 and R0>=0 and 0<kappa<=M and s>=1):
        raise ValueError('Invalid envelope inputs')
    opts=[];rejected=[]
    for inflation in inflations:
        if inflation<1 or 16*inflation*np.sqrt(s)*B/kappa>=1:
            rejected.append(float(inflation));continue
        x,info=envelope_fit(nodes,A,B,R0,kappa,M,s,inflation=inflation,**kwargs)
        if info['status']!='ok':raise RuntimeError('Envelope candidate failed')
        val=float(np.mean((yval-xval@x)**2))
        opts.append((x,dict(info,inflation=float(inflation),validation_mse=val)))
    if not opts:raise ValueError('No admissible envelope candidate')
    best=min(range(len(opts)),key=lambda j:opts[j][1]['validation_mse'])
    return opts[best][0],dict(selected_index=best,candidates=[z[1] for z in opts],rejected_inflations=rejected)
